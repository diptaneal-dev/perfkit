package monitoring;

public interface EventType {
    String getDescription();
}
