package monitoring;

public interface Observable<E, S> {
    void addObserver(Observer<E, S> observer);
    void removeObserver(Observer<E, S> observer);
    void notifyObservers(E eventType);
}
