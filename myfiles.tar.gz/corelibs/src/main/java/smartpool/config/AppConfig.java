package smartpool.config;

import config.CoreConfig;

public class AppConfig implements CoreConfig {
    private SmartPoolManagerConfig smartPoolManagerConfig;

    public SmartPoolManagerConfig getSmartPoolManagerConfig() {
        return smartPoolManagerConfig;
    }

    public void setSmartPoolManagerConfig(SmartPoolManagerConfig smartPoolManagerConfig) {
        this.smartPoolManagerConfig = smartPoolManagerConfig;
    }

    @Override
    public String toString() {
        return "AppConfig{" +
                "smartPoolManager=" + smartPoolManagerConfig +
                '}';
    }

    public static class SmartPoolManagerConfig {
        private String eodFilePath;

        public String getEodFilePath() {
            return eodFilePath;
        }

        public void setEodFilePath(String eodFilePath) {
            this.eodFilePath = eodFilePath;
        }

        @Override
        public String toString() {
            return "SmartPoolManager{" +
                    "eodFilePath='" + eodFilePath + '\'' +
                    '}';
        }
    }
}

