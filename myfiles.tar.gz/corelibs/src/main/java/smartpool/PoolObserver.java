package smartpool;

import monitoring.Observer;

public interface PoolObserver extends Observer<PoolEventType, ObjectPool<?>> {
    void update(PoolEventType notification, ObjectPool<?> pool);
}
