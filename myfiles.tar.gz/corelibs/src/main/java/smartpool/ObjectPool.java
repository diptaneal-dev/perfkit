package smartpool;

import monitoring.Observable;
import monitoring.Observer;
import smartpool.poolexceptions.PoolException;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Predicate;

public class ObjectPool<T> implements Observable<PoolEventType, ObjectPool<T>> {
    private final ConcurrentLinkedQueue<T> pool = new ConcurrentLinkedQueue<>();
    private Factory<T> factory;
    private Class<T> type;
    private final long initialSize;
    private final int maxSize;
    private int currentSize;
    private final List<Observer<PoolEventType, ObjectPool<T>>> observers = new ArrayList<>();

    public ObjectPool(Factory<T> factory, Class<T> type, long initialSize, int maxSize) {
        this.factory = factory;
        this.type = type;
        this.initialSize = initialSize;
        this.maxSize = maxSize;
        this.currentSize = 0;
        addObserver(SmartObjectPoolMonitor.getInstance());
        initializeObjects();
    }

    private void initializeObjects() {
        for (int i = 0; i < initialSize; i++) {
            try {
                pool.offer(factory.create());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            currentSize++;
        }
        notifyObservers(PoolEventType.POOL_CREATION);
    }

    public long getInitialSize() {
        return initialSize;
    }

    public T get() throws PoolException {
        T object = pool.poll();
        if (object == null && currentSize < maxSize) {
            synchronized (this) {
                if (!resize()) {
                    notifyObservers(PoolEventType.OUT_OF_POOL);
                    throw new PoolException("No objects available in the pool and resizing is disabled or reached max limit.");
                }
            }

            object = pool.poll();
            if (object == null) {
                notifyObservers(PoolEventType.OUT_OF_POOL);
                throw new PoolException("Failed to retrieve an object even after resizing.");
            }
        }
        notifyObservers(PoolEventType.OBJECT_BORROWED);
        return object;
    }

    public void release(T object) throws PoolException {
        if (object == null) {
            throw new PoolException("Cannot release a null object back to the pool");
        }

        try {
            if (object instanceof Resettable) {
                ((Resettable) object).reset();
            }

            if (!pool.offer(object)) {
                throw new PoolException("Failed to release the object back to the pool");
            }
            notifyObservers(PoolEventType.OBJECT_RETURNED);
        } catch (Exception e) {
            notifyObservers(PoolEventType.ERROR_ON_RELEASE);
            throw new PoolException("Error occurred while releasing object back to the pool", e);
        }
    }

    public boolean resize() throws PoolException {
        try {
            int newSize = currentSize * 2;
            for (int i = 0; i < currentSize; i++) {
                pool.offer(factory.create());
            }
            currentSize = newSize;
            notifyObservers(PoolEventType.RESIZE);

            if (currentSize >= maxSize) {
                notifyObservers(PoolEventType.MAXSIZE_BREACH);
            }
        } catch (OutOfMemoryError e) {
            notifyObservers(PoolEventType.OUT_OF_MEMORY);
            throw new PoolException("Failed to resize the pool due to memory constraints", e);
        } catch (Exception e) {
            notifyObservers(PoolEventType.ERROR_ON_RESIZE);
            throw new PoolException("Error occurred during pool resizing", e);
        }
        return true;
    }

    public void reset() {
        pool.clear();
        notifyObservers(PoolEventType.RESET);
    }

    @Override
    public void removeObserver(Observer<PoolEventType, ObjectPool<T>> observer) {
        observers.removeIf(Predicate.isEqual(observer));
    }

    public Class<T> getObjectClass() {
        return type;
    }

    @Override
    public void addObserver(Observer<PoolEventType, ObjectPool<T>> observer) {
        observers.add(observer);
    }

    @Override
    public void notifyObservers(PoolEventType eventType) {
        for (Observer<PoolEventType, ObjectPool<T>> observer : observers) {
            observer.update(eventType, this);
        }
    }

    public int getCurrentSize() {
        return currentSize;
    }

    public int getAvailableObjects() {
        return pool.size();
    }

    /*
    * Only for JUNIT Tests
     */
    public void setFactory(Factory mockFactory) {
        this.factory = mockFactory;
    }

    @FunctionalInterface
    public interface Factory<T> {
        T create();
    }
}
