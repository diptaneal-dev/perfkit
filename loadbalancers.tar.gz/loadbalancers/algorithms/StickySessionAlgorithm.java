package loadbalancers.algorithms;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StickySessionAlgorithm<T> implements Algorithm<T> {
    private Map<String, T> stickySessions = new HashMap<>();

    @Override
    public T getNextNode(List<T> nodes) {
        throw new UnsupportedOperationException("Sticky session algorithm does not use getNextNode");
    }

    public T getNodeForStickySession(String client, List<T> nodes) {
        if (stickySessions.containsKey(client)) {
            T node = stickySessions.get(client);
            if (nodes.contains(node)) {
                return node;
            }
        }

        // fallback use Round Robin approach
        int currentIndex = (stickySessions.size() % nodes.size());
        T node = nodes.get(currentIndex);
        stickySessions.put(client, node);
        return node;
    }

    public void setStickySession(String client, T node) {
        stickySessions.put(client, node);
    }

    public void clearStickySession(String client) {
        stickySessions.remove(client);
    }
}
