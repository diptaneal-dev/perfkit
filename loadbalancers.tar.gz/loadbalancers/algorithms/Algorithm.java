package loadbalancers.algorithms;

import java.util.List;

public interface Algorithm<T> {
    T getNextNode(List<T> nodes);
}
