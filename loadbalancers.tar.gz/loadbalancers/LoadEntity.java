package loadbalancers;

public interface LoadEntity {
    String getEntityKey();
}
