package loadbalancers;

import loadbalancers.algorithms.Algorithm;
import loadbalancers.algorithms.StickySessionAlgorithm;

import java.util.List;
import java.util.Map;

public class AbstractLoadBalancer<T> implements LoadBalancer<T> {
    private List<T> nodes;
    private Algorithm<T> algorithm;

    public AbstractLoadBalancer(Algorithm<T> algorithm) {
        this.algorithm = algorithm;
    }

    public AbstractLoadBalancer(List<T> nodes, Algorithm<T> algorithm) {
        this.nodes = nodes;
        this.algorithm = algorithm;
    }

    @Override
    public T getNextNode() {
        if (algorithm instanceof StickySessionAlgorithm) {
            throw new UnsupportedOperationException("Sticky session algorithm does not use getNextNode");
        }
        return algorithm.getNextNode(nodes);
    }

    @Override
    public Status getNodeStatus(T node) {
        return null;
    }

    @Override
    public void setNodeStatus(T node, Status status) {

    }

    @Override
    public Map<T, Integer> getLoadDistribution() {
        return null;
    }

    @Override
    public LoadMetrics getLoadMetrics(T node) {
        return null;
    }

    @Override
    public Algorithm getAlgorithm() {
        return algorithm;
    }

    @Override
    public void setAlgorithm(Algorithm algorithm) {
        this.algorithm = algorithm;
    }

    @Override
    public T getStickySession(String client) {
        if (algorithm instanceof StickySessionAlgorithm) {
            StickySessionAlgorithm<T> stickySessionAlgorithm = (StickySessionAlgorithm<T>) algorithm;
            return stickySessionAlgorithm.getNodeForStickySession(client, nodes);
        }
        throw new UnsupportedOperationException("Sticky session not supported");
    }

    @Override
    public void setStickySession(String client, T node) {
        if (algorithm instanceof StickySessionAlgorithm) {
            StickySessionAlgorithm<T> stickySessionAlgorithm = (StickySessionAlgorithm<T>) algorithm;
            stickySessionAlgorithm.setStickySession(client, node);
        } else {
            throw new UnsupportedOperationException("Sticky session not supported");
        }
    }

    @Override
    public List<T> getNodes() {
        return nodes;
    }

    @Override
    public void addNode(T node) {
        nodes.add(node);
    }

    @Override
    public void removeNode(T node) {
        nodes.remove(node);
    }

    @Override
    public void addNodes(List<T> nodes) { this.nodes = nodes; }
}
