package loadbalancers;

import loadbalancers.algorithms.StickySessionAlgorithm;

import java.util.List;

public class StickySessionLoadBalancer<T> extends AbstractLoadBalancer<T> {
    private final StickySessionAlgorithm<T> stickySessionAlgorithm;

    public StickySessionLoadBalancer() {
        super(new StickySessionAlgorithm<>());
        this.stickySessionAlgorithm = (StickySessionAlgorithm<T>) super.getAlgorithm();
    }

    public StickySessionLoadBalancer(List<T> nodes) {
        super(nodes, new StickySessionAlgorithm<>());
        this.stickySessionAlgorithm = (StickySessionAlgorithm<T>) super.getAlgorithm();
    }

    public T getNodeForStickySession(String client) {
        return stickySessionAlgorithm.getNodeForStickySession(client, super.getNodes());
    }

    public void clearStickySession(String client) {
        stickySessionAlgorithm.clearStickySession(client);
    }
}
