package smartpool;

import stats.PoolStats;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;

public class SmartObjectPoolMonitorTest {

    private SmartObjectPoolMonitor monitor;
    private ObjectPool<String> mockPool;

    @BeforeEach
    public void setup() {
        monitor = SmartObjectPoolMonitor.getInstance();
        mockPool = mock(ObjectPool.class);
        when(mockPool.getObjectClass()).thenReturn(String.class);
    }

    @Test
    public void testPoolCreation() {
        when(mockPool.getCurrentSize()).thenReturn(5);
        when(mockPool.getInitialSize()).thenReturn(5L);

        monitor.update(PoolEventType.POOL_CREATION, mockPool);
        PoolStats stats = monitor.getStatsForClass(String.class);

        assertEquals(5, stats.getCurrentSize());
        assertEquals(5, stats.getInitialPoolSize());
    }

    @Test
    public void testObjectBorrowed() {
        monitor.update(PoolEventType.OBJECT_BORROWED, mockPool);
        PoolStats stats = monitor.getStatsForClass(String.class);

        assertEquals(1, stats.getCurrentPoolUtilization());
    }

    @Test
    public void testReset() {
        monitor.update(PoolEventType.RESET, mockPool);
        PoolStats stats = monitor.getStatsForClass(String.class);

        assertEquals(stats.getInitialPoolSize(), 0);
        assertEquals(stats.getCurrentSize(), 0);
        assertEquals(stats.getPoolType(), "");
        assertEquals(stats.getCurrentPoolUtilization(), 0);
    }

    @Test
    public void testEndOfDaySummary() {
        monitor.update(PoolEventType.POOL_CREATION, mockPool);
        String summary = monitor.endOfDaySummary();

        assertTrue(summary.contains("Stats for pool of type String"));
    }


}
