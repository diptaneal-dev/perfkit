package smartpool;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.reflect.Whitebox;
import org.yaml.snakeyaml.Yaml;
import smartpool.config.AppConfig;
import stats.PoolStats;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

class SmartObjectPoolManagerTest {
    private SmartObjectPoolMonitor monitor;
    private SmartObjectPoolManager manager;
    private Map<Class<?>, ObjectPool<?>> mockPools;

    @BeforeEach
    public void setUp() {
        // Mocking the AppConfig and SmartPoolManagerConfig
        AppConfig mockConfig = mock(AppConfig.class);
        AppConfig.SmartPoolManagerConfig mockPoolConfig = mock(AppConfig.SmartPoolManagerConfig.class);
        when(mockConfig.getSmartPoolManagerConfig()).thenReturn(mockPoolConfig);

        manager = SmartObjectPoolManager.getInstance();
        monitor = SmartObjectPoolMonitor.getInstance();
        mockPools = new ConcurrentHashMap<>();

        ObjectPool<String> mockPool = mock(ObjectPool.class);
        mockPools.put(String.class, mockPool);
        Whitebox.setInternalState(manager, "pools", mockPools);

        try {
            Field configField = SmartObjectPoolManager.class.getDeclaredField("config");
            configField.setAccessible(true);
            configField.set(manager, mockConfig);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new RuntimeException("Failed to set mock config", e);
        }
    }

    @AfterEach
    public void tearDown() {

    }

    @Test
    public void testLoadAndInitializePools() {
        when(manager.getEodFilePath()).thenReturn("path/to/yaml");
        try (InputStream mockInputStream = mock(InputStream.class)) {
            when(Files.newInputStream(Paths.get("path/to/yaml"))).thenReturn(mockInputStream);

            manager.loadAndInitializePools();

        } catch (Exception e) {
        }
    }

    @Test
    public void testSavePoolSizes() {
        when(manager.getEodFilePath()).thenReturn("path/to/save");

        try (OutputStream mockOutputStream = mock(OutputStream.class)) {
            when(Files.newOutputStream(Paths.get("path/to/save"))).thenReturn(mockOutputStream);

            manager.savePoolSizes("path/to/save");

        } catch (Exception e) {
        }
    }

    @Test
    public void testGetPool_Success() {
        ObjectPool<String> returnedPool = manager.getPool(String.class);

        assertNotNull(returnedPool);
        assertEquals(mock(ObjectPool.class).getClass(), returnedPool.getClass());
    }

    @Test
    public void testGetPool_NotRegistered() {
        ObjectPool<Integer> returnedPool = manager.getPool(Integer.class);
        assertNull(returnedPool);
    }

    public static void injectIntoPrivateField(Object object, String fieldName, Object valueToInject) throws Exception {
        Field field = object.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        ((Map) field.get(object)).putAll((Map) valueToInject);
    }

    @Test
    public void testSavePoolSizes_success() throws Exception {
        SmartObjectPoolManager manager = SmartObjectPoolManager.getInstance();

        PoolStats mockPoolStats = Mockito.mock(PoolStats.class);
        when(mockPoolStats.getInitialPoolSize()).thenReturn(10L);
        when(mockPoolStats.getPeakSize()).thenReturn(20L);

        SmartObjectPoolMonitor monitorInstance = SmartObjectPoolMonitor.getInstance();
        Map<Class<?>, PoolStats> dummyPoolStatsMap = new HashMap<>();
        dummyPoolStatsMap.put(String.class, mockPoolStats);

        injectIntoPrivateField(monitorInstance, "poolStatsMap", dummyPoolStatsMap);

        String testPath = "testPath.yaml";
        manager.savePoolSizes(testPath);

        Yaml yaml = new Yaml();
        try (InputStream in = Files.newInputStream(Paths.get(testPath))) {
            SavedPoolConfig loadedConfig = (SavedPoolConfig) yaml.load(in);

            List<PoolRecord> loadedPools = loadedConfig.getPools();

            assertEquals(3, loadedPools.size());
            PoolRecord loadedRecord = loadedPools.get(0);
            assertEquals("smartpool.House", loadedRecord.getPoolType());
            assertEquals(20, loadedRecord.getInitialSize());
        } catch ( IOException e) {
            throw new RuntimeException("Failed to read the saved EOD pool sizes", e);
        }
    }
}
