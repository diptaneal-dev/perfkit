package smartpool;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import smartpool.poolexceptions.PoolException;

import static org.junit.jupiter.api.Assertions.*;

public class ObjectPoolTest {

    private ObjectPool<String> objectPool;

    @BeforeEach
    public void setup() {
        ObjectPool.Factory<String> factory = () -> "TestString";
        objectPool = new ObjectPool<>(factory, String.class, 5, 10);
    }

    @Test
    public void testInitializeObjects() {
        assertEquals(5, objectPool.getCurrentSize());
        assertEquals(5, objectPool.getAvailableObjects());
    }

    @Test
    public void testGet() throws PoolException {
        String obj = objectPool.get();
        assertNotNull(obj);
        assertEquals(4, objectPool.getAvailableObjects());
    }

    @Test
    public void testGetWithResize() throws PoolException {
        for (int i = 0; i < 5; i++) {
            objectPool.get();
        }
        String obj = objectPool.get();
        assertNotNull(obj);
        assertTrue(objectPool.getCurrentSize() > 5);
    }

    @Test
    public void testGetWhenMaxSize() {
        // Consume all objects.
        for (int i = 0; i < 10; i++) {
            try {
                objectPool.get();
            } catch (PoolException ignored) {
            }
        }
        assertThrows(PoolException.class, () -> objectPool.get());
    }

    @Test
    public void testReleaseValidObject() throws PoolException {
        String obj = objectPool.get();
        objectPool.release(obj);
        assertEquals(5, objectPool.getAvailableObjects());
    }

    @Test
    public void testReleaseNullObject() {
        assertThrows(PoolException.class, () -> objectPool.release(null));
    }

    @Test
    public void testReset() {
        objectPool.reset();
        assertEquals(0, objectPool.getCurrentSize());
        assertEquals(0, objectPool.getAvailableObjects());
    }

}
