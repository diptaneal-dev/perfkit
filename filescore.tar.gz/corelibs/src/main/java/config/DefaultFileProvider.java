package config;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

public class DefaultFileProvider implements FileProvider {
    @Override
    public InputStream newInputStream(Path path) throws IOException {
        return Files.newInputStream(path);
    }
}
