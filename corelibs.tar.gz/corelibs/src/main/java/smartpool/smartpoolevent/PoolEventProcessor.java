package smartpool.smartpoolevent;

import com.influxdb.client.domain.WritePrecision;
import com.influxdb.client.write.Point;
import eventsHandling.AbstractEventProcessor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import smartpool.PoolStats;

import java.time.Instant;

public class PoolEventProcessor<E> extends AbstractEventProcessor<PoolStats> {
    private static final Logger LOGGER = LogManager.getLogger(PoolEventProcessor.class);
    private static int counter = 0;
    public PoolEventProcessor() {
    }

    @Override
    public void process(PoolStats event) {
        LOGGER.info("Event processor called. Publishing message to Grafana. Event no: {}", counter++);
        try {
            Point point = convertToInfluxDBPoint(event);
            influxDBConnector.write(point);
            LOGGER.info("Data successfully published {}", point.toLineProtocol());
        } catch (Exception e) {
            LOGGER.error("Error processing PoolStats event: ", e);
        }
    }

    @Override
    protected Point convertToInfluxDBPoint(PoolStats poolStats) {
        return Point.measurement("pool_stats")
                .addTag("pool_type", poolStats.getPoolType())
                .addField("initial_pool_size", poolStats.getInitialPoolSize())
                .addField("current_pool_utilization", poolStats.getCurrentPoolUtilization())
                .addField("current_size", poolStats.getCurrentSize())
                .addField("peak_size", poolStats.getPeakSize())
                .addField("out_of_pool_count", poolStats.getOutOfPoolCount())
                .addField("out_of_memory_count", poolStats.getOutOfMemoryCount())
                .addField("resizes", poolStats.getResizes())
                .addField("max_size_breached", poolStats.isMaxSizeBreached())
                .time(Instant.now(), WritePrecision.MS);
    }

    public void close() {
        influxDBConnector.disconnect();
    }
}
