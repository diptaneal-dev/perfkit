package smartpool;

import monitoring.Observable;
import monitoring.Observer;
import smartpool.poolexceptions.PoolException;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * A generic object pool for managing a collection of reusable objects.
 * @param <T> the type of objects in the pool.
 */
public class ObjectPool<T> implements Observable<PoolEventType, ObjectPool<T>> {
    private final ConcurrentLinkedQueue<T> pool = new ConcurrentLinkedQueue<>();
    private Factory<T> factory;
    private Class<T> type;
    private final long initialSize;
    private final int maxSize;
    private int currentSize;
    private boolean strictMaxSize = false;

    private final List<Observer<PoolEventType, ObjectPool<T>>> observers = new ArrayList<>();

    /**
     * Constructs an ObjectPool with the specified parameters.
     *
     * @param factory the factory to create new objects.
     * @param type the class of objects the pool will manage.
     * @param initialSize the initial number of objects in the pool.
     * @param maxSize the maximum size of the pool.
     */
    public ObjectPool(Factory<T> factory, Class<T> type, long initialSize, int maxSize) {
        this.factory = factory;
        this.type = type;
        this.initialSize = initialSize;
        this.maxSize = maxSize;
        this.currentSize = 0;
        addObserver(SmartObjectPoolMonitor.getInstance());
        initializeObjects();
    }

    private void initializeObjects() {
        for (int i = 0; i < initialSize; i++) {
            try {
                pool.offer(factory.create());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            currentSize++;
        }
        notifyObservers(PoolEventType.POOL_CREATION, type);
    }

    /**
     * Sets the strictness of the pool's maximum size.
     *
     * @param strictMaxSize if true, the pool size is strictly enforced.
     */
    public void setStrictMaxSize(boolean strictMaxSize) {
        this.strictMaxSize = strictMaxSize;
    }

    @Override
    public List<Observer<PoolEventType, ObjectPool<T>>> getObservers() {
        return observers;
    }

    public long getInitialSize() {
        return initialSize;
    }

    /**
     * Retrieves an available object from the pool.
     *
     * @return an object from the pool.
     * @throws PoolException if an object cannot be retrieved.
     */
    public T get() throws PoolException {
        T object = pool.poll();
        if (object == null) {
            synchronized (this) {
                if (currentSize < maxSize || !strictMaxSize) {
                    resize();
                } else {
                    notifyObservers(PoolEventType.MAXSIZE_BREACH, type);
                }
            }

            object = pool.poll();
            if (object == null) {
                notifyObservers(PoolEventType.OUT_OF_POOL, type);
                throw new PoolException("Failed to retrieve an object from the pool.");
            }
        }
        notifyObservers(PoolEventType.OBJECT_BORROWED, type);
        return object;
    }

    /**
     * Releases an object back to the pool.
     *
     * @param object the object to be returned to the pool.
     * @throws PoolException if the object cannot be released.
     */
    public void release(T object) throws PoolException {
        if (object == null) {
            throw new PoolException("Cannot release a null object back to the pool");
        }

        try {
            if (object instanceof Resettable) {
                ((Resettable) object).reset();
            }

            if (!pool.offer(object)) {
                throw new PoolException("Failed to release the object back to the pool");
            }
            notifyObservers(PoolEventType.OBJECT_RETURNED, type);
        } catch (Exception e) {
            notifyObservers(PoolEventType.ERROR_ON_RELEASE, type);
            throw new PoolException("Error occurred while releasing object back to the pool", e);
        }
    }

    /**
     * Resizes the pool to accommodate more objects.
     *
     * @return true if resizing was successful.
     * @throws PoolException if resizing fails.
     */
    public boolean resize() throws PoolException {
        try {
            int newSize = currentSize * 2;
            for (int i = 0; i < currentSize; i++) {
                pool.offer(factory.create());
            }
            currentSize = newSize;
            notifyObservers(PoolEventType.RESIZE, type);

            if (currentSize >= maxSize) {
                notifyObservers(PoolEventType.MAXSIZE_BREACH, type);
            }
        } catch (OutOfMemoryError e) {
            notifyObservers(PoolEventType.OUT_OF_MEMORY, type);
            throw new PoolException("Failed to resize the pool due to memory constraints", e);
        } catch (Exception e) {
            notifyObservers(PoolEventType.ERROR_ON_RESIZE, type);
            throw new PoolException("Error occurred during pool resizing", e);
        }
        return true;
    }

    /**
     * Resets the pool, clearing all objects.
     */
    public void reset() {
        pool.clear();
        notifyObservers(PoolEventType.RESET, type);
    }

    /**
     * Gets the class of objects managed by this pool.
     *
     * @return the class of the objects.
     */
    public Class<T> getObjectClass() {
        return type;
    }

    /**
     * Gets the current size of the pool.
     *
     * @return the current size.
     */
    public int getCurrentSize() {
        return currentSize;
    }

    /**
     * Gets the number of available objects in the pool.
     *
     * @return the number of available objects.
     */
    public int getAvailableObjects() {
        return pool.size();
    }

    /**
     * Sets the factory for the pool. Intended for use in tests only.
     *
     * @param mockFactory the factory to be used.
     */
    public void setFactory(Factory mockFactory) {
        this.factory = mockFactory;
    }

    /**
     * Factory interface for creating new objects.
     */
    @FunctionalInterface
    public interface Factory<T> {
        T create();
    }
}
