package smartpool.config;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import config.ApplicationConfig;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.stream.Collectors;

public abstract class AbstractApplicationConfig implements ApplicationConfig {
    private static final Logger LOGGER = LogManager.getLogger(ApplicationConfig.class);

    @Override
    public void loadConfigFromFile(String filePath) {
        try {
            String yamlContent = Files.lines(Paths.get(filePath), StandardCharsets.UTF_8)
                    .collect(Collectors.joining("\n"));
            loadConfigFromString(yamlContent);
        } catch (IOException e) {
            LOGGER.error("Exception thrown while reading config {}", e.getMessage());
        }
    }

    protected Map<String, Object> parseYamlToMap(String yamlContent) {
        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
        try {
            return mapper.readValue(yamlContent, new TypeReference<Map<String, Object>>() {});
        } catch (Exception e) {
            LOGGER.error("Exception thrown while reading config YAML in string format", e);
            return null;
        }
    }
}
