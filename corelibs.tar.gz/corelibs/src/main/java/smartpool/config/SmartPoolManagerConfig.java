package smartpool.config;

import java.util.Map;

public class SmartPoolManagerConfig extends AbstractApplicationConfig {
    private String eodFilePath;

    @Override
    public void loadConfigFromString(String yamlString) {
        Map<String, Object> configMap = parseYamlToMap(yamlString);
        if (configMap != null) {
            if (configMap.containsKey("smartPoolManagerConfig")) {
                Map<String, Object> smartPoolManagerMap = (Map<String, Object>) configMap.get("smartPoolManagerConfig");
                this.eodFilePath = (String) smartPoolManagerMap.get("eodFilePath");
            }
        }
    }

    public String getEodFilePath() {
        return eodFilePath;
    }
}
