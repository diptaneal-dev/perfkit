package smartpool;

import java.util.List;

public class SavedPoolConfig {
    private List<PoolRecord> pools;

    public List<PoolRecord> getPools() {
        return pools;
    }

    public void setPools(List<PoolRecord> pools) {
        this.pools = pools;
    }
}
