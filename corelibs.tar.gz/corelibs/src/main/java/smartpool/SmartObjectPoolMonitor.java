package smartpool;

import eventsHandling.EventPublisher;
import eventsHandling.EventPublisherService;
import smartpool.smartpoolevent.PoolEventProcessor;
import monitoring.Observer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import static smartpool.PoolEventType.POOL_REGISTERED_TO_SM;

public class SmartObjectPoolMonitor<T> implements Observer<PoolEventType, Object> {
    private static final Logger LOGGER = LogManager.getLogger(SmartObjectPoolMonitor.class);

    private static EventPublisher<PoolStats> eventPublisher;
    private PoolEventProcessor eventProcessor;
    private static SmartObjectPoolMonitor INSTANCE;

    private SmartObjectPoolMonitor() {
        eventProcessor = new PoolEventProcessor<PoolStats>();
        eventPublisher = new EventPublisherService<PoolStats>(eventProcessor);
    }

    public static synchronized SmartObjectPoolMonitor getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new SmartObjectPoolMonitor();
        }
        return INSTANCE;
    }

    // Only for testing purposes
    static void resetInstance() {
        INSTANCE = null;
        eventPublisher = null;
    }

    private final Map<Class<?>, PoolStats> poolStatsMap = new ConcurrentHashMap<>();

    public Map<Class<?>, PoolStats> getPoolStatsMap() {
        return poolStatsMap;
    }

    public synchronized void setEventPublisher(EventPublisher<PoolStats> publisher) {
        if (this.eventPublisher != null) {
            throw new IllegalStateException("EventPublisher has already been set!");
        }
        this.eventPublisher = publisher;
    }

    @Override
    public void update(PoolEventType eventType, Object eventObject) {
        if (eventObject instanceof ObjectPool) {
            ObjectPool<?> pool = (ObjectPool<?>) eventObject;
            PoolStats stats = poolStatsMap.computeIfAbsent(pool.getObjectClass(), k -> new PoolStats());
            if (eventPublisher == null) {
                throw new IllegalStateException("EventPublisher is not initialized!");
            }

            switch (eventType) {
                case POOL_CREATION:
                    stats.updateTimeOfPoolCreation();
                    stats.setCurrentSize(pool.getCurrentSize());
                    stats.setInitialPoolSize(pool.getInitialSize());
                    stats.setPoolType(pool.getObjectClass().getName());
                    LOGGER.info("Pool for class {} created.", pool.getObjectClass());
                    break;
                case OBJECT_BORROWED:
                    stats.incrementCurrentPoolUtilization();
                    break;
                case OBJECT_RETURNED:
                    stats.decrementCurrentPoolUtilization();
                    break;
                case OUT_OF_POOL:
                    stats.incrementOutOfPoolCount();
                    break;
                case OUT_OF_MEMORY:
                    stats.incrementOutOfMemoryCount();
                    LOGGER.error("Failed to resize pool for class {} due to memory constraints.", pool.getObjectClass());
                    break;
                case RESIZE:
                    stats.incrementResizes();
                    stats.setCurrentSize(pool.getCurrentSize());
                    stats.addResizeTimestamp(Instant.now());
                    LOGGER.warn("Resize event triggered for class {}.", pool.getObjectClass());
                    break;
                case RESET:
                    stats.reset();
                    LOGGER.warn("Reset event triggered for class {}.", pool.getObjectClass());
                    break;
                case ERROR_ON_RELEASE:
                    LOGGER.error("Error occurred during releasing an object back to the pool for class {}.", pool.getObjectClass());
                    break;
                case ERROR_ON_RESIZE:
                    LOGGER.error("Error occurred during pool resizing for class {}.", pool.getObjectClass());
                    break;
                case MAXSIZE_BREACH:
                    LOGGER.warn("Max Pool Size breached for class {}", pool.getObjectClass());
                    stats.setPeakSize(pool.getCurrentSize());
                    stats.setMaxSizeBreached(true);
                    break;
                default:
                    break;
            }

            if (stats != null) {
                eventPublisher.publish(stats);
            }
        }
        else if (eventObject instanceof PoolRegistrationEvent && eventType == PoolEventType.POOL_REGISTERED_TO_SM) {
            PoolRegistrationEvent registrationEvent = (PoolRegistrationEvent) eventObject;
            Class<?> poolType = registrationEvent.getPoolType();
            SmartObjectPoolManager poolManager = registrationEvent.getPoolManager();

            ObjectPool<?> pool = poolManager.getPool(poolType);

            if (pool != null) {
                PoolStats stats = poolStatsMap.computeIfAbsent(poolType, k -> new PoolStats());
                stats.setPoolType(poolType.getName());
                stats.setCurrentSize(pool.getCurrentSize());
                stats.setInitialPoolSize(pool.getInitialSize());
                LOGGER.info("SmartObjectPoolManager Pool Registered Event received for {}", poolType.getName());
                if (eventPublisher != null) {
                    eventPublisher.publish(stats);
                }
            }
        }

    }

    public Map<Class<?>, Long> getCurrentPoolSizes() {
        return poolStatsMap.entrySet().stream()
                .collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue().getCurrentSize()));
    }

    public Map<Class<?>, Long> getInitialPoolSizes() {
        return poolStatsMap.entrySet().stream()
                .collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue().getInitialPoolSize()));
    }

    public Map<Class<?>, Long> getPeakPoolSizes() {
        return poolStatsMap.entrySet().stream()
                .collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue().getPeakSize()));
    }


    public PoolStats getStatsForClass(Class<?> cls) {
        return poolStatsMap.get(cls);
    }

    public String getPoolStatsAsJson(Class<?> clazz) {
        PoolStats stats = poolStatsMap.get(clazz);
        if (stats != null) {
            return stats.convertStatsToJson();
        }
        return "{}";
    }

    public String endOfDaySummary() {
        StringBuilder summaryBuilder = new StringBuilder();
        summaryBuilder.append("End of Day Pool Summary:\n");

        for (Class<?> poolType : poolStatsMap.keySet()) {
            PoolStats stats = getStatsForClass(poolType);
            if (stats != null) {
                String jsonSummary = stats.convertStatsToJson();
                summaryBuilder.append("Stats for pool of type ")
                        .append(poolType.getSimpleName())
                        .append(": ")
                        .append(jsonSummary)
                        .append("\n");
            } else {
                summaryBuilder.append("No stats found for pool of type ")
                        .append(poolType.getSimpleName())
                        .append("\n");
            }
        }

        String completeSummary = summaryBuilder.toString();
        return completeSummary;
    }

    /*
     * Mainly for JUNIT tests
     */
    public void reset() {
        poolStatsMap.clear();
        eventPublisher = null;
    }
}
