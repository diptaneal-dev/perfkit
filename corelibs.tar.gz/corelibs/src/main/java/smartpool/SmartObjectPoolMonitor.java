package smartpool;

import dbclients.DatabaseClient;
import eventsHandling.DynamicEvent;
import eventsHandling.EventProcessor;
import eventsHandling.EventPublisher;
import eventsHandling.EventPublisherService;
import monitoring.AbstractMonitor;
import smartpool.smartpoolevent.PoolEventProcessor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class SmartObjectPoolMonitor<S> extends AbstractMonitor<PoolEventType, S, PoolTelemetryData> {
    private static final Logger LOGGER = LogManager.getLogger(SmartObjectPoolMonitor.class);
    private final Map<Class<?>, PoolTelemetryData> poolStatsMap = new ConcurrentHashMap<>();
    private DatabaseClient databaseClient;

    private SmartObjectPoolMonitor() {
        super();
    }

    private static class Holder {
        static final SmartObjectPoolMonitor INSTANCE = new SmartObjectPoolMonitor();
    }

    public static SmartObjectPoolMonitor getInstance() {
        return Holder.INSTANCE;
    }

    @Override
    protected EventPublisher<PoolTelemetryData> createEventPublisher() {
        return new EventPublisherService<>(eventProcessor);
    }

    @Override
    protected EventProcessor<PoolTelemetryData> createEventProcessor(DatabaseClient databaseClient) {
        return new PoolEventProcessor<>(databaseClient);
    }

    public synchronized void setEventPublisher(EventPublisher<PoolTelemetryData> publisher) {
        if (this.eventPublisher != null) {
            throw new IllegalStateException("EventPublisher has already been set!");
        }
        this.eventPublisher = publisher;
    }

    @Override
    public void update(DynamicEvent<S, PoolEventType> event) {
        PoolEventType eventType = event.getEventType();
        S eventObject = event.getSubject();
        Class<?> telemetryKey = event.getTelemetryKey();
        PoolTelemetryData stats = poolStatsMap.computeIfAbsent(telemetryKey, k -> new PoolTelemetryData());
        if (eventObject instanceof ObjectPool) {
            ObjectPool<?> pool = (ObjectPool<?>) eventObject;
            switch (eventType) {
                case POOL_CREATION:
                    stats.updateTimeOfPoolCreation();
                    stats.setCurrentSize(pool.getCurrentSize());
                    stats.setInitialPoolSize(pool.getInitialSize());
                    stats.setPoolType(pool.getObjectClass().getName());
                    LOGGER.info("Pool for class {} created.", pool.getObjectClass());
                    break;
                case OBJECT_BORROWED:
                    stats.incrementCurrentPoolUtilization();
                    break;
                case OBJECT_RETURNED:
                    stats.decrementCurrentPoolUtilization();
                    break;
                case OUT_OF_POOL:
                    stats.incrementOutOfPoolCount();
                    break;
                case OUT_OF_MEMORY:
                    stats.incrementOutOfMemoryCount();
                    LOGGER.error("Failed to resize pool for class {} due to memory constraints.", pool.getObjectClass());
                    break;
                case RESIZE:
                    stats.incrementResizes();
                    stats.setCurrentSize(pool.getCurrentSize());
                    stats.addResizeTimestamp(Instant.now());
                    LOGGER.warn("Resize event triggered for class {}.", pool.getObjectClass());
                    break;
                case RESET:
                    stats.reset();
                    LOGGER.warn("Reset event triggered for class {}.", pool.getObjectClass());
                    break;
                case ERROR_ON_RELEASE:
                    LOGGER.error("Error occurred during releasing an object back to the pool for class {}.", pool.getObjectClass());
                    break;
                case ERROR_ON_RESIZE:
                    LOGGER.error("Error occurred during pool resizing for class {}.", pool.getObjectClass());
                    break;
                case MAXSIZE_BREACH:
                    LOGGER.warn("Max Pool Size breached for class {}", pool.getObjectClass());
                    stats.setPeakSize(pool.getCurrentSize());
                    stats.setMaxSizeBreached(true);
                    break;
                default:
                    break;
            }
        }
        else if (eventObject instanceof SmartObjectPoolManager){
            switch(eventType) {
                case POOL_REGISTERED_TO_SM:
                    stats.setPoolType(telemetryKey.getName());
                    stats.setPoolRegisteredWithSmartManager(true);
                    stats.updateLastUpdateTime();
                    LOGGER.info("SmartObjectPoolManager Pool Registered Event received for {}", telemetryKey.getName());
                    break;
                default:
                    break;
            }
        }
        publishTelemetryData(stats);
    }

    @Override
    public void shutdown() {
        super.shutdown();

        if (eventPublisher != null) {
            (eventPublisher).shutdown();
        }
        poolStatsMap.clear();
    }

    public Map<Class<?>, Long> getCurrentPoolSizes() {
        return poolStatsMap.entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().getCurrentSize()));
    }

    public Map<Class<?>, Long> getInitialPoolSizes() {
        return poolStatsMap.entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().getInitialPoolSize()));
    }

    public Map<Class<?>, Long> getPeakPoolSizes() {
        return poolStatsMap.entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().getPeakSize()));
    }


    public PoolTelemetryData getStatsForClass(Class<?> cls) {
        return poolStatsMap.get(cls);
    }

    public String getPoolStatsAsJson(Class<?> clazz) {
        PoolTelemetryData stats = poolStatsMap.get(clazz);
        if (stats != null) {
            return stats.convertTelemetryDataToJSON();
        }
        return "{}";
    }

    public String endOfDaySummary() {
        StringBuilder summaryBuilder = new StringBuilder();
        summaryBuilder.append("End of Day Pool Summary:\n");

        for (Class<?> poolType : poolStatsMap.keySet()) {
            PoolTelemetryData stats = getStatsForClass(poolType);
            if (stats != null) {
                String jsonSummary = stats.convertTelemetryDataToJSON();
                summaryBuilder.append("Stats for pool of type ")
                        .append(poolType.getSimpleName())
                        .append(": ")
                        .append(jsonSummary)
                        .append("\n");
            } else {
                summaryBuilder.append("No stats found for pool of type ")
                        .append(poolType.getSimpleName())
                        .append("\n");
            }
        }

        return summaryBuilder.toString();
    }

    /*
     * Mainly for JUNIT tests
     */
    public void reset() {
        poolStatsMap.clear();
        eventPublisher = null;
    }
}
