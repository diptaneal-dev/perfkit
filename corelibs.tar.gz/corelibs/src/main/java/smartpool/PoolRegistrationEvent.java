package smartpool;

import monitoring.ObservableEvent;

public class PoolRegistrationEvent implements ObservableEvent {
    private final Class<?> poolType;
    private final SmartObjectPoolManager poolManager;

    public PoolRegistrationEvent(Class<?> poolType, SmartObjectPoolManager poolManager) {
        this.poolType = poolType;
        this.poolManager = poolManager;
    }

    public Class<?> getPoolType() {
        return poolType;
    }

    public SmartObjectPoolManager getPoolManager() {
        return poolManager;
    }
}
