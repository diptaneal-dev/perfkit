package smartpool;

import config.EnvironmentManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import smartpool.config.PoolConfig;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;

public abstract class AbstractSmartObjectPoolBuilder {
    protected static final Logger LOGGER = LogManager.getLogger(AbstractSmartObjectPoolBuilder.class);

    protected final SmartObjectPoolManager poolManager;
    protected Properties configProperties;

    protected AbstractSmartObjectPoolBuilder() {
        this.poolManager = SmartObjectPoolManager.getInstance();
        this.configProperties = loadConfigProperties();
    }

    protected Properties loadConfigProperties() {
        final String smartObjectPoolBuilderConfig = EnvironmentManager.getInstance().getVariable("smartObjectPoolBuilder.config.path");

        Properties props = new Properties();
        try (InputStream input = Files.newInputStream(Paths.get(smartObjectPoolBuilderConfig))) {
            props.load(input);
        } catch (Exception e) {
            LOGGER.error("Loading configuration properties failed from {} for AbstractSmartObjectPoolBuilder {}", smartObjectPoolBuilderConfig, e.getMessage());
        }
        return props;
    }

    public <T> void registerPools(Class<T> clazz, long initialSize, int maxSize) {
        poolManager.register(clazz, initialSize, maxSize);
    }

    public <T> ObjectPool<T> getPool(Class<T> clazz) {
        return poolManager.getPool(clazz);
    }

    protected <T> void setupPool(Class<T> clazz) {
        int initialSize;
        int maxSize;

        final String className = clazz.getSimpleName().toLowerCase();
        if (configProperties.containsKey(className + ".initialSize") && configProperties.containsKey(className + ".maxSize")) {
            initialSize = Integer.parseInt(configProperties.getProperty(className + ".initialSize"));
            maxSize = Integer.parseInt(configProperties.getProperty(className + ".maxSize"));
        } else {
            PoolConfig config = clazz.getAnnotation(PoolConfig.class);
            if (config != null) {
                initialSize = config.initialSize();
                maxSize = config.maxSize();
            } else {
                throw new IllegalStateException("No pool configuration available for " + className);
            }
        }

        poolManager.register(clazz, initialSize, maxSize);
    }

    public abstract void setupPools();
}

