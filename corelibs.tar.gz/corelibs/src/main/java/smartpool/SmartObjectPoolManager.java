package smartpool;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import config.EnvironmentManager;
import config.FileProvider;
import config.YamlConfigLoader;
import monitoring.Observable;
import monitoring.Observer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import smartpool.config.AppConfig;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static smartpool.PoolEventType.POOL_REGISTERED_TO_SM;

public class SmartObjectPoolManager implements Observable<PoolEventType, SmartObjectPoolManager> {
    private static final Logger LOGGER = LogManager.getLogger(SmartObjectPoolManager.class);
    private static final int DEFAULT_MAX_SIZE = 10000;

    private AppConfig config;
    private static final SmartObjectPoolManager INSTANCE = new SmartObjectPoolManager();
    private final Map<Class<?>, ObjectPool<?>> pools = new ConcurrentHashMap<>();
    private final List<Observer<PoolEventType, SmartObjectPoolManager>> observers = new ArrayList<>();

    private final FileProvider fileProvider = null;
    private boolean isInitialized = false;
    EnvironmentManager envManager;

    private SmartObjectPoolManager() {
        try {
            envManager = EnvironmentManager.getInstance();
            initialize();
            loadAndInitializePools();
            isInitialized = true;
        } catch (IOException e) {
            LOGGER.error("SmartObjectPoolManager initialization failed");
            throw new RuntimeException(e);
        }
    }

    public void reset() {
        config = null;
        pools.clear();
    }

    public static SmartObjectPoolManager getInstance() {
        return INSTANCE;
    }

    public void initialize() {
        if (isInitialized) {
            return;
        }

        SmartObjectPoolMonitor monitor = SmartObjectPoolMonitor.getInstance();
        addObserver(monitor);

        final String configPath = envManager.getVariable("smartobjectpool.config.path", null);
        config = YamlConfigLoader.loadConfig(configPath, AppConfig.class);
        if (config == null) {
            LOGGER.error("Failed to load SmartObjectPoolManager configuration.");
        }
    }

    @Override
    public List<Observer<PoolEventType, SmartObjectPoolManager>> getObservers() {
        return observers;
    }

    public String getEodFilePath() {
        return this.config.getSmartPoolManagerConfig().getEodFilePath();
    }

    public void loadAndInitializePools() {
        LOGGER.info("Loading smartObjectPool configuration");
        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());

        Path configFilePath = Paths.get(getEodFilePath());
        if (!Files.exists(configFilePath)) {
            LOGGER.error("Configuration file not found at: " + configFilePath);
            return;
        }

        try (InputStream in = fileProvider.newInputStream(configFilePath)) {
            SavedPoolConfig config = mapper.readValue(in, SavedPoolConfig.class);
            List<PoolRecord> loadedPools = config.getPools();
            Map<String, Long> smartObjectPools = new HashMap<>();

            if (loadedPools != null) {
                for (PoolRecord record : loadedPools) {
                    Class<?> clazz = Class.forName(record.getPoolType());
                    smartObjectPools.put(clazz.getName(), record.getInitialSize());
                }
            }

            for (Map.Entry<String, Long> entry : smartObjectPools.entrySet()) {
                try {
                    Class<?> clazz = Class.forName(entry.getKey());
                    ObjectPool.Factory<?> factory = () -> {
                        try {
                            return clazz.getDeclaredConstructor().newInstance();
                        } catch (Exception e) {
                            LOGGER.error("Error creating instance of type: " + clazz.getName(), e);
                            return null;
                        }
                    };

                    register(clazz, entry.getValue(), DEFAULT_MAX_SIZE);
                } catch (ClassNotFoundException e) {
                    LOGGER.error("Error processing type: " + entry.getKey(), e);
                }
            }
        } catch (Exception ex) {
            LOGGER.error("Error loading and initializing pools from file", ex);
        }
    }

    public <T> void register(Class<T> clazz, long initialSize, int maxSize) {
        LOGGER.info("Registering ObjectPool for {} for {} objects", clazz.getName(), initialSize);
        ObjectPool.Factory<T> factory = () -> {
            try {
                return clazz.getDeclaredConstructor().newInstance();
            } catch (Exception e) {
                LOGGER.error("Error creating instance of type: " + clazz.getName(), e);
                return null;
            }
        };

        registerPool(clazz, factory, initialSize, maxSize);
    }

    public <T> void registerPool(Class<T> type, ObjectPool.Factory<T> factory, long initialSize, int maxSize) {
        try {
            if (!pools.containsKey(type)) {
                ObjectPool<T> pool = new ObjectPool<>(factory, type, initialSize, maxSize);
                pools.put(type, pool);
                notifyObservers(POOL_REGISTERED_TO_SM);
            } else {
                LOGGER.warn("A pool for {} is already registered.", type.getName());
            }
        } catch (Exception e) {
            LOGGER.error("Failed to register pool for {}. Reason: {}", type.getName(), e.getMessage(), e);
        }
    }

    @SuppressWarnings("unchecked")
    public <T> ObjectPool<T> getPool(Class<T> type) {
        return (ObjectPool<T>) pools.get(type);
    }

    public void savePoolSizes(String eodFilePath) {
        Map<Class<?>, Long> peakPoolSizes = SmartObjectPoolMonitor.getInstance().getPeakPoolSizes();
        Map<Class<?>, Long> initialPoolSizes = SmartObjectPoolMonitor.getInstance().getInitialPoolSizes();

        List<PoolRecord> records = new ArrayList<>();

        for (Class<?> clazz : peakPoolSizes.keySet()) {
            long currentSize = peakPoolSizes.get(clazz);
            long initialSize = initialPoolSizes.get(clazz);

            // Calculate a buffer for growth (10%)
            long growthBuffer = (long) (currentSize * 0.10);
            long newSize = initialSize;

            if (currentSize >= initialSize) {
                newSize = currentSize + growthBuffer;
            }

            PoolRecord record = new PoolRecord();
            record.setPoolType(clazz.getName());
            record.setInitialSize(newSize);
            records.add(record);
        }

        SavedPoolConfig config = new SavedPoolConfig();
        config.setPools(records);

        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
        try (OutputStream out = Files.newOutputStream(Paths.get(eodFilePath))) {
            mapper.writeValue(out, config);
        } catch (IOException e) {
            throw new RuntimeException("Failed to save EOD pool sizes", e);
        }
    }
}
