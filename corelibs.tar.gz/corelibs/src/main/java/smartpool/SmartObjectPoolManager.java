package smartpool;

import config.YamlConfigLoader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.yaml.snakeyaml.Yaml;
import smartpool.config.AppConfig;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SmartObjectPoolManager {
    private static final Logger LOGGER = LogManager.getLogger(SmartObjectPoolManager.class);
    private static final int DEFAULT_MAX_SIZE = 10000;

    private AppConfig config;
    private static final SmartObjectPoolManager INSTANCE = new SmartObjectPoolManager();
    private final Map<Class<?>, ObjectPool<?>> pools = new ConcurrentHashMap<>();

    private SmartObjectPoolManager() {
        initialize();
        loadAndInitializePools();
    }

    public void reset() {
        config = null;
        pools.clear();
    }

    public static SmartObjectPoolManager getInstance() {
        return INSTANCE;
    }

    public void initialize() {
        final String yamlFilePath = "src/main/resources/smartobjectpool.yaml";
        config = YamlConfigLoader.loadConfig(yamlFilePath, AppConfig.class);
        if (config == null) {
            LOGGER.error("Failed to load SmartObjectPoolManager configuration.");
        }
    }

    public String getEodFilePath() {
        return this.config.getSmartPoolManagerConfig().getEodFilePath();
    }

    public void loadAndInitializePools() {
        LOGGER.info("Loading smartObjectPool configuration");
        Yaml yaml = new Yaml();
        try (InputStream in = new FileInputStream(getEodFilePath())) {
            Object result = yaml.load(in);
            if (result instanceof SavedPoolConfig) {
                SavedPoolConfig config = (SavedPoolConfig) result;

                List<PoolRecord> loadedPools = config.getPools();
                Map<String, Long> smartObjectPools = new HashMap<>();

                if (loadedPools != null) {
                    for (PoolRecord record : loadedPools) {
                        Class<?> clazz = Class.forName(record.getPoolType());
                        smartObjectPools.put(clazz.getName(), record.getInitialSize());
                    }
                }

                for (Map.Entry<String, Long> entry : smartObjectPools.entrySet()) {
                    try {
                        Class<?> clazz = Class.forName(entry.getKey());
                        Object sampleInstance = clazz.getDeclaredConstructor().newInstance();

                        if (sampleInstance != null) {
                            ObjectPool.Factory<?> factory = () -> {
                                try {
                                    return clazz.getDeclaredConstructor().newInstance();
                                } catch (Exception e) {
                                    LOGGER.error("Error creating instance of type: " + clazz.getName(), e);
                                    return null;
                                }
                            };

                            LOGGER.info("Registering ObjectPool for {} for {} objects", clazz.getName(), entry.getValue());
                            registerPoolWithReflection(clazz, entry.getValue(), DEFAULT_MAX_SIZE);
                        } else {
                            LOGGER.warn("No sample instance created for type: " + entry.getKey());
                        }
                    } catch (ClassNotFoundException | NoSuchMethodException | InstantiationException |
                             IllegalAccessException | InvocationTargetException e) {
                        LOGGER.error("Error processing type: " + entry.getKey(), e);
                    }
                }
            }
        } catch (Exception ex) {
            LOGGER.error("Error loading and initializing pools from file", ex);
            ex.printStackTrace();
        }
    }

    private <T> void registerPoolWithReflection(Class<T> clazz, long initialSize, int maxSize) {
        ObjectPool.Factory<T> factory = () -> {
            try {
                return clazz.getDeclaredConstructor().newInstance();
            } catch (Exception e) {
                LOGGER.error("Error creating instance of type: " + clazz.getName(), e);
                return null;
            }
        };

        registerPool(clazz, factory, initialSize, maxSize);
    }

    public <T> void registerPool(Class<T> type, ObjectPool.Factory<T> factory, long initialSize, int maxSize) {
        try {
            if (!pools.containsKey(type)) {
                ObjectPool<T> pool = new ObjectPool<>(factory, type, initialSize, maxSize);
                pools.put(type, pool);
                SmartObjectPoolMonitor.getInstance().update(PoolEventType.POOL_CREATION, pool);
            } else {
                LOGGER.warn("A pool for {} is already registered.", type.getName());
            }
        } catch (Exception e) {
            LOGGER.error("Failed to register pool for {}. Reason: {}", type.getName(), e.getMessage(), e);
        }
    }

    @SuppressWarnings("unchecked")
    public <T> ObjectPool<T> getPool(Class<T> type) {
        return (ObjectPool<T>) pools.get(type);
    }

    public void savePoolSizes(String eodFilePath) {
        Map<Class<?>, Long> peakPoolSizes = SmartObjectPoolMonitor.getInstance().getPeakPoolSizes();
        Map<Class<?>, Long> initialPoolSizes = SmartObjectPoolMonitor.getInstance().getInitialPoolSizes();

        List<PoolRecord> records = new ArrayList<>();

        for (Class<?> clazz : peakPoolSizes.keySet()) {
            long currentSize = peakPoolSizes.get(clazz);
            long initialSize = initialPoolSizes.get(clazz);

            // Calculate a buffer for growth (10%)
            long growthBuffer = (long) (currentSize * 0.10);
            long newSize = initialSize;

            if (currentSize >= initialSize) {
                newSize = currentSize + growthBuffer;
            }

            PoolRecord record = new PoolRecord();
            record.setPoolType(clazz.getName());
            record.setInitialSize(newSize);
            records.add(record);
        }

        SavedPoolConfig config = new SavedPoolConfig();
        config.setPools(records);

        Yaml yaml = new Yaml();
        try (OutputStream out = Files.newOutputStream(Paths.get(eodFilePath))) {
            yaml.dump(config, new OutputStreamWriter(out));
        } catch (IOException e) {
            throw new RuntimeException("Failed to save EOD pool sizes", e);
        }
    }
}
