package featureToggle.telemetry;

import eventsHandling.EventType;

public enum KVMEventType implements EventType {
    KVM_USAGE_COUNTER("KVM Usage Counter");

    private final String description;

    KVMEventType(String description) {
        this.description = description;
    }

    @Override
    public String getDescription() {
        return description;
    }
}

