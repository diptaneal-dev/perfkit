package featureToggle.telemetry;

import dbclients.DatabaseClient;
import eventsHandling.DynamicEvent;
import eventsHandling.EventProcessor;
import eventsHandling.EventPublisher;
import eventsHandling.EventPublisherService;
import featureToggle.FeatureManager;
import monitoring.AbstractMonitor;
import smartpool.PoolTelemetryData;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class KVMEventMonitor<S> extends AbstractMonitor<KVMEventType, S, KVMTelemetryData> {
    private final Map<Class<?>, KVMTelemetryData> telemetryDataMap = new ConcurrentHashMap<>();

    private KVMEventMonitor() {
        super();
    }

    private static class Holder {
        static final KVMEventMonitor INSTANCE = new KVMEventMonitor();
    }

    public static KVMEventMonitor getInstance() {
        return KVMEventMonitor.Holder.INSTANCE;
    }

    @Override
    protected EventProcessor<KVMTelemetryData> createEventProcessor(DatabaseClient databaseClient) {
        return new KVMTelemetryProcessor<>(databaseClient);
    }


    @Override
    protected EventPublisher<KVMTelemetryData> createEventPublisher() {
        return new EventPublisherService<>(eventProcessor);
    }

    @Override
    public void update(DynamicEvent<S, KVMEventType> event) {
        KVMEventType eventType = event.getEventType();
        S eventObject = event.getSubject();

        if (eventObject instanceof FeatureManager) {
            FeatureManager cart = (FeatureManager) eventObject;
            KVMTelemetryData stats = telemetryDataMap.computeIfAbsent(cart.getClass(),
                    k -> new KVMTelemetryData());

            switch (eventType) {
                case KVM_USAGE_COUNTER:
                    stats.setCountKVMUsage(stats.getCountKVMUsage() + 1);
                    stats.updateLastUpdateTime();
                    break;
            }

            if (eventPublisher == null) {
                throw new IllegalStateException("EventPublisher is not initialized!");
            }

            eventPublisher.publish(stats);
        }
    }

    public KVMTelemetryData getTelemetryData(Class<?> clazz) {
        return telemetryDataMap.get(clazz);
    }

    /*
     * Mainly for JUNIT tests
     */
    public void reset() {
        telemetryDataMap.clear();
    }

}