package utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public final class StackTraceUtility {
    private static final Logger LOGGER = LogManager.getLogger(StackTraceUtility.class);

    private StackTraceUtility() {
        throw new UnsupportedOperationException("Utility class and cannot be instantiated");
    }

    /**
     * Prints the specified number of levels from the call stack. This method is useful for debugging purposes
     * to trace the sequence of method calls that led to a particular point in the execution of the program.
     *
     * <p>The method uses {@code StringBuilder} to efficiently concatenate the stack trace information and logs it at the
     * INFO level using Log4j. It starts from the direct caller of this method and goes up the call stack for the specified
     * number of levels.</p>
     *
     * <p>Note: Retrieving the full stack trace is a performance-intensive operation and should be used sparingly,
     * especially in performance-critical sections of code.</p>
     *
     * @param levels The number of levels of the stack trace to print. If the requested levels exceed the actual depth
     *               of the stack, only the available levels are printed.
     * @throws IllegalArgumentException If {@code levels} is less than 1.
     */
    public static void printCallStackLevels(int levels) {
        if (levels < 1) {
            throw new IllegalArgumentException("Number of levels must be at least 1");
        }

        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StringBuilder sb = new StringBuilder();

        int maxLevels = Math.min(levels + 2, stackTrace.length); // +2 to account for getStackTrace and this method itself
        for (int i = 2; i < maxLevels; i++) {
            StackTraceElement element = stackTrace[i];
            sb.append("Stack Level ").append(i - 1).append(":\n");
            sb.append("  Method Name: ").append(element.getMethodName()).append("\n");
            sb.append("  Class Name: ").append(element.getClassName()).append("\n");
            sb.append("  File Name: ").append(element.getFileName()).append("\n");
            sb.append("  Line Number: ").append(element.getLineNumber()).append("\n\n");
        }

        LOGGER.info(sb.toString());
    }
}
