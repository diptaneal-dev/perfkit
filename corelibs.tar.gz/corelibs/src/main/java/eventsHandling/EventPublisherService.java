package eventsHandling;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import smartpool.SmartObjectPoolMonitor;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

public class EventPublisherService<E> implements EventPublisher<E>, Runnable {
    private static final Logger LOGGER = LogManager.getLogger(EventPublisherService.class);

    private final BlockingQueue<E> eventQueue = new LinkedBlockingQueue<>();
    private final EventProcessor<E> eventProcessor;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public EventPublisherService(EventProcessor<E> processor) {
        this.eventProcessor = processor;
        executor.submit(this);
    }

    @Override
    public void publish(E event) {
        LOGGER.info("Publishing event");
        eventQueue.offer(event);
    }

    @Override
    public void run() {
        try {
            while (!Thread.currentThread().isInterrupted()) {
                E event = eventQueue.take();
                eventProcessor.process(event);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            executor.shutdown();
        }
    }

    public void shutdown() {
        executor.shutdownNow();
    }
}

