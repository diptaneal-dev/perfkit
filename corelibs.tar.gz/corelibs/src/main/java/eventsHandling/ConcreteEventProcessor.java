package eventsHandling;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import smartpool.SmartObjectPoolMonitor;

public class ConcreteEventProcessor<E> implements EventProcessor<E> {
    private static final Logger LOGGER = LogManager.getLogger(SmartObjectPoolMonitor.class);

    @Override
    public void process(E event) {
        LOGGER.info("Event processor called. Publishing message to Grafana");
    }
}