package eventsHandling;

import statsHandling.StatsPublisher;

import java.util.ArrayList;
import java.util.List;

public class StatsPublisherMediator {

    private final List<StatsPublisher> publishers = new ArrayList<>();

    public void addPublisher(StatsPublisher publisher) {
        publishers.add(publisher);
    }

    public void publishAll(String statsJson) {
        for (StatsPublisher publisher : publishers) {
            publisher.publishStats(statsJson);
        }
    }
}
