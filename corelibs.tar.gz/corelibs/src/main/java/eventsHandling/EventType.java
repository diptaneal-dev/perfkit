package eventsHandling;

public interface EventType {
    String getDescription();
}
