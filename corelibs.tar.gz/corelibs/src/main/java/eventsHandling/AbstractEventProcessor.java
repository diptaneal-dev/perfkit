package eventsHandling;

import dbclients.DataWriter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public abstract class AbstractEventProcessor<E, T> implements EventProcessor<E> {
    protected static final Logger LOGGER = LogManager.getLogger(AbstractEventProcessor.class);
    protected final DataWriter<T> dataWriter;

    protected AbstractEventProcessor(DataWriter<T> dataWriter) {
        this.dataWriter = dataWriter;
    }

    protected abstract T convertToData(E event);
}
