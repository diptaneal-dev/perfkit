package eventsHandling;

import com.influxdb.client.write.Point;
import config.EnvironmentManager;
import dbclients.infuxdb.InfluxDBConnector;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class AbstractEventProcessor<E> implements EventProcessor<E> {
    protected static final Logger LOGGER = LogManager.getLogger(AbstractEventProcessor.class);
    protected final InfluxDBConnector influxDBConnector;

    public AbstractEventProcessor() {
        final String influxDBConfigPath = EnvironmentManager.getInstance().getVariable("influxdb.config.path");
        this.influxDBConnector = new InfluxDBConnector(influxDBConfigPath);
        this.influxDBConnector.connect();
    }

    @Override
    public abstract void process(E event);

    protected abstract Point convertToInfluxDBPoint(E event);

    public void close() {
        influxDBConnector.disconnect();
    }
}
