package eventsHandling;

public interface EventProcessor<E> {
    void process(E event);
}
