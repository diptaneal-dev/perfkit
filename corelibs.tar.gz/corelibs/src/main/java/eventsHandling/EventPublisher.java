package eventsHandling;

public interface EventPublisher<E> {
    void publish(E event);
}
