package com.mkt.xac.smartpool.config;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.mkt.xac.config.ApplicationConfig;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public abstract class AbstractApplicationConfig implements ApplicationConfig {
    private static final Logger LOGGER = LogManager.getLogger(AbstractApplicationConfig.class);

    @Override
    public void loadConfigFromFile(String filePath) {
        try (Stream<String> lines = Files.lines(Paths.get(filePath), StandardCharsets.UTF_8)) {
            String yamlContent = lines.collect(Collectors.joining("\n"));
            loadConfigFromString(yamlContent);
        } catch (IOException e) {
            LOGGER.error("Exception thrown while reading config {}", e.getMessage());
        }
    }

    public Map<String, Object> parseYamlToMap(String yamlContent) {
        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
        try {
            return mapper.readValue(yamlContent, new TypeReference<Map<String, Object>>() {});
        } catch (Exception e) {
            LOGGER.error("Exception thrown while reading config YAML in string format", e);
            return Collections.emptyMap();
        }
    }
}
