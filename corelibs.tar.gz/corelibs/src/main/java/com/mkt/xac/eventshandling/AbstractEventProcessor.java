package com.mkt.xac.eventshandling;

import com.mkt.xac.dbclients.dbclients.DatabaseClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public abstract class AbstractEventProcessor<E, T> implements EventProcessor<E> {
    protected static final Logger LOGGER = LogManager.getLogger(AbstractEventProcessor.class);
    protected final DatabaseClient databaseClient;

    protected AbstractEventProcessor(DatabaseClient databaseClient) {
        this.databaseClient = databaseClient;
    }

    protected abstract T convertToData(E event);
}
