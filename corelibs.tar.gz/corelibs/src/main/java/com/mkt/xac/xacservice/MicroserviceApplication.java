package com.mkt.xac.xacservice;

import com.mkt.xac.xacservice.processors.SimpleProcessor;
import com.mkt.xac.xacservice.processors.XACProcessor;
import net.openhft.chronicle.queue.ChronicleQueue;
import net.openhft.chronicle.queue.RollCycles;

public class MicroserviceApplication {
    public static void main(String[] args) {
        XACProcessor<Message> processor = new SimpleProcessor();

        ChronicleQueue inputChronicleQueue = ChronicleQueue.singleBuilder("queues/inputQueue")
                .rollCycle(RollCycles.FAST_DAILY)
                .build();

        ChronicleQueue outputChronicleQueue = ChronicleQueue.singleBuilder("queues/outputQueue")
                .rollCycle(RollCycles.FAST_DAILY)
                .build();

        // Create service factory and builder
        ServiceBuilder builder = new ServiceBuilder();
        Microservice myService = builder
                .withInputQueue(inputChronicleQueue)
                .withOutputQueue(outputChronicleQueue)
                .withProcessor(processor)
                .build();

        ServiceController controller = new ServiceController(myService);
        controller.startService();


        controller.stopService();
    }
}
