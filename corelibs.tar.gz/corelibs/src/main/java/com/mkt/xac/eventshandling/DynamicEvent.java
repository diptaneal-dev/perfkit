package com.mkt.xac.eventshandling;

import java.util.HashMap;
import java.util.Map;

public class DynamicEvent<T, E extends EventType> {
    private final T subject;
    private final E eventType;
    private Class<?> telemetryKey;
    private final Map<String, Object> data = new HashMap<>();

    public DynamicEvent(E eventType, T subject, Class<?> telemetryKey) {
        this.eventType = eventType;
        this.subject = subject;
        this.telemetryKey = telemetryKey;
    }

    public DynamicEvent(E eventType, T subject) {
        this.eventType = eventType;
        this.subject = subject;
    }

    public void addData(String key, Object value) {
        data.put(key, value);
    }

    public Object getData(String key) {
        return data.get(key);
    }

    public E getEventType() {
        return eventType;
    }

    public T getSubject() {
        return subject;
    }

    public Class<?> getTelemetryKey() {
        return telemetryKey;
    }
}
