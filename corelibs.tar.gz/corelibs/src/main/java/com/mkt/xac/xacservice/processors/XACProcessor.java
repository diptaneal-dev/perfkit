package com.mkt.xac.xacservice.processors;

import java.util.concurrent.ConcurrentLinkedQueue;

public interface XACProcessor<T> {
    void process(T message, ConcurrentLinkedQueue<T> downstreamQueue);
}
