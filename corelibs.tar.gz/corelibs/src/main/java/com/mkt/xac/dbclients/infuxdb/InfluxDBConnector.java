package com.mkt.xac.dbclients.infuxdb;

import com.influxdb.client.InfluxDBClient;
import com.influxdb.client.InfluxDBClientFactory;
import com.influxdb.client.WriteApi;
import com.influxdb.client.write.Point;
import com.mkt.xac.config.YamlConfigLoader;
import com.mkt.xac.dbclients.DatabaseConnector;
import com.mkt.xac.dbclients.exceptions.ConnectionException;
import com.mkt.xac.dbclients.infuxdb.config.InfluxDBConfig;
import com.mkt.xac.dbclients.infuxdb.config.InfluxDBConfigWrapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class InfluxDBConnector implements DatabaseConnector {
    private static final Logger LOGGER = LogManager.getLogger(InfluxDBConnector.class);
    private InfluxDBClient client;
    private InfluxDBConfig influxDBConfig;
    private final ScheduledExecutorService scheduler;

    public InfluxDBConnector(String configFilePath) {
        configure(configFilePath);
        Runtime.getRuntime().addShutdownHook(new Thread(this::close));
        this.scheduler = Executors.newSingleThreadScheduledExecutor();
    }

    public void setClient(InfluxDBClient client) {
        this.client = client;
    }

    @Override
    public void connect() throws ConnectionException {
        try {
            client = createClient(influxDBConfig.getUrl(), influxDBConfig.getToken().toCharArray());
            if (!client.ping()) {
                throw new ConnectionException("Initial connection to InfluxDB failed");
            }
            LOGGER.info("Successfully connected to InfluxDB");
        } catch (Exception e) {
            throw new ConnectionException("Failed to establish initial connection to InfluxDB", e);
        }
        startReconnectionTask();
    }

    @Override
    public void configure(String configFilePath) {
        try {
            InfluxDBConfigWrapper influxDBConfigWrapper = YamlConfigLoader.loadConfig(configFilePath, InfluxDBConfigWrapper.class);
            if (influxDBConfigWrapper != null) {
                this.influxDBConfig = influxDBConfigWrapper.getInfluxDBConfig();
            }

            if (influxDBConfig != null) {
                influxDBConfig.resolveAllProperties();
            }
        } catch (Exception e) {
            LOGGER.error("Reading config Failed with exception {}", e.getMessage());
        }
    }

    @Override
    public Connection getConnection() throws ConnectionException {
        return null;
    }

    @Override
    public void pingDatabase() throws ConnectionException {
        if (client == null) {
            throw new ConnectionException("InfluxDB client is not initialized.");
        }

        try {
            if (!client.ping()) {
                throw new ConnectionException("Failed to ping InfluxDB.");
            }
            LOGGER.info("Ping to InfluxDB successful.");
        } catch (Exception e) {
            throw new ConnectionException("Error pinging InfluxDB: " + e.getMessage(), e);
        }
    }

    private void startReconnectionTask() {
        AtomicInteger attempts = new AtomicInteger(0);

        Runnable connectTask = () -> {
            if (!isConnected() && attempts.incrementAndGet() <= influxDBConfig.getRetryCount()) {
                try {
                    LOGGER.info("Attempting to reconnect to InfluxDB...");
                    client = createClient(influxDBConfig.getUrl(), influxDBConfig.getToken().toCharArray());
                    if (client.ping()) {
                        LOGGER.info("Reconnected to InfluxDB");
                        shutdownScheduler();
                    }
                } catch (Exception e) {
                    LOGGER.error("Reconnection attempt {} failed", attempts.get(), e);
                }
            } else {
                shutdownScheduler();
            }
        };

        scheduler.scheduleWithFixedDelay(connectTask, 0, influxDBConfig.getRetryInterval(), TimeUnit.MILLISECONDS);
    }

    public boolean isConnected() {
        try {
            return client != null && client.ping();
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public void disconnect() {
        if (client != null) {
            try {
                client.close();
                LOGGER.info("Successfully closed connection to InfluxDB url {}", influxDBConfig.getUrl());
                client = null;
            } catch (Exception e) {
                LOGGER.error("Connection Close Failed with InfluxDB with exception {}", e.getMessage());
            }
        }
    }

    public void close() {
        disconnect();
        shutdownScheduler();
    }

    public void write(Point point) {
        if (client == null) {
            throw new IllegalStateException("InfluxDB client not initialized. Call connect() first.");
        }

        try (WriteApi writeApi = client.makeWriteApi()) {
            writeApi.writePoint(influxDBConfig.getBucket(), influxDBConfig.getOrganization(), point);
        } catch (Exception e) {
            LOGGER.error("Write Failed with InfluxDB with exception {}", e.getMessage());
        }
    }

    private void shutdownScheduler() {
        if (scheduler != null && !scheduler.isShutdown()) {
            scheduler.shutdown();
            try {
                if (!scheduler.awaitTermination(60, TimeUnit.SECONDS)) {
                    scheduler.shutdownNow();
                }
            } catch (InterruptedException ie) {
                scheduler.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }

    public String toString() {
        return "InfluxDBConnector{" +
                "url='" + influxDBConfig.getUrl() + '\'' +
                ", bucket='" + influxDBConfig.getBucket() + '\'' +
                ", organization='" + influxDBConfig.getOrganization() + '\'' +
                '}';
    }

    protected InfluxDBClient createClient(String url, char[] token) {
        return InfluxDBClientFactory.create(url, token);
    }

}
