package com.mkt.xac.config;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;


public interface FileProvider {
    InputStream newInputStream(Path path) throws IOException;
}
