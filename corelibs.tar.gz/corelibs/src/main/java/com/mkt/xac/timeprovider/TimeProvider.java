package com.mkt.xac.timeprovider;

import java.time.Instant;
import java.time.ZoneId;

public interface TimeProvider {
    Instant getCurrentTime();

    Instant getCurrentTime(ZoneId zoneId);
}
