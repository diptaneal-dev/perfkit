package com.mkt.xac.smartpool.config;

import com.mkt.xac.smartpool.PoolRecord;

import java.util.List;

public class SavedPoolConfig {
    private List<PoolRecord> pools;

    public List<PoolRecord> getPools() {
        return pools;
    }

    public void setPools(List<PoolRecord> pools) {
        this.pools = pools;
    }
}
