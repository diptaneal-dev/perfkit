package com.mkt.xac.reusableobjects;

public class TLC {
    private static final ThreadLocal<TLC> CONTEXT = ThreadLocal.withInitial(TLC::new);

    private final FIXMessageString fixMessageString;

    private TLC() {
        fixMessageString = new FIXMessageString();
    }

    public static TLC instance() {
        return CONTEXT.get();
    }

    /**
     * Get a reusable FIXMessageString instance.
     * Note: This instance should only be used within the same thread and should not be passed across threads.
     */
    public FIXMessageString getFIXMessageString() {
        fixMessageString.reset(); // Reset before reuse to clear previous state
        return fixMessageString;
    }

}
