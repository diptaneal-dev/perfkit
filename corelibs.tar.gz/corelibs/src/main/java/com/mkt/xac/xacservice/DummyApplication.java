package com.mkt.xac.xacservice;

import net.openhft.chronicle.queue.ChronicleQueue;
import net.openhft.chronicle.queue.ExcerptAppender;
import net.openhft.chronicle.queue.RollCycles;

public class DummyApplication {
    public static void main(String[] args) {
        final String inputQueuePath = "queues/inputQueue";

        try {
            try (ChronicleQueue queue = ChronicleQueue.singleBuilder(inputQueuePath)
                    .rollCycle(RollCycles.FAST_DAILY)
                    .build()) {

                for (int i = 1; i <= 5; i++) {
                    writeTestMessage(queue, "Test Message " + i);
                    System.out.println("Successfully written: Test Message " + i);
                }
            }
        } catch (Exception e) {
            System.err.println("An error occurred while writing messages to the ChronicleQueue: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void writeTestMessage(ChronicleQueue queue, String content) {
        try (ExcerptAppender appender = queue.createAppender()) {
            appender.writeDocument(w -> w.getValueOut().object(new Message(content)));
        } catch (Exception e) {
            throw new RuntimeException("Error writing message to queue: " + content, e);
        }
    }
}
