package com.mkt.xac.dbclients;

import com.influxdb.client.write.Point;
import com.mkt.xac.dbclients.exceptions.ConnectionException;

public interface DatabaseClient {
    void connect() throws ConnectionException;
    void disconnect() throws ConnectionException;
    boolean isConnected();
    void writeData(Point data);
}
