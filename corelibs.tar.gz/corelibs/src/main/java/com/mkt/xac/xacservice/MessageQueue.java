package com.mkt.xac.xacservice;

import java.util.concurrent.ConcurrentLinkedQueue;

public class MessageQueue<T> {
    private final ConcurrentLinkedQueue<T> queue;

    // Constructor
    public MessageQueue() {
        this.queue = new ConcurrentLinkedQueue<>();
    }

    // Method to enqueue messages
    public void enqueue(T message) {
        queue.offer(message);
    }

    // Method to dequeue messages
    public T dequeue() {
        return queue.poll();
    }

    // Method to check if the queue is empty
    public boolean isEmpty() {
        return queue.isEmpty();
    }

}

