package com.mkt.xac.smartpool.smartpoolevent;

import com.influxdb.client.domain.WritePrecision;
import com.influxdb.client.write.Point;
import com.mkt.xac.dbclients.DatabaseClient;
import com.mkt.xac.eventshandling.AbstractEventProcessor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.mkt.xac.smartpool.PoolTelemetryData;

import java.time.Instant;
import java.time.format.DateTimeFormatter;

public class PoolEventProcessor<E, P> extends AbstractEventProcessor<PoolTelemetryData, Point> {
    private static final Logger LOGGER = LogManager.getLogger(PoolEventProcessor.class);
    private static int counter = 0;
    DateTimeFormatter formatter = DateTimeFormatter.ISO_INSTANT;

    public PoolEventProcessor(DatabaseClient databaseClient) {
        super(databaseClient);
    }

    @Override
    public void process(PoolTelemetryData event) {
        LOGGER.info("Event processor called. Publishing message to Grafana. Event no: {}", counter++);
        try {
            Point point = convertToData(event);
            databaseClient.writeData(point);
            LOGGER.info("Data successfully published {}", point.toLineProtocol());
        } catch (Exception e) {
            LOGGER.error("Error processing PoolStats event: ", e);
        }
    }

    @Override
    protected Point convertToData(PoolTelemetryData poolStats) {
        poolStats.updateLastUpdateTime();
        return Point.measurement("pool_stats")
                .addTag("pool_type", poolStats.getPoolType())
                .addField("initial_pool_size", poolStats.getInitialPoolSize())
                .addField("current_pool_utilization", poolStats.getCurrentPoolUtilization())
                .addField("current_size", poolStats.getCurrentSize())
                .addField("peak_size", poolStats.getPeakSize())
                .addField("out_of_pool_count", poolStats.getOutOfPoolCount())
                .addField("out_of_memory_count", poolStats.getOutOfMemoryCount())
                .addField("resizes", poolStats.getResizes())
                .addField("max_size_breached", poolStats.isMaxSizeBreached())
                .addField("pool_registered_with_SM", poolStats.isPoolRegisteredWithSmartManager())
                .addField("last_update_time", formatter.format(poolStats.getUpdateTime()))
                .time(Instant.now(), WritePrecision.MS);
    }
}
