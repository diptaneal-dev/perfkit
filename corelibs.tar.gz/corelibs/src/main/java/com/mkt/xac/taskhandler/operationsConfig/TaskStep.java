package com.mkt.xac.taskhandler.operationsConfig;

public class TaskStep {
    private String step;
    private String table;
    private String query;
    private String filePath;
    private String delimiter;
    private Boolean createIfNotExist;
    private int expectedColumnCount;

    public int getExpectedColumnCount() {
        return expectedColumnCount;
    }

    public void setExpectedColumnCount(int expectedColumnCount) {
        this.expectedColumnCount = expectedColumnCount;
    }

    public String getQuery() {
        return query;
    }

    public String getFilePath() {
        return filePath;
    }

    public String getDelimiter() {
        return delimiter;
    }

    public Boolean getCreateIfNotExist() {
        return createIfNotExist;
    }

    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }

    public String getTable() {
        return table;
    }

    public void setTable(String table) {
        this.table = table;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("TaskStep{");
        sb.append("step='").append(step).append('\'');
        sb.append(", table='").append(table).append('\'');
        sb.append(", query='").append(query).append('\'');
        sb.append(", filePath='").append(filePath).append('\'');
        sb.append(", delimiter='").append(delimiter).append('\'');
        sb.append(", createIfNotExist=").append(createIfNotExist);
        sb.append('}');
        return sb.toString();
    }
}

