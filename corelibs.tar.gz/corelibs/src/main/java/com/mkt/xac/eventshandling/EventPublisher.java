package com.mkt.xac.eventshandling;

public interface EventPublisher<E> {
    void publish(E event);
    void shutdown();
}
