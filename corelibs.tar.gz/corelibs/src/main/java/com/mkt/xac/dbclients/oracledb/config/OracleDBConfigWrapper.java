package com.mkt.xac.dbclients.oracledb.config;


public class OracleDBConfigWrapper {
    private OracleDBConfig oracleDBConfig;

    public OracleDBConfig getOracleDBConfig() {
        return oracleDBConfig;
    }

    public void setOracleDBConfig(OracleDBConfig oracleDBConfig) {
        this.oracleDBConfig = oracleDBConfig;
    }
}
