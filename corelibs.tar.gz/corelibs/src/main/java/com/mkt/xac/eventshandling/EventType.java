package com.mkt.xac.eventshandling;

public interface EventType {
    String getDescription();
}
