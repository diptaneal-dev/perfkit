package com.mkt.xac.dbclients.dbclients.infuxdb;

import com.influxdb.client.write.Point;
import com.mkt.xac.dbclients.dbclients.DatabaseClient;
import com.mkt.xac.dbclients.dbclients.exceptions.ConnectionException;

public class InfluxDBClient implements DatabaseClient {
    private final InfluxDBConnector influxDBConnector;

    public InfluxDBClient(String configPath) {
        this.influxDBConnector = new InfluxDBConnector(configPath);
    }

    @Override
    public void connect() throws ConnectionException {
        influxDBConnector.connect();
    }

    @Override
    public void disconnect() {
        influxDBConnector.disconnect();
    }

    @Override
    public boolean isConnected() {
        return influxDBConnector.isConnected();
    }

    @Override
    public void writeData(Point data) {
        influxDBConnector.write(data);
    }
}
