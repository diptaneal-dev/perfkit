package com.mkt.xac.taskhandler;

public class DataInsertHandler implements TaskHandler {
    private final TaskStep taskStep;

    public DataInsertHandler(TaskStep taskStep) {
        this.taskStep = taskStep;
    }

    @Override
    public void setNext(TaskHandler taskHandler) {

    }

    @Override
    public void handle(RequestContext context) {

    }
}
