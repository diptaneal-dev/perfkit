package com.mkt.xac.smartpool;

public class PoolRecord {
    private String poolType;
    private long initialSize;

    public PoolRecord() {}

    public PoolRecord(String poolType, int initialSize) {
        this.poolType = poolType;
        this.initialSize = initialSize;
    }

    public String getPoolType() {
        return poolType;
    }

    public void setPoolType(String poolType) {
        this.poolType = poolType;
    }

    public long getInitialSize() {
        return initialSize;
    }

    public void setInitialSize(long initialSize) {
        this.initialSize = initialSize;
    }
}
