package com.mkt.xac.eventshandling;

import com.mkt.xac.statsHandling.StatsPublisher;

import java.util.ArrayList;
import java.util.List;

/*
* This class will be used when we have multiple subscribers
* and we want to use the same event to publish to all
 */
public class StatsPublisherMediator {

    private final List<StatsPublisher> publishers = new ArrayList<>();

    public void addPublisher(StatsPublisher publisher) {
        publishers.add(publisher);
    }

    public void publishAll(String statsJson) {
        for (StatsPublisher publisher : publishers) {
            publisher.publishStats(statsJson);
        }
    }
}
