package com.mkt.xac.xaccache;

import com.mkt.xac.xaccache.exceptions.CacheException;
import net.openhft.chronicle.map.ChronicleMap;
import net.openhft.chronicle.map.ChronicleMapBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;

public class LargeCache implements CacheNode {
    protected static final Logger LOGGER = LogManager.getLogger(LargeCache.class.getName());

    private final ChronicleMap<Object, Object> chronicleMap;
    private final File mapFile;

    public LargeCache(String mapName) {
        try {
            this.mapFile = new File("maps/" + mapName + ".dat");
            this.chronicleMap = ChronicleMapBuilder
                    .of(Object.class, Object.class)
                    .entries(1000)
                    .averageKeySize(2048)
                    .averageValueSize(2048)
                    .name(mapName)
                    .createPersistedTo(mapFile);
        } catch (Exception e) {
            throw new CacheException("Error initializing ChronicleMap", e);
        }
    }

    @Override
    public void clear() {
        chronicleMap.clear();
    }

    public String getCacheName() {
        return chronicleMap.name();
    }

    public boolean isCacheOpen() {
        return chronicleMap.isOpen();
    }

    public boolean isCacheClosed() {
        return chronicleMap.isClosed();
    }

    public void putToCache(Object key, Object value) {
        chronicleMap.put(key, value);
    }

    public Object getFromCache(Object key) {
        return chronicleMap.get(key);
    }

    public void removeFromCache(Object key) {
        chronicleMap.remove(key);
    }

    public int size() {
        return chronicleMap.size();
    }

    public void close() {
        chronicleMap.close();
    }

    @Override
    public void deleteFromDisk() {
        if (chronicleMap.isOpen()) {
            chronicleMap.close();
        }

        // Delete the Chronicle Map file if it exists.
        if (mapFile.exists()) {
            if (mapFile.delete()) {
                LOGGER.warn("Deleted Chronicle Map file: {}", mapFile.getName());
            } else {
                LOGGER.error("Failed to delete Chronicle Map file: {}", mapFile.getName());
            }
        }
    }
}
