package com.mkt.xac.featuretoggle;

import com.mkt.xac.featuretoggle.telemetry.KVMEventMonitor;
import com.mkt.xac.featuretoggle.telemetry.KVMEventType;
import com.mkt.xac.monitoring.Observable;
import com.mkt.xac.monitoring.Observer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FeatureManager<T> implements Observable<KVMEventType, FeatureManager> {
    private Map<String, Map<String, T>> featureGroups = new HashMap<>();
    private static FeatureManager instance;
    private KVMEventMonitor monitor;

    private final List<Observer<KVMEventType, FeatureManager>> observers = new ArrayList<>();

    private FeatureManager()  {
        monitor = KVMEventMonitor.getInstance();
        addObserver(monitor);
        monitor.connectToDatabase();
    }

    public void reset() {
        observers.clear();
        featureGroups.clear();
    }

    public static synchronized FeatureManager getInstance() {
        if (instance == null) {
            instance = new FeatureManager();
        }
        return instance;
    }

    @Override
    public List<Observer<KVMEventType, FeatureManager>> getObservers() {
        return observers;
    }

    public void addFeatureGroup(String groupName) {
        featureGroups.put(groupName, new HashMap<>());
    }
    public void addFeature(String groupName, String featureName, T value) {
        Map<String, T> group = featureGroups.get(groupName);
        if (group != null) {
            group.put(featureName, value);
        } else {
            throw new IllegalArgumentException("Group '" + groupName + "' does not exist.");
        }
    }

    public void updateFeature(String groupName, String featureName, T newValue) {
        featureGroups.computeIfAbsent(groupName, k -> new HashMap<>())
                .put(featureName, newValue);
    }

    public void removeFeature(String groupName, String featureName) {
        Map<String, T> group = featureGroups.get(groupName);
        if (group != null) {
            group.remove(featureName);

            if (group.isEmpty()) {
                featureGroups.remove(groupName);
            }
        }
    }

    public void createKVM(String groupName, String featureName, T value) {
        notifyObservers(KVMEventType.KVM_USAGE_COUNTER);

        if (value == null) {
            throw new IllegalArgumentException("Value cannot be null.");
        }

        Map<String, T> group = featureGroups.computeIfAbsent(groupName, k -> new HashMap<>());
        group.put(featureName, value);
    }

    public void createKVM(String groupName, String featureName, T value, T defaultValue) {
        notifyObservers(KVMEventType.KVM_USAGE_COUNTER);
        T finalValue = (value != null) ? value : defaultValue;

        Map<String, T> group = featureGroups.computeIfAbsent(groupName, k -> new HashMap<>());
        group.put(featureName, finalValue);
    }

    public T getFeatureValue(String groupName, String featureName) {
        Map<String, T> group = featureGroups.get(groupName);
        if (group != null) {
            T value = group.get(featureName);
            if (value != null) {
                return value;
            } else {
                throw new IllegalArgumentException("Feature '" + featureName + "' does not exist in group '" + groupName + "'.");
            }
        } else {
            throw new IllegalArgumentException("Group '" + groupName + "' does not exist.");
        }
    }

    public T getFeatureValueWithDefault(String groupName, String featureName, T defaultValue) {
        Map<String, T> group = featureGroups.get(groupName);
        if (group != null) {
            T value = group.get(featureName);
            return (value != null) ? value : defaultValue;
        } else {
            throw new IllegalArgumentException("Group '" + groupName + "' does not exist.");
        }
    }

    public Map<String, T> getKVM(String groupName) {
        notifyObservers(KVMEventType.KVM_USAGE_COUNTER);
        return featureGroups.getOrDefault(groupName, new HashMap<>());
    }
}
