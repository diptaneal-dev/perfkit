package com.mkt.xac.taskhandler;

import com.mkt.xac.config.EnvironmentManager;
import com.mkt.xac.config.YamlConfigLoader;
import com.mkt.xac.taskhandler.handlers.TaskHandler;
import com.mkt.xac.taskhandler.operationsConfig.Operation;
import com.mkt.xac.taskhandler.operationsConfig.OperationsConfig;
import com.mkt.xac.taskhandler.operationsConfig.Schedule;
import com.mkt.xac.timeprovider.JvmTimeProvider;
import com.mkt.xac.timeprovider.MachineTimeProvider;
import com.mkt.xac.timeprovider.TimeProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.Duration;
import java.time.LocalTime;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class TaskSchedulerService {
    private static final Logger LOGGER = LogManager.getLogger(TaskSchedulerService.class);
    private final ScheduledExecutorService executorService;
    private final TimeProvider timeProvider;
    private OperationsConfig operationsConfig;

    public TaskSchedulerService() {
        this(Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors()),
                initializeDefaultTimeProvider());
    }

    public TaskSchedulerService(TimeProvider timeProvider) {
        this(Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors()), timeProvider);
    }

    private TaskSchedulerService(ScheduledExecutorService executorService, TimeProvider timeProvider) {
        this.executorService = executorService;
        this.timeProvider = timeProvider;
    }

    private static TimeProvider initializeDefaultTimeProvider() {
        final String timeProviderType = EnvironmentManager.getInstance().getVariable("taskScheduler.default.time.provider");
        final String defaultTZ = EnvironmentManager.getInstance().getVariable("taskScheduler.default.timeZone");

        switch (timeProviderType.toLowerCase()) {
            case "machine":
                return new MachineTimeProvider();
            case "jvm":
            default:
                return new JvmTimeProvider(defaultTZ);
        }
    }

    public void configure(String configFilePath) {
        operationsConfig = YamlConfigLoader.loadConfig(configFilePath, OperationsConfig.class);
        if (operationsConfig == null) {
            LOGGER.error("Failed to load operations configuration.");
            return;
        }
        LOGGER.info("Loaded Configuration: {}", operationsConfig);
    }

    public void scheduleTasks(RequestContext context) {
        if (operationsConfig == null) {
            LOGGER.error("Failed to load operations configuration.");
            return;
        }

        for (Operation operation : operationsConfig.getOperations()) {
            scheduleOperation(operation, context);
        }
    }

    public void scheduleOperation(Operation operation, RequestContext context) {
        try {
            Schedule schedule = operation.getSchedule();
            LocalTime startTime = LocalTime.parse(schedule.getStartTime());
            long initialDelay = calculateInitialDelay(startTime);
            long period = calculatePeriod(schedule.getFrequency());

            executorService.scheduleAtFixedRate(() -> {
                try {
                    executeOperation(operation, context);
                } catch (Exception e) {
                    LOGGER.error("Error executing scheduled operation: {}", e.getMessage(), e);
                }
            }, initialDelay, period, TimeUnit.MILLISECONDS);

            LOGGER.info("Scheduled operation '{}' to start at {} with a period of {} seconds",
                    operation.getName(), startTime, period);

        } catch (Exception e) {
            LOGGER.error("Error scheduling operation '{}': {}", operation.getName(), e.getMessage(), e);
        }
    }

    private long calculateInitialDelay(LocalTime startTime) {
        LocalTime now = LocalTime.now();
        long delay;

        if (now.isBefore(startTime)) {
            // If the start time is later today
            delay = Duration.between(now, startTime).toMillis();
        } else {
            // If the start time is tomorrow
            Duration untilMidnight = Duration.between(now, LocalTime.MIDNIGHT);
            Duration afterMidnight = Duration.between(LocalTime.MIDNIGHT, startTime);
            delay = untilMidnight.plus(afterMidnight).toMillis();
        }
        return delay;
    }

    private long calculatePeriod(String frequency) {
        switch (frequency.toLowerCase()) {
            case "daily":
                return TimeUnit.DAYS.toSeconds(1);
            case "weekly":
                return TimeUnit.DAYS.toSeconds(7);
            case "hourly":
                return TimeUnit.HOURS.toSeconds(1);
            default:
                throw new IllegalArgumentException("Unknown frequency: " + frequency);
        }
    }

    private void executeOperation(Operation operation, RequestContext context) {
        LOGGER.info("Scheduled operation triggered {}", operation.getName());
        TaskHandler handlerChain = OperationChainBuilder.buildChain(operation.getSequence());
        handlerChain.handle(context);
    }

    public void shutdown() {
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdown();
            try {
                if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                    executorService.shutdownNow();
                }
            } catch (InterruptedException e) {
                executorService.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }
}
