package com.mkt.xac.taskhandler;

import com.mkt.xac.config.YamlConfigLoader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.Duration;
import java.time.LocalTime;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class TaskSchedulerService {
    private static final Logger LOGGER = LogManager.getLogger(TaskSchedulerService.class);
    private ScheduledExecutorService executorService;

    public TaskSchedulerService() {
        this.executorService = Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors());
    }

    public void scheduleTasks(String configFilePath) {
        OperationsConfig config = YamlConfigLoader.loadConfig(configFilePath, OperationsConfig.class);
        if (config == null) {
            LOGGER.error("Failed to load operations configuration.");
            return;
        }

        LOGGER.info("Loaded Configuration: {}", config);

        for (Operation operation : config.getOperations()) {
            //scheduleOperation(operation);
            executeOperation(operation);
        }
    }

    private void scheduleOperation(Operation operation) {
        Schedule schedule = operation.getSchedule();
        LocalTime startTime = LocalTime.parse(schedule.getStartTime());
        long initialDelay = calculateInitialDelay(startTime);
        long period = calculatePeriod(schedule.getFrequency());

        executorService.scheduleAtFixedRate(() -> executeOperation(operation),
                initialDelay,
                period,
                TimeUnit.SECONDS);
    }

    private long calculateInitialDelay(LocalTime startTime) {
        LocalTime now = LocalTime.now();
        long delay;

        if (now.isBefore(startTime)) {
            // If the start time is later today
            delay = Duration.between(now, startTime).getSeconds();
        } else {
            // If the start time is tomorrow
            delay = Duration.between(now, LocalTime.MIDNIGHT).getSeconds() + Duration.between(LocalTime.MIDNIGHT, startTime).getSeconds();
        }

        return delay;
    }

    private long calculatePeriod(String frequency) {
        switch (frequency.toLowerCase()) {
            case "daily":
                return TimeUnit.DAYS.toSeconds(1);
            case "weekly":
                return TimeUnit.DAYS.toSeconds(7);
            case "hourly":
                return TimeUnit.HOURS.toSeconds(1);
            default:
                throw new IllegalArgumentException("Unknown frequency: " + frequency);
        }
    }

    private void executeOperation(Operation operation) {
        TaskHandler handlerChain = OperationChainBuilder.buildChain((OperationsConfig) operation.getSequence());
        RequestContext context = new RequestContext();
        handlerChain.handle(context);
    }

    public void shutdown() {
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdown();
            try {
                if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                    executorService.shutdownNow();
                }
            } catch (InterruptedException e) {
                executorService.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }
}
