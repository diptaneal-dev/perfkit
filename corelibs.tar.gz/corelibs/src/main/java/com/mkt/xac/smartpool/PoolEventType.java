package com.mkt.xac.smartpool;

import com.mkt.xac.eventshandling.EventType;

public enum PoolEventType implements EventType {
    POOL_CREATION("Pool created event"),
    POOL_REGISTERED_TO_SM ("Pool Registered"),
    OBJECT_BORROWED("Object borrowed event"),
    OBJECT_RETURNED("Object returned to the pool"),
    OUT_OF_POOL("Out of available objects in the pool"),
    OUT_OF_MEMORY("Unable to allocate memory for new objects"),
    MAXSIZE_BREACH("MaxSize Breach event triggered"),
    RESIZE("Pool has been resized"),
    RESET("Pool is reset"),
    ERROR_ON_RELEASE("Error occurred while releasing object back to the pool"),
    ERROR_ON_RESIZE("Error during pool resize"),
    ERROR_ON_CREATION("Smart Pool Creation Error");

    private final String description;

    PoolEventType(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
