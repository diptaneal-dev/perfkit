package com.mkt.xac.loadbalancers;

public interface LoadEntity {
    String getEntityKey();
}
