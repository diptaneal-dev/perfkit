package com.mkt.xac.taskhandler;

public class Schedule {
    private String startTime; // in HH:mm format
    private String frequency; // e.g., "daily", "weekly"

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Schedule{");
        sb.append("startTime='").append(startTime).append('\'');
        sb.append(", frequency='").append(frequency).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
