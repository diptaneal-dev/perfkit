package com.mkt.xac.dbclients.dbclients;

import com.mkt.xac.dbclients.dbclients.exceptions.ConnectionException;

public interface DatabaseConnector {
    void connect() throws ConnectionException;
    void disconnect();
}
