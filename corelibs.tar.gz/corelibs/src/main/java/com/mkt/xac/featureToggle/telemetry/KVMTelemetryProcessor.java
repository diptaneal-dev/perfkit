package com.mkt.xac.featureToggle.telemetry;


import com.influxdb.client.domain.WritePrecision;
import com.influxdb.client.write.Point;
import com.mkt.xac.dbclients.dbclients.DatabaseClient;
import com.mkt.xac.eventshandling.AbstractEventProcessor;

import java.time.Instant;

public class KVMTelemetryProcessor<E, P> extends AbstractEventProcessor<KVMTelemetryData, Point>  {
    private static int counter = 0;
    protected KVMTelemetryProcessor(DatabaseClient databaseClient) {
        super(databaseClient);
    }

    @Override
    protected Point convertToData(KVMTelemetryData event) {
        return Point.measurement("kvm_usage_stats")
                .addTag("kvm_group", String.valueOf(event.getKvmGroup()))
                .addField("kvm_usage_count", String.valueOf(event.getCountKVMUsage()))
                .time(Instant.now(), WritePrecision.MS);
    }

    @Override
    public void process(KVMTelemetryData event) {
        LOGGER.info("Event processor called. Publishing message to Grafana. Event no: {}", counter++);
        try {
            Point point = convertToData(event);
            databaseClient.writeData(point);
            LOGGER.info("Data successfully published {}", point.toLineProtocol());
        } catch (Exception e) {
            LOGGER.error("Error processing PoolStats event: ", e);
        }
    }
}
