package com.mkt.xac.xaccache;

import com.mkt.xac.xaccache.exceptions.CacheException;

import java.io.*;

public class SerializationUtils {

    private SerializationUtils() {

    }

    public static byte[] serialize(Serializable object) {
        try (ByteArrayOutputStream bos = new ByteArrayOutputStream();
             ObjectOutputStream oos = new ObjectOutputStream(bos)) {
            oos.writeObject(object);
            return bos.toByteArray();
        } catch (Exception e) {
            throw new CacheException("Error serializing object", e);
        }
    }

    public static Object deserialize(byte[] bytes) {
        try (ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
             ObjectInputStream ois = new ObjectInputStream(bis)) {
            return ois.readObject();
        } catch (Exception e) {
            throw new CacheException("Error deserializing object", e);
        }
    }
}
