package com.mkt.xac.dbclients.dbclients;

public interface DatabaseService {
}
