package com.mkt.xac.timeprovider.timezoneprovider;

import java.time.ZoneId;

public class ExchangeTimeZoneService {
    private TimeZoneMapping exchangeMap;
    private ZoneId zoneId;

    public ExchangeTimeZoneService() {

    }

    public ExchangeTimeZoneService(CompositeTimeZoneManager manager) {
        this.exchangeMap = (TimeZoneMapping) manager.getComponent("exchangeMap");
    }

    public ZoneId getExchangeTimeZone(String exchangeCode) {
        return exchangeMap.getMapping(exchangeCode);
    }

    public void setZoneId(ZoneId zoneId) {
        this.zoneId = zoneId;
    }
}
