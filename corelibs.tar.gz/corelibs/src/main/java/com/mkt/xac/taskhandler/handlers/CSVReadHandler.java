package com.mkt.xac.taskhandler.handlers;

import com.mkt.xac.taskhandler.RequestContext;
import com.mkt.xac.taskhandler.operationsConfig.TaskStep;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/*
* This class is mainly written for JUNIT tests
 */
public class CSVReadHandler extends AbstractTaskHandler {
    private static final Logger LOGGER = LogManager.getLogger(CSVReadHandler.class);

    private int dataCount;

    public CSVReadHandler(TaskStep taskStep) {
        super(taskStep);
    }

    public int getDataCount() {
        return dataCount;
    }

    @Override
    public void handle(RequestContext context) {
        final String csvFilePath = taskStep.getFilePath();
        final String delimiter = taskStep.getDelimiter();

        dataCount = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            CSVFormat csvFormat = CSVFormat.DEFAULT.builder().setDelimiter(delimiter).build();
            final Iterable<CSVRecord> records = csvFormat.parse(br);

            for (CSVRecord record : records) {
                dataCount++;
            }
        } catch (IOException e) {
            LOGGER.error("Error reading CSV file: {}", e.getMessage(), e);
        }

        LOGGER.info("Data read completed. Total records read: {}", dataCount);
        if (next != null) {
            next.handle(context);
        }
    }
}
