package com.mkt.xac.loadbalancers.algorithms;

import java.util.List;

public class RoundRobinAlgorithm<T> implements Algorithm<T> {
    private int currentIndex = 0;

    @Override
    public T getNextNode(List<T> nodes) {
        if (nodes.isEmpty()) {
            throw new IllegalStateException("No nodes available in the algorithm");
        }

        T nextNode = nodes.get(currentIndex);
        currentIndex = (currentIndex + 1) % nodes.size();
        return nextNode;
    }

    public int getCurrentIndex() {
        return currentIndex;
    }
}
