package com.mkt.xac.taskhandler.handlers;

import com.mkt.xac.dbclients.DatabaseService;
import com.mkt.xac.dbclients.exceptions.ConnectionException;
import com.mkt.xac.taskhandler.RequestContext;
import com.mkt.xac.taskhandler.operationsConfig.TaskStep;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CheckTableExistenceHandler extends AbstractTaskHandler {
    private static final Logger LOGGER = LogManager.getLogger(CheckTableExistenceHandler.class);

    public CheckTableExistenceHandler(TaskStep taskStep) {
        super(taskStep);
    }

    @Override
    public void handle(RequestContext context) {
        final String tableName = taskStep.getTable();
        final String checkTableExistsQuery = taskStep.getQuery().replace("value", "'" + tableName.toUpperCase() + "'");

        try {
            DatabaseService dbService = context.getDbService();
            Connection connection = context.getDbConnection();

            boolean tableExists = dbService.executeQuery(connection, checkTableExistsQuery, ResultSet::next);

            if (!tableExists) {
                final String createTableSQL = "CREATE TABLE " + tableName + " (...)";
                dbService.executeQuery(connection, createTableSQL, rs -> null);
                LOGGER.info("{} table created successfully.", tableName);
            } else {
                LOGGER.info("{} table already exists.", tableName );
            }
        } catch (SQLException e) {
            LOGGER.error("SQL Exception in CheckTableExistenceHandler: {}", e.getMessage(), e);
        } catch (ConnectionException e) {
            throw new RuntimeException(e);
        }

        if (next != null) {
            next.handle(context);
        }
    }
}


