package com.mkt.xac.smartpool.poolexceptions;

public class PoolOutOfMemoryException extends PoolException {
    public PoolOutOfMemoryException(String message) {
        super(message);
    }
}
