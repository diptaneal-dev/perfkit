package com.mkt.xac.statsHandling;

import com.mkt.xac.eventshandling.StatsPublisherMediator;

public interface StatsProducer {
    TelemetryData getMetric();

    void registerWithMediator(StatsPublisherMediator mediator);
}
