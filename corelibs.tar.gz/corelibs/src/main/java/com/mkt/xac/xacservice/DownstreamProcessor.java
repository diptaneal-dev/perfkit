package com.mkt.xac.xacservice;

public class DownstreamProcessor<T> implements Runnable {
    private final MessageQueue<T> outQueue;
    private final MessageSender<T> messageSender;
    private volatile boolean running;

    // Constructor
    public DownstreamProcessor(MessageQueue<T> outQueue, MessageSender<T> messageSender) {
        this.outQueue = outQueue;
        this.messageSender = messageSender;
        this.running = true;
    }

    @Override
    public void run() {
        while (running) {
            try {
                T message = outQueue.dequeue();
                if (message != null) {
                    messageSender.sendMessage(message);
                }
            } catch (Exception e) {
                handleException(e);
            }
        }
    }

    public void stop() {
        this.running = false;
    }

    private void handleException(Exception e) {
    }
}
