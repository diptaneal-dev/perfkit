package com.mkt.xac.taskhandler;

public class DeleteRecordsHandler implements TaskHandler {
    private final TaskStep taskStep;

    public DeleteRecordsHandler(TaskStep taskStep) {
        this.taskStep = taskStep;
    }

    @Override
    public void setNext(TaskHandler taskHandler) {

    }

    @Override
    public void handle(RequestContext context) {

    }
}

