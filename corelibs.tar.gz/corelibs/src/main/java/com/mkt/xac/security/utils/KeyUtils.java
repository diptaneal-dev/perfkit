package com.mkt.xac.security.utils;

import com.mkt.xac.security.CryptoUtils;

import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class KeyUtils {

    public static String encodeKey(byte[] key) {
        return Base64.getEncoder().encodeToString(key);
    }

    public static void main(String args[]) throws NoSuchAlgorithmException {
        byte[] key = CryptoUtils.generateKey();
        System.out.println(encodeKey(key));

        String passcode="strongSecretCode123";
        String encryptedValue = CryptoUtils.encrypt(passcode, key);
        System.out.println("Encrypted Password is: " + encryptedValue);
    }

}
