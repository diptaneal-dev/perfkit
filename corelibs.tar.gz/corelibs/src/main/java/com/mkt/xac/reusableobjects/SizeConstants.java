package com.mkt.xac.reusableobjects;

public class SizeConstants {
    public static final int DEFAULT_STRING_LENGTH = 1024;
}
