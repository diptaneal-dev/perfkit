package com.mkt.xac.dbclients.infuxdb.config;

import com.mkt.xac.config.PropertyResolver;
import com.mkt.xac.security.CryptoUtils;

import java.util.Base64;

/**
 * Configuration class for InfluxDB, mapped from a YAML file using Jackson's ObjectMapper.
 * Field names in this class must match keys in the YAML file for correct data binding.
 *
 * Usage:
 * This class is intended for use with YamlConfigLoader to load InfluxDB settings.
 */
public class InfluxDBConfig implements PropertyResolver {
    private String url;
    private String token;
    private String bucket;
    private String organization;
    private String username;
    private String encryptionKey;
    private String secretValue;
    private int    retryCount;
    private int    retryInterval;

    @Override
    public void resolveAllProperties() {
        setToken(PropertyResolver.resolve(token));
        setUsername(PropertyResolver.resolve(username));
        final byte[] key = Base64.getDecoder().decode(PropertyResolver.resolve(encryptionKey));
        String decryptedSecretValue = CryptoUtils.decrypt(PropertyResolver.resolve(secretValue), key);
        setSecretValue(decryptedSecretValue);
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getBucket() {
        return bucket;
    }

    public void setBucket(String bucket) {
        this.bucket = bucket;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEncryptionKey() {
        return encryptionKey;
    }

    public void setEncryptionKey(String encryptionKey) {
        this.encryptionKey = encryptionKey;
    }

    public String getSecretValue() {
        return secretValue;
    }

    public void setSecretValue(String secretValue) {
        this.secretValue = secretValue;
    }

    public int getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(int retryCount) {
        this.retryCount = retryCount;
    }

    public int getRetryInterval() {
        return retryInterval;
    }
}
