package com.mkt.xac.statsHandling;

public interface StatsPublisher {
    void publishStats(String statsJson);
}
