package com.mkt.xac.xacservice;

public class ServiceMonitor {
    private static ServiceMonitor instance;

    private ServiceMonitor() {
        // Private constructor for singleton pattern
    }

    public static ServiceMonitor getInstance() {
        if (instance == null) {
            instance = new ServiceMonitor();
        }
        return instance;
    }

    // Monitoring methods
}
