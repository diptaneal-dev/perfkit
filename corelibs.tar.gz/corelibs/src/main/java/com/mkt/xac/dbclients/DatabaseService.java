package com.mkt.xac.dbclients;

import com.mkt.xac.dbclients.oracledb.ResultSetProcessor;

import java.sql.Connection;
import java.sql.SQLException;

public interface DatabaseService {
    <T> T executeQuery(Connection connection, String query, ResultSetProcessor<T> processor) throws SQLException;

    boolean executeInsert(Connection connection, String insertSQL, Object[] values);

    boolean executeUpdate(Connection connection, String updateSQL, Object[] values);
}
