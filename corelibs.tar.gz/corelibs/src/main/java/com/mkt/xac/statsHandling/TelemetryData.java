package com.mkt.xac.statsHandling;

import java.time.Instant;

public interface TelemetryData<T> {
    Instant getCreationTime();
    Instant getUpdateTime();
    String convertTelemetryDataToJSON();
}

