package com.mkt.xac.xacservice;

public abstract class Event {
    // Basic properties of an event
    private String type;
    private long timestamp;

    // Constructor
    public Event(String type) {
        this.type = type;
        this.timestamp = System.currentTimeMillis();
    }

    // Abstract method to be implemented by specific event types
    public abstract void process();

    // Getters and Setters
    public String getType() {
        return type;
    }

    public long getTimestamp() {
        return timestamp;
    }
}
