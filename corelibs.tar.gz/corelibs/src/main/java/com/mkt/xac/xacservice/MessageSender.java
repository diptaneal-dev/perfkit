package com.mkt.xac.xacservice;

public interface MessageSender<T> {
    void sendMessage(T message) throws Exception;
}
