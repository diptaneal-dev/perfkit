package com.mkt.xac.dbclients.dbclients.infuxdb.config;

public class InfluxDBConfigWrapper {
    private InfluxDBConfig influxDBConfig;

    public InfluxDBConfig getInfluxDBConfig() {
        return influxDBConfig;
    }

    public void setInfluxDBConfig(InfluxDBConfig influxDBConfig) {
        this.influxDBConfig = influxDBConfig;
    }
}
