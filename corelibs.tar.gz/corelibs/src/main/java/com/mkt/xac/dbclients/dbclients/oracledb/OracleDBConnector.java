package com.mkt.xac.dbclients.dbclients.oracledb;

import com.mkt.xac.config.EnvironmentManager;
import com.mkt.xac.config.YamlConfigLoader;
import com.mkt.xac.dbclients.dbclients.DatabaseService;
import com.mkt.xac.dbclients.dbclients.DatabaseConnector;
import com.mkt.xac.dbclients.dbclients.exceptions.ConnectionException;
import com.mkt.xac.dbclients.dbclients.oracledb.config.OracleDBConfig;
import com.mkt.xac.dbclients.dbclients.oracledb.config.OracleDBConfigWrapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;
import java.util.Properties;

public class OracleDBConnector implements DatabaseConnector {
    private static final Logger LOGGER = LogManager.getLogger(OracleDBConnector.class);

    private OracleDBConfig oracleDBConfig;
    private Connection connection;
    private final OracleDatabaseService dbService;

    public OracleDBConnector(DatabaseService dbService) {
        this.dbService = (OracleDatabaseService) dbService;
    }

    public void configure(String configFilePath) {
        try {
            OracleDBConfigWrapper oracleDBConfigWrapper = YamlConfigLoader.loadConfig(configFilePath, OracleDBConfigWrapper.class);
            if (oracleDBConfigWrapper != null) {
                this.oracleDBConfig = oracleDBConfigWrapper.getOracleDBConfig();
            }

            if (oracleDBConfig != null) {
                oracleDBConfig.resolveAllProperties();
            }
        } catch (Exception e) {
            LOGGER.error("Reading config Failed with exception {}", e.getMessage());
        }
    }

    @Override
    public synchronized void connect() throws ConnectionException {
        try {
            if (connection != null && !connection.isClosed()) {
                try {
                    pingDatabase();
                    return;
                } catch (ConnectionException e) {
                    LOGGER.info("Existing connection is no longer valid. Reconnecting...");
                    connection.close();
                    connection = null;
                }
            }

            System.setProperty("jdk.tls.client.protocols", oracleDBConfig.getTlsProtocolVersion());
            System.setProperty("oracle.net.tns_admin", oracleDBConfig.getTnsAdminPath());

            Properties properties = new Properties();
            properties.put("user", oracleDBConfig.getUser());
            properties.put("password", oracleDBConfig.getPassword());

            connection = DriverManager.getConnection(oracleDBConfig.getUrl(), properties);

            // Perform a ping test to validate the new connection
            pingDatabase();

            LOGGER.info("Successfully connected and pinged Oracle Autonomous Database.");
        } catch (SQLException e) {
            LOGGER.error("Failed to connect to Oracle Database", e);
            throw new ConnectionException("Failed to connect to Oracle Database", e);
        }
    }

    private void pingDatabase() throws ConnectionException {
        try {
            ListResultSetProcessor<Integer> processor = new ListResultSetProcessor<>(new PingRowMapper());
            dbService.executeQuery(connection, "SELECT 1 FROM DUAL", processor);
        } catch (SQLException e) {
            LOGGER.error("Ping to database failed", e);
            throw new ConnectionException("Ping to database failed", e);
        }
    }

    public Connection getConnection() throws ConnectionException, SQLException {
        if (connection == null || connection.isClosed()) {
            connect();
        }
        return connection;
    }

    @Override
    public void disconnect() {
        if (connection != null) {
            try {
                connection.close();
                LOGGER.info("Successfully Disconnected from OracleDB");
            } catch (SQLException e) {
                LOGGER.error("Failed to close the connection {}", e.getMessage(), e);
            }
        }
    }

    public static void main(String[] args) {
        OracleDatabaseService dbService = new OracleDatabaseService();
        OracleDBConnector dbConnector = new OracleDBConnector(dbService);

        try {
            final String oracledbConfigPath = EnvironmentManager.getInstance().getVariable("oracledb.config.path");
            dbConnector.configure(oracledbConfigPath);
            dbConnector.connect();
            final String sql = "INSERT INTO Feature_Manager (GroupName, Key, Value, LastUpdateDate) VALUES (?, ?, ?, ?)";
            final Object[] values = { "Group1", "Key1", "Value1", new java.sql.Timestamp(new java.util.Date().getTime()) };

            boolean success = dbService.executeInsert(dbConnector.getConnection(), sql, values);
            if (success) {
                LOGGER.info("Dummy data insertion successful.");
            } else {
                LOGGER.error("Failed to insert dummy data.");
            }

        } catch (ConnectionException e) {
            LOGGER.error("Error while connecting to the database: {}", e.getMessage());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            dbConnector.disconnect();
        }
    }
}
