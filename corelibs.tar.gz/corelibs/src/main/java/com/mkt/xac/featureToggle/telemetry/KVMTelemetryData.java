package com.mkt.xac.featureToggle.telemetry;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.mkt.xac.statsHandling.TelemetryData;

import java.time.Instant;

public class KVMTelemetryData implements TelemetryData<KVMTelemetryData> {
    private static final Logger LOGGER = LogManager.getLogger(KVMTelemetryData.class);

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

    private String kvmGroup;

    public String getKvmGroup() {
        return kvmGroup;
    }

    public void setKvmGroup(String kvmGroup) {
        this.kvmGroup = kvmGroup;
    }

    private Instant kvmCreationTime;

    @Override
    public Instant getCreationTime() {
        return kvmCreationTime;
    }

    private Instant lastUpdateTime;

    public void updateLastUpdateTime() {
        this.lastUpdateTime = Instant.now();
    }

    @Override
    public Instant getUpdateTime() {
        return lastUpdateTime;
    }

    private int countKVMUsage;

    public int getCountKVMUsage() {
        return countKVMUsage;
    }

    public void setCountKVMUsage(int countKVMUsage) {
        this.countKVMUsage = countKVMUsage;
    }

    @Override
    public String convertTelemetryDataToJSON() {
        try {
            return OBJECT_MAPPER.writeValueAsString(this);
        } catch (Exception e) {
            LOGGER.error("Failed to convert stats to JSON. Reason: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to convert stats to JSON", e);
        }
    }
}
