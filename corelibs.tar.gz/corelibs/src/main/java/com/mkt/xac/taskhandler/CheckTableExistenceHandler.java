package com.mkt.xac.taskhandler;

import com.mkt.xac.dbclients.dbclients.exceptions.ConnectionException;
import com.mkt.xac.dbclients.dbclients.oracledb.OracleDatabaseService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.SQLException;

public class CheckTableExistenceHandler implements TaskHandler {
    private static final Logger LOGGER = LogManager.getLogger(CheckTableExistenceHandler.class);

    private TaskHandler next;
    private final TaskStep taskStep;

    public CheckTableExistenceHandler(TaskStep taskStep) {
        this.taskStep = taskStep;
    }

    @Override
    public void setNext(TaskHandler handler) {
        this.next = handler;
    }

    @Override
    public void handle(RequestContext context) {
        final String tableName = taskStep.getTable();
        final String checkTableExistsQuery = taskStep.getQuery().replace("value", "'" + tableName.toUpperCase() + "'");

        try {
            OracleDatabaseService dbService = context.getDbService();
            Connection connection = context.getDbConnection();

            boolean tableExists = dbService.executeQuery(connection, checkTableExistsQuery, rs -> rs.next());

            if (!tableExists) {
                final String createTableSQL = "CREATE TABLE " + tableName + " (...)";
                dbService.executeQuery(connection, createTableSQL, rs -> null);
                LOGGER.info(tableName + " table created successfully.");
            } else {
                LOGGER.info(tableName + " table already exists.");
            }
        } catch (SQLException e) {
            LOGGER.error("SQL Exception in CheckTableExistenceHandler: {}", e.getMessage(), e);
        } catch (ConnectionException e) {
            throw new RuntimeException(e);
        }

        if (next != null) {
            next.handle(context);
        }
    }

    private boolean tableExists(RequestContext context) {
        // Logic to check table existence
        return false;
    }
}


