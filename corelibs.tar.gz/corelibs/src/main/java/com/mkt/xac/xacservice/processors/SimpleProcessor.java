package com.mkt.xac.xacservice.processors;

import com.mkt.xac.xacservice.Message;

import java.util.concurrent.ConcurrentLinkedQueue;

public class SimpleProcessor implements XACProcessor<Message> {
    @Override
    public void process(Message message, ConcurrentLinkedQueue<Message> downstreamQueue) {
        System.out.println("Processing message: " + message.getContent());
        downstreamQueue.offer(new Message("Processed: " + message.getContent()));
    }
}
