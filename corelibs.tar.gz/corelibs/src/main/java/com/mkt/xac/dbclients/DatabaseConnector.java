package com.mkt.xac.dbclients;

import com.mkt.xac.dbclients.exceptions.ConnectionException;

import java.sql.Connection;
import java.sql.SQLException;

public interface DatabaseConnector {
    void connect() throws ConnectionException;

    void configure(String configFilePath);

    Connection getConnection() throws ConnectionException;

    void pingDatabase() throws ConnectionException;

    void disconnect();
}
