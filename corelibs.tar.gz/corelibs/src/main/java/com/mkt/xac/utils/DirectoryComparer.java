package com.mkt.xac.utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DirectoryComparer {
    public static void main(String[] args) throws IOException {
        File dir1 = new File("/Users/diptanealroy/dev/threading/checkcode/corelibs/");
        File dir2 = new File("/Users/diptanealroy/dev/threading/corelibs/src/main/java");

        compareDirectories(dir1, dir2);
    }

    private static void compareDirectories(File dir1, File dir2) throws IOException {
        List<File> javaFilesDir1 = findJavaFiles(dir1);
        List<File> javaFilesDir2 = findJavaFiles(dir2);

        for (File file1 : javaFilesDir1) {
            File file2 = new File(dir2, file1.getName());
            if (javaFilesDir2.contains(file2)) {
                compareJavaFiles(file1, file2);
            }
        }
    }

    private static List<File> findJavaFiles(File dir) {
        return Arrays.stream(dir.listFiles())
                .filter(file -> file.getName().endsWith(".java"))
                .collect(Collectors.toList());
    }

    private static void compareJavaFiles(File file1, File file2) throws IOException {
        try (Stream<String> lines1Stream = Files.lines(file1.toPath());
             Stream<String> lines2Stream = Files.lines(file2.toPath())) {

            List<String> lines1 = lines1Stream
                    .filter(line -> !line.trim().startsWith("package"))
                    .collect(Collectors.toList());

            List<String> lines2 = lines2Stream
                    .filter(line -> !line.trim().startsWith("package"))
                    .collect(Collectors.toList());

            if (!lines1.equals(lines2)) {
                System.out.println("Different Java File (excluding package difference): " + file1.getName());
            }
        }
    }
}
