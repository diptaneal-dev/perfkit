package com.mkt.xac.dbclients.dbclients.oracledb;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PingRowMapper implements RowMapper<Integer> {
    @Override
    public Integer mapRow(ResultSet rs) throws SQLException {
        return rs.getInt(1);
    }
}

