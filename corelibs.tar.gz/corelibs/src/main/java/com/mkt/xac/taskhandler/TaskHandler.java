package com.mkt.xac.taskhandler;

public interface TaskHandler {
    void setNext(TaskHandler taskHandler);

    void handle(RequestContext context);
}
