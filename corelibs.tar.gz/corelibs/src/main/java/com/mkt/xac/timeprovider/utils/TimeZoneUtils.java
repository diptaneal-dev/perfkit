package com.mkt.xac.timeprovider.utils;

import java.time.Instant;
import java.time.ZoneId;

public class TimeZoneUtils {
    public static Instant convertTime(Instant time, ZoneId fromZone, ZoneId toZone) {
        return time.atZone(fromZone).withZoneSameInstant(toZone).toInstant();
    }
}
