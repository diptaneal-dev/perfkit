package com.mkt.xac.xacservice;

public enum ServiceState {
    NEW,          // The service is newly created
    CONFIGURING,  // The service is in the process of being configured
    RECOVERING,   // The service is recovering from a failure or interruption
    ACTIVE,       // The service is actively running
    STOPPED,      // The service has been stopped
    SUSPENDED,    // The service is temporarily suspended
    FAILED,       // The service has encountered a failure
    STOPPING      // The service is in the process of stopping
}
