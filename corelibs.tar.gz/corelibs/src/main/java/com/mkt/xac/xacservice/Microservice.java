package com.mkt.xac.xacservice;

import com.mkt.xac.xacservice.processors.XACProcessor;
import net.openhft.chronicle.queue.ChronicleQueue;
import net.openhft.chronicle.queue.ExcerptTailer;

import java.util.concurrent.ConcurrentLinkedQueue;

public class Microservice {
    private ServiceMonitor monitor;
    private ChronicleQueue inputQueue;
    private ChronicleQueue outputQueue;
    private final Thread upstreamInputThread;
    private final Thread upstreamOutputThread;
    private final Thread downstreamInputThread;
    private final Thread downstreamOutputThread;
    private final Thread downstreamProcessorThread;
    private ConcurrentLinkedQueue<Message> internalInboundQueue;
    private ConcurrentLinkedQueue<Message> internalOutboundQueue;

    private XACProcessor<Message> processor;

    private ServiceState state;

    public Microservice(XACProcessor<Message> processor) {
        state = ServiceState.NEW;

        internalInboundQueue = new ConcurrentLinkedQueue<>();
        this.internalOutboundQueue = new ConcurrentLinkedQueue<>();

        this.processor = processor;

        upstreamInputThread = new Thread(this::upstreamInputProcessing);
        upstreamOutputThread = new Thread(this::upstreamOutputProcessing);
        downstreamInputThread = new Thread(this::downstreamInputProcessing);
        downstreamOutputThread = new Thread(this::downstreamOutputProcessing);
        downstreamProcessorThread = new Thread(this::downstreamProcessor);

        System.out.println("Microservice started");
    }

    private void startThreads() {
        upstreamInputThread.start();
        upstreamOutputThread.start();
        downstreamInputThread.start();
        downstreamOutputThread.start();
        downstreamProcessorThread.start();
    }

    private void upstreamInputProcessing() {
        System.out.println("Upstream processing thread started...");

        if (inputQueue == null) {
            System.err.println("Input queue is not initialized.");
            return;
        }

        try (ExcerptTailer tailer = inputQueue.createTailer()) {
            while (!Thread.currentThread().isInterrupted()) {
                boolean documentRead = tailer.readDocument(wire -> {
                    Message message = wire.getValueIn().object(Message.class);
                    if (message != null) {
                        internalInboundQueue.offer(message);
                        System.out.println("Enqueued message from upstream: " + message.getContent());
                    }
                });

                if (!documentRead) {
                    System.out.println("No new messages in upstream queue.");
                }

                Thread.sleep(50);
            }
        } catch (InterruptedException e) {
            System.out.println("Upstream processing thread interrupted.");
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            System.err.println("Exception in upstream processing thread: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("Upstream processing thread exiting...");
    }

    private void upstreamOutputProcessing() {
        // Logic for sending output to upstream
    }

    private void downstreamInputProcessing() {
        while (!Thread.currentThread().isInterrupted()) {
            Message message = internalInboundQueue.poll();
            if (message != null) {
                processor.process(message, internalOutboundQueue);
            }

            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }


    private void downstreamOutputProcessing() {
        // Logic for sending output to downstream
    }

    private void downstreamProcessor() {
        // Logic for processing messages (e.g., between inbound and outbound queues)
    }

    public void shutdown() {
        // Gracefully shutdown all threads
        // Note: Ensure that each thread's run method responds to interruption for graceful shutdown
        upstreamInputThread.interrupt();
        upstreamOutputThread.interrupt();
        downstreamInputThread.interrupt();
        downstreamOutputThread.interrupt();
        downstreamProcessorThread.interrupt();
    }

    public void updateState(ServiceState newState) {
        this.state = newState;
    }

    public ServiceState getState() {
        return state;
    }

    // Start the microservice
    public void start() {
        startThreads();
    }

    // Stop the microservice
    public void stop() {
        // Stop the service controller, event loop, etc.
    }

    public void setInputQueue(ChronicleQueue inputQueue) {
        this.inputQueue = inputQueue;
    }

    public void setOutputQueue(ChronicleQueue outputQueue) {
        this.outputQueue = outputQueue;
    }
}
