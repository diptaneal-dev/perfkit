package com.mkt.xac.timeprovider.timezoneprovider;

import java.util.HashMap;
import java.util.Map;

class CompositeTimeZoneManager {
    private Map<String, TimeZoneMappingComponent> mappings = new HashMap<>();

    public void addComponent(String name, TimeZoneMappingComponent component) {
        mappings.put(name, component);
    }

    public TimeZoneMappingComponent getComponent(String name) {
        return mappings.get(name);
    }

    // Methods for storage, recovery, and daily updates...
}
