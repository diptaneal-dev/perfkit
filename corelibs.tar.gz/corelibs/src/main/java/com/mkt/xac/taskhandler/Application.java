package com.mkt.xac.taskhandler;

import com.mkt.xac.config.EnvironmentManager;
import com.mkt.xac.dbclients.DatabaseConnector;
import com.mkt.xac.dbclients.DatabaseService;
import com.mkt.xac.dbclients.exceptions.ConnectionException;
import com.mkt.xac.dbclients.oracledb.OracleDBConnector;
import com.mkt.xac.dbclients.oracledb.OracleDatabaseService;

public class Application {
    public static void main(String[] args) {
        System.setProperty("env.config.path", "src/main/resources/environment.properties");

        DatabaseService dbService = new OracleDatabaseService();
        DatabaseConnector dbConnector = new OracleDBConnector(dbService);

        try {
            final String oracledbConfigPath = EnvironmentManager.getInstance().getVariable("oracledb.config.path");
            dbConnector.configure(oracledbConfigPath);
            dbConnector.connect();
        } catch (ConnectionException e) {
            throw new RuntimeException(e);
        }

        TaskSchedulerService scheduler = new TaskSchedulerService();
        scheduler.configure("src/main/resources/dailyoperations.yaml");
        RequestContext context = new RequestContext(dbService, dbConnector);
        scheduler.scheduleTasks(context);

        Runtime.getRuntime().addShutdownHook(new Thread(scheduler::shutdown));
    }
}
