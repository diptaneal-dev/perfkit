package com.mkt.xac.taskhandler;

public class Application {
    public static void main(String[] args) {
        TaskSchedulerService scheduler = new TaskSchedulerService();
        scheduler.scheduleTasks("src/main/resources/dailyoperations.yaml");
        Runtime.getRuntime().addShutdownHook(new Thread(scheduler::shutdown));
    }
}
