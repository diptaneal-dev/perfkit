package com.mkt.xac.monitoring;

public interface ObservableEvent {
}
