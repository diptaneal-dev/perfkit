package com.mkt.xac.xacservice;

public interface ServiceFactory {
    Microservice createService();
}
