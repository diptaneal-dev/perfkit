package com.mkt.xac.xacservice;

public class ServiceController {
    private Microservice microservice;
    public ServiceController(Microservice service) {
        this.microservice = service;
    }

    // Start the service
    public void startService() {
        microservice.start();
    }

    // Stop the service
    public void stopService() {
        microservice.stop();
    }

}
