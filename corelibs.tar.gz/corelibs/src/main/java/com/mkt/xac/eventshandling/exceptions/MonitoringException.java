package com.mkt.xac.eventshandling.exceptions;

public class MonitoringException extends RuntimeException {

    public MonitoringException(String message) {
        super(message);
    }

    public MonitoringException(String message, Throwable cause) {
        super(message, cause);
    }

    public MonitoringException(Throwable cause) {
        super(cause);
    }
}
