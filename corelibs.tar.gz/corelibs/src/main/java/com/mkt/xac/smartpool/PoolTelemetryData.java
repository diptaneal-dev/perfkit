package com.mkt.xac.smartpool;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.mkt.xac.statsHandling.TelemetryData;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class PoolTelemetryData implements TelemetryData<PoolTelemetryData> {
    private static final Logger LOGGER = LogManager.getLogger(PoolTelemetryData.class);

    private String poolType;
    private long initialPoolSize;
    private Instant poolCreationTime;
    private Instant lastUpdateTime;
    private int outOfPoolCount = 0;
    private int outOfMemoryCount = 0;
    private int resizes = 0;
    private long currentSize = 0;
    private long peakSize = 0;
    private boolean maxSizeBreached = false;

    private long currentPoolUtilization = 0;
    private boolean poolRegisteredWithSmartManager = false;

    private final List<Instant> resizeTimestamps = new ArrayList<>();

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    static {
        OBJECT_MAPPER.configure(SerializationFeature.FAIL_ON_SELF_REFERENCES, false);
        OBJECT_MAPPER.registerModule(new JavaTimeModule());
        OBJECT_MAPPER.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    }

    public PoolTelemetryData() {
        reset();
    }

    public void reset(){
        this.poolType = "";
        this.initialPoolSize = 0;
        this.poolCreationTime = null;
        this.lastUpdateTime = null;
        this.currentSize = 0;
        this.currentPoolUtilization = 0;
        this.outOfPoolCount = 0;
        this.outOfMemoryCount = 0;
        this.peakSize = 0;
        this.maxSizeBreached = false;
        this.resizes = 0;
        this.resizeTimestamps.clear();
    }

    public long getInitialPoolSize() {
        return initialPoolSize;
    }

    public void setInitialPoolSize(long initialPoolSize) {
        this.initialPoolSize = initialPoolSize;
    }

    public long getCurrentPoolUtilization() {
        return currentPoolUtilization;
    }

    public long getPeakSize() {
        return peakSize;
    }

    public void setPeakSize(long peakSize) {
        this.peakSize = peakSize;
    }

    public void incrementCurrentPoolUtilization() {
        this.currentPoolUtilization++;
    }

    public void decrementCurrentPoolUtilization() {
        this.currentPoolUtilization--;
    }

    @Override
    public Instant getCreationTime() {
        return poolCreationTime;
    }

    public long getCurrentSize() {
        return currentSize;
    }

    public String getPoolType() {
        return poolType;
    }

    public void setPoolType(String poolType) {
        this.poolType = poolType;
    }

    public void setCurrentSize(long currentSize) {
        this.currentSize = currentSize;
    }

    @Override
    public Instant getUpdateTime() {
        return lastUpdateTime;
    }

    public void incrementOutOfMemoryCount() {
        this.outOfMemoryCount++;
    }

    public int getOutOfPoolCount() {
        return outOfPoolCount;
    }

    public int getOutOfMemoryCount() {
        return outOfMemoryCount;
    }

    public void incrementOutOfPoolCount() {
        this.outOfPoolCount++;
    }

    public void incrementResizes() {
        this.resizes++;
    }

    public int getResizes() {
        return resizes;
    }

    public void setResizes(int resizes) {
        this.resizes = resizes;
    }

    public boolean isMaxSizeBreached() {
        return maxSizeBreached;
    }

    public void setMaxSizeBreached(boolean maxSizeBreached) {
        this.maxSizeBreached = maxSizeBreached;
    }

    public void addResizeTimestamp(Instant timestamp) {
        this.resizeTimestamps.add(timestamp);
    }

    public boolean isPoolRegisteredWithSmartManager() {
        return poolRegisteredWithSmartManager;
    }

    public void setPoolRegisteredWithSmartManager(boolean poolRegisteredWithSmartManager) {
        this.poolRegisteredWithSmartManager = poolRegisteredWithSmartManager;
    }

    public void updateTimeOfPoolCreation() {
        this.poolCreationTime = Instant.now();
    }

    public void updateLastUpdateTime(){
        this.lastUpdateTime = Instant.now();
    }

    @Override
    public String convertTelemetryDataToJSON() {
        try {
            return OBJECT_MAPPER.writeValueAsString(this);
        } catch (Exception e) {
            LOGGER.error("Failed to convert stats to JSON. Reason: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to convert stats to JSON", e);
        }
    }
}
