package com.mkt.xac.timeprovider;


import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;

import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class MachineTimeProvider implements TimeProvider {
    private final Clock clock;

    public MachineTimeProvider() {
        this.clock = Clock.systemDefaultZone();
    }

    public MachineTimeProvider(ZoneId zoneId) {
        this.clock = Clock.system(zoneId);
    }

    public Instant getCurrentTime() {
        return Instant.now(clock);
    }

    @Override
    public Instant getCurrentTime(ZoneId zoneId) {
        return Instant.now(Clock.system(zoneId));
    }

    public Instant getCurrentTimeInZone(ZoneId zoneId) {
        return Instant.now(Clock.system(zoneId));
    }

    public LocalTime getCurrentLocalTime() {
        return LocalTime.now(clock);
    }

    public String getFormattedCurrentTime(String pattern) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return formatter.format(ZonedDateTime.now(clock));
    }
}

