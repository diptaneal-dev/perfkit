package com.mkt.xac.timeprovider;

import com.mkt.xac.timeprovider.exception.InvalidTimeZoneException;

import java.time.Clock;
import java.time.DateTimeException;
import java.time.Instant;
import java.time.ZoneId;

public class MachineTimeProvider implements TimeProvider {
    private final ZoneId defaultZone = ZoneId.of("UTC");

    public Instant getCurrentTime() {
        return Clock.systemDefaultZone().instant();
    }

    public Instant getCurrentTimeOrUTC(ZoneId zoneId) {
        try {
            return Clock.system(zoneId).instant();
        } catch (DateTimeException e) {
            return Clock.system(defaultZone).instant();
        }
    }

    public Instant getCurrentTime(ZoneId zoneId) {
        try {
            return Clock.system(zoneId).instant();
        } catch (DateTimeException e) {
            throw new InvalidTimeZoneException("Invalid or unrecognized time zone: " + zoneId);
        }
    }

}
