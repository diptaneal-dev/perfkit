package com.mkt.xac.timeprovider;

public class TimeProviderConfig {
    private static TimeProvider timeProvider;

    public static void configureTimeProvider(TimeProvider provider) {
        timeProvider = provider;
    }

    public static TimeProvider getTimeProvider() {
        return timeProvider;
    }
}
