package com.mkt.xac.smartpool.poolexceptions;

public class PoolOutOfObjectsException extends PoolException {
    public PoolOutOfObjectsException(String message) {
        super(message);
    }
}
