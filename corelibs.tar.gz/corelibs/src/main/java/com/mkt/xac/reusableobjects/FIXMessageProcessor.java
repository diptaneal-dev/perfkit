package com.mkt.xac.reusableobjects;

public class FIXMessageProcessor {

    public static void main(String[] args) {
        // Example FIX message
        String rawFIXMessage = "8=FIX.4.2|9=176|35=8|...";

        // Convert to byte array (assuming ASCII encoding)
        byte[] messageBytes = rawFIXMessage.replace('|', '\u0001').getBytes();

        // Get a FIXMessageString instance from TLC
        FIXMessageString fixMessageString = TLC.instance().getFIXMessageString();

        // Set the buffer to the FIX message
        fixMessageString.setBuffer(messageBytes, messageBytes.length);

        // Process the FIX message
        processFIXMessage(fixMessageString);

        // The FIXMessageString instance will be automatically reused in subsequent operations within the same thread
    }

    private static void processFIXMessage(FIXMessageString fixMessage) {
        // Example: Update the message type from '8' to 'D'
        fixMessage.updateMessageType("D");

        // Output the processed message for demonstration
        System.out.println("Processed FIX Message: " + fixMessage);
    }
}
