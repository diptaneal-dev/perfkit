package com.mkt.xac.taskhandler.operationsConfig;

import java.util.List;

public class Operation {
    private String name;
    private String databaseType;
    private Schedule schedule;
    private List<TaskStep> sequence;

    public Schedule getSchedule() {
        return schedule;
    }

    public String getName() {
        return name;
    }

    public String getDatabaseType() {
        return databaseType;
    }

    public List<TaskStep> getSequence() {
        return sequence;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Operation{");
        sb.append("name='").append(name).append('\'');
        sb.append(", databaseType='").append(databaseType).append('\'');
        sb.append(", schedule='").append(schedule).append('\'');
        sb.append(", sequence='").append(sequence).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
