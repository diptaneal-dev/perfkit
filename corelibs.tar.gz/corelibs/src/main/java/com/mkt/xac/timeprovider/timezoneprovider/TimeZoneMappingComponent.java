package com.mkt.xac.timeprovider.timezoneprovider;

import java.time.ZoneId;

interface TimeZoneMappingComponent {
    void addMapping(String key, String timeZone);

    ZoneId getMapping(String key);

    void removeMapping(String key);
}
