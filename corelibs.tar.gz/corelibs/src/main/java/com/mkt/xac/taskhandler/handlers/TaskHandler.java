package com.mkt.xac.taskhandler.handlers;

import com.mkt.xac.taskhandler.RequestContext;

public interface TaskHandler {
    void setNext(TaskHandler taskHandler);

    void handle(RequestContext context);
}
