package com.mkt.xac.reusableobjects;

public interface Reusable<T> {
    void reset();

    T getNext();

    void setNext(T next);
}
