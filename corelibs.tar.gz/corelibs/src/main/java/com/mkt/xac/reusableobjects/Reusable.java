package com.mkt.xac.reusableobjects;

public interface Reusable<T> {

    /**
     * Reset the object to its initial state for reuse.
     */
    void reset();

    /**
     * Get the next reusable object in the pool or chain.
     * @return The next reusable object, or null if this is the last object in the chain.
     */
    T getNext();

    /**
     * Set the next reusable object in the pool or chain.
     * @param next The next reusable object to link to this object.
     */
    void setNext(T next);
}
