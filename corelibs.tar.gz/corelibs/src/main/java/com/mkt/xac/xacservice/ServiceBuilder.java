package com.mkt.xac.xacservice;

import com.mkt.xac.xacservice.processors.XACProcessor;
import net.openhft.chronicle.queue.ChronicleQueue;

public class ServiceBuilder {
    private ChronicleQueue inputQueue;
    private ChronicleQueue outputQueue;
    private XACProcessor<Message> processor;

    public ServiceBuilder withInputQueue(ChronicleQueue inputQueue) {
        this.inputQueue = inputQueue;
        return this;
    }

    public ServiceBuilder withOutputQueue(ChronicleQueue outputQueue) {
        this.outputQueue = outputQueue;
        return this;
    }

    public ServiceBuilder withProcessor(XACProcessor<Message> processor) {
        this.processor = processor;
        return this;
    }

    public Microservice build() {
        Microservice service = new Microservice(processor);
        service.setInputQueue(inputQueue);
        service.setOutputQueue(outputQueue);
        return service;
    }

}

