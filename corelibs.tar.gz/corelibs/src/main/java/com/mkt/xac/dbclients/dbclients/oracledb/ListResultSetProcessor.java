package com.mkt.xac.dbclients.dbclients.oracledb;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ListResultSetProcessor<T> implements ResultSetProcessor<List<T>> {
    private final RowMapper<T> rowMapper;

    public ListResultSetProcessor(RowMapper<T> rowMapper) {
        this.rowMapper = rowMapper;
    }

    @Override
    public List<T> process(ResultSet resultSet) throws SQLException {
        List<T> results = new ArrayList<>();
        while (resultSet.next()) {
            T obj = rowMapper.mapRow(resultSet);
            results.add(obj);
        }
        return results;
    }
}
