package com.mkt.xac.taskhandler;

public class CSVReaderHandler implements TaskHandler {
    private final TaskStep taskStep;

    public CSVReaderHandler(TaskStep taskStep) {
        this.taskStep = taskStep;
    }

    @Override
    public void setNext(TaskHandler taskHandler) {

    }

    @Override
    public void handle(RequestContext context) {

    }
}
