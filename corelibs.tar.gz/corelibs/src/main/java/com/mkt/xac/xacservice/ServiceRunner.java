package com.mkt.xac.xacservice;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ServiceRunner {
    private final ServiceFactory serviceFactory;
    private final ExecutorService executorService;
    private Microservice service;

    // Constructor
    public ServiceRunner(ServiceFactory factory) {
        this.serviceFactory = factory;
        this.executorService = Executors.newSingleThreadExecutor();
    }

    // Start the service
    public void startService() {
        service = serviceFactory.createService();
        executorService.submit(() -> {
            try {
                service.start();
            } catch (Exception e) {
                // Handle exceptions
            }
        });
    }

    // Stop the service
    public void stopService() {
        service.stop();
        executorService.shutdown();
    }

    // Signal handling for graceful shutdown
    public void handleShutdownSignal() {
        // Implementation for handling shutdown signals
    }

    // Monitoring and other functionalities
}
