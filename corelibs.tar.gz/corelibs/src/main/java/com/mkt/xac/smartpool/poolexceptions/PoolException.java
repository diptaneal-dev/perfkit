package com.mkt.xac.smartpool.poolexceptions;

public class PoolException extends Exception {
    public PoolException(String message) {
        super(message);
    }

    public PoolException(String message, Throwable cause) {
        super(message, cause);
    }
}
