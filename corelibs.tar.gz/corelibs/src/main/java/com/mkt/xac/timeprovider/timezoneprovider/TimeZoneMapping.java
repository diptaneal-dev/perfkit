package com.mkt.xac.timeprovider.timezoneprovider;


import java.time.ZoneId;
import java.util.HashMap;
import java.util.Map;

class TimeZoneMapping implements TimeZoneMappingComponent {
    private Map<String, ZoneId> mapping = new HashMap<>();

    @Override
    public void addMapping(String key, String timeZone) {
        mapping.put(key, ZoneId.of(timeZone));
    }

    @Override
    public ZoneId getMapping(String key) {
        return mapping.get(key);
    }

    @Override
    public void removeMapping(String key) {
        mapping.remove(key);
    }
}

