package com.mkt.xac.taskhandler.handlers;

import com.mkt.xac.dbclients.DatabaseService;
import com.mkt.xac.dbclients.exceptions.ConnectionException;
import com.mkt.xac.taskhandler.RequestContext;
import com.mkt.xac.taskhandler.operationsConfig.TaskStep;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;

public class CSVToDatabaseDataTransfer extends AbstractTaskHandler {
    private static final Logger LOGGER = LogManager.getLogger(CSVToDatabaseDataTransfer.class);

    public CSVToDatabaseDataTransfer(TaskStep taskStep) {
        super(taskStep);
    }

    @Override
    public void handle(RequestContext context) {
        DatabaseService dbService = context.getDbService();
        Connection connection = null;
        try {
            connection = context.getDbConnection();
        } catch (SQLException | ConnectionException e) {
            throw new RuntimeException(e);
        }

        final String csvFilePath = taskStep.getFilePath();
        final String delimiter = taskStep.getDelimiter();
        final String insertSQL = taskStep.getQuery();

        int insertCount = 0;
        try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
            CSVFormat csvFormat = CSVFormat.DEFAULT.builder().setDelimiter(delimiter).build();
            final Iterable<CSVRecord> records = csvFormat.parse(br);

            for (CSVRecord record : records) {
                String[] data = new String[record.size()];
                for (int i = 0; i < record.size(); i++) {
                    data[i] = record.get(i);
                }

                if (data.length != taskStep.getExpectedColumnCount()) {
                    LOGGER.error("Invalid data length for line: {}", record);
                    continue;
                }

                boolean success = dbService.executeInsert(connection, insertSQL, data);
                if (success) {
                    insertCount++;
                } else {
                    LOGGER.error("Failed to insert data: {}", Arrays.toString(data));
                }
            }
        } catch (IOException e) {
            LOGGER.error("Error reading CSV file: {}", e.getMessage(), e);
        }

        LOGGER.info("Data insertion completed. Total records inserted: {}", insertCount);
        if (next != null) {
            next.handle(context);
        }
    }
}

