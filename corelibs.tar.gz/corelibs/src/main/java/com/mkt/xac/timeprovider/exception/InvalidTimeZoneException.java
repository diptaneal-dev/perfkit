package com.mkt.xac.timeprovider.exception;

public class InvalidTimeZoneException extends RuntimeException {
    public InvalidTimeZoneException(String message) {
        super(message);
    }
}
