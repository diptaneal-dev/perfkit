package com.mkt.xac.taskhandler;

import java.util.List;

public class TaskScheduler {
    public void scheduleOperations(List<OperationsConfig> operations) {
        for (OperationsConfig operation : operations) {
            // Schedule the operation based on its startTime and frequency
            // At the scheduled time, execute the operation
            executeOperation(operation);
        }
    }

    private void executeOperation(OperationsConfig operation) {
        RequestContext context = new RequestContext();
        // Set up the context (e.g., database connection, configuration data)

        TaskHandler chain = OperationChainBuilder.buildChain(operation.getSequence());
        chain.handle(context);
    }
}
