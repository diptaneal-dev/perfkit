package com.mkt.xac.monitoring;

import com.mkt.xac.eventshandling.DynamicEvent;
import com.mkt.xac.eventshandling.EventType;

public interface Observer<E extends EventType, S> {
    void update(DynamicEvent<S, E> event);
}

