package com.mkt.xac.dbclients;

public interface DataWriter<T> {
    void write(T data);
}
