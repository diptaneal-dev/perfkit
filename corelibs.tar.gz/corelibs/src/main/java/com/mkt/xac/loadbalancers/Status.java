package com.mkt.xac.loadbalancers;

public interface Status {
    boolean isHealthy();
    // Additional methods related to node status if needed
}
