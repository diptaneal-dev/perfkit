package com.mkt.xac.config;

public interface ApplicationConfig {
    void loadConfigFromFile(String filePath);

    void loadConfigFromString(String yamlString);
}
