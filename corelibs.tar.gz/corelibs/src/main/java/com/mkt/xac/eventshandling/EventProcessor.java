package com.mkt.xac.eventshandling;

public interface EventProcessor<E> {
    void process(E event);
}
