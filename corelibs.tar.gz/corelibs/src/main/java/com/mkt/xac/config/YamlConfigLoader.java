package com.mkt.xac.config;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * A utility class for loading YAML configurations.
 */
public class YamlConfigLoader implements ConfigLoader {
    protected static final Logger LOGGER = LogManager.getLogger(YamlConfigLoader.class.getName());

    private YamlConfigLoader() {}

    public static <T extends ApplicationConfig> void loadConfigFromFile(String yamlFilePath, T configInstance) throws IOException {
        try (Stream<String> lines = Files.lines(Paths.get(yamlFilePath))) {
            String yamlContent = lines.collect(Collectors.joining("\n"));
            configInstance.loadConfigFromString(yamlContent);
        }
    }

    public static <T extends ApplicationConfig> void loadConfigFromString(String yamlString, T configInstance) {
        configInstance.loadConfigFromString(yamlString);
    }

    public static <T> T loadConfig(String yamlFilePath, Class<T> targetType) {
        try (InputStream input = Files.newInputStream(Paths.get(yamlFilePath))) {
            ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
            return mapper.readValue(input, targetType);
        } catch (Exception e) {
            LOGGER.error("Error loading configuration", e);
        }
        return null;
    }

    public static Map<String, Object> loadConfigFromString(String yamlContent) {
        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
        try {
            return mapper.readValue(yamlContent, new TypeReference<Map<String, Object>>() {});
        } catch (Exception e) {
            LOGGER.error("Exception thrown while reading config YAML in string format", e);
            return Collections.emptyMap();
        }
    }
}


