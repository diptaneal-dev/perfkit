package com.mkt.xac.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * A utility class for loading YAML configurations.
 */
public class YamlConfigLoader implements ConfigLoader {
    protected static final Logger LOGGER = LogManager.getLogger(YamlConfigLoader.class.getName());

    private YamlConfigLoader() {}

    /**
     * Loads configuration from a YAML file.
     *
     * @param yamlFilePath the file path of the YAML file.
     * @param configInstance the instance to populate with loaded data.
     * @throws IOException if reading from the file fails.
     * @param <T> the type of configuration instance.
     */
    public static <T extends ApplicationConfig> void loadConfigFromFile(String yamlFilePath, T configInstance) throws IOException {
        try (Stream<String> lines = Files.lines(Paths.get(yamlFilePath))) {
            String yamlContent = lines.collect(Collectors.joining("\n"));
            configInstance.loadConfigFromString(yamlContent);
        }
    }

    /**
     * Loads configuration from a YAML string.
     *
     * @param yamlString the YAML content as a string.
     * @param configInstance the instance to populate with loaded data.
     * @param <T> the type of configuration instance.
     */
    public static <T extends ApplicationConfig> void loadConfigFromString(String yamlString, T configInstance) {
        configInstance.loadConfigFromString(yamlString);
    }

    /**
     * Loads configuration from a YAML file and returns an instance of the specified type.
     *
     * @param yamlFilePath the file path of the YAML file.
     * @param targetType the class of the type to return.
     * @return an instance of the specified type with loaded data, or null in case of errors.
     * @param <T> the type of configuration instance.
     */
    public static <T> T loadConfig(String yamlFilePath, Class<T> targetType) {
        try (InputStream input = Files.newInputStream(Paths.get(yamlFilePath))) {
            ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
            return mapper.readValue(input, targetType);
        } catch (Exception e) {
            LOGGER.error("Error loading configuration", e);
        }
        return null;
    }
}


