package com.mkt.xac.config.exceptions;

public class EnvironmentManagerInitializationException extends RuntimeException {
    public EnvironmentManagerInitializationException(String message, Throwable cause) {
        super(message, cause);
    }
}
