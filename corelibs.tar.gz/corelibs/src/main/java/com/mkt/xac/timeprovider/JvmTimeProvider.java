package com.mkt.xac.timeprovider;

import com.mkt.xac.timeprovider.exception.InvalidTimeZoneException;
import com.mkt.xac.timeprovider.timezoneprovider.ExchangeTimeZoneService;

import java.time.DateTimeException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class JvmTimeProvider implements TimeProvider {
    private final ZoneId defaultZone = ZoneId.of("UTC");
    private ExchangeTimeZoneService timeZoneService;

    public JvmTimeProvider(ExchangeTimeZoneService timeZoneService) {
        this.timeZoneService = timeZoneService;
    }

    public Instant getCurrentTime() {
        return Instant.now();
    }

    public Instant getCurrentTimeOrUTC(ZoneId zoneId) {
        try {
            return Instant.now().atZone(zoneId).toInstant();
        } catch (DateTimeException e) {
            return Instant.now().atZone(defaultZone).toInstant();
        }
    }

    public Instant getCurrentTime(ZoneId zoneId) {
        try {
            return Instant.now().atZone(zoneId).toInstant();
        } catch (DateTimeException e) {
            throw new InvalidTimeZoneException("Invalid or unrecognized time zone: " + zoneId);
        }
    }

    public Instant getCurrentTime(String exchangeCode) {
        ZoneId zoneId = timeZoneService.getExchangeTimeZone(exchangeCode);
        return ZonedDateTime.now(zoneId).toInstant();
    }

    public String getFormattedCurrentTime(String exchangeCode, String pattern) {
        ZoneId zoneId = timeZoneService.getExchangeTimeZone(exchangeCode);
        ZonedDateTime zonedDateTime = ZonedDateTime.now(zoneId);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return zonedDateTime.format(formatter);
    }
}
