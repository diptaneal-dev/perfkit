package com.mkt.xac.timeprovider;

import com.mkt.xac.timeprovider.exception.InvalidTimeZoneException;

import java.time.*;
import java.time.format.DateTimeFormatter;

public class JvmTimeProvider implements TimeProvider {
    private final ZoneId defaultZone = ZoneId.of("UTC");
    private final ZoneId zoneId;

    public JvmTimeProvider(String timeZoneId) {
        this.zoneId = ZoneId.of(timeZoneId);
    }

    public Instant getCurrentTime() {
        return Instant.now();
    }

    public Instant getCurrentTimeInZone() {
        return ZonedDateTime.now(zoneId).toInstant();
    }

    public LocalTime getCurrentLocalTime() {
        return ZonedDateTime.now(zoneId).toLocalTime();
    }

    public String getFormattedCurrentTime(String pattern) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern).withZone(zoneId);
        return formatter.format(Instant.now());
    }

    public Instant getCurrentTimeOrUTC(ZoneId zoneId) {
        try {
            return Instant.now().atZone(zoneId).toInstant();
        } catch (DateTimeException e) {
            return Instant.now().atZone(defaultZone).toInstant();
        }
    }

    public Instant getCurrentTime(ZoneId zoneId) {
        try {
            return Instant.now().atZone(zoneId).toInstant();
        } catch (DateTimeException e) {
            throw new InvalidTimeZoneException("Invalid or unrecognized time zone: " + zoneId);
        }
    }
}
