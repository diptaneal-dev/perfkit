package com.mkt.xac.eventshandling;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.mkt.xac.statsHandling.TelemetryData;

import java.util.concurrent.*;

public class EventPublisherService<E> implements EventPublisher<E>, Runnable {
    private static final Logger LOGGER = LogManager.getLogger(EventPublisherService.class);

    private final BlockingQueue<E> eventQueue = new LinkedBlockingQueue<>();
    private final EventProcessor<E> eventProcessor;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile boolean running = true;

    public EventPublisherService(EventProcessor<E> processor) {
        this.eventProcessor = processor;
        executor.submit(this);
    }

    @Override
    public void publish(E event) {
        if (!running) {
            LOGGER.error("Publishing event {} failed: Publisher is not running", event);
            return;
        }

        if (event instanceof TelemetryData) {
            TelemetryData telemetryData = (TelemetryData) event;
            LOGGER.info("Publishing telemetry data {}", telemetryData.convertTelemetryDataToJSON());
        } else {
            LOGGER.info("Publishing raw telemetry data {}", event);
        }

        if (!eventQueue.offer(event)) {
            LOGGER.error("Publishing telemetry data {} failed: Queue offer failed", event);
        }
    }

    @Override
    public void run() {
        try {
            while (running && !Thread.currentThread().isInterrupted()) {
                E event = eventQueue.take();
                eventProcessor.process(event);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            cleanup();
            executor.shutdown();
        }
    }

    public void shutdown() {
        running = false;
        executor.shutdownNow();
        try {
            if (!executor.awaitTermination(60, TimeUnit.SECONDS)) {
                LOGGER.warn("Executor did not terminate in the specified time.");
                executor.shutdownNow();
            }
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            executor.shutdownNow();
        }
    }

    private void cleanup() {
        while (!eventQueue.isEmpty()) {
            E event = eventQueue.poll();
            if (event != null) {
                eventProcessor.process(event);
            }
        }
    }
}

