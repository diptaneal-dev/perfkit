package com.mkt.xac.taskhandler;

import com.mkt.xac.taskhandler.handlers.*;
import com.mkt.xac.taskhandler.operationsConfig.TaskStep;

import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OperationChainBuilder {
    private static final Map<String, String> handlerMappings;

    // this is for dynamic handlers
    // Example: handlerMappings.put("CustomTask", "com.mkt.xac.taskhandler.handlers.CustomTaskHandler");
    static {
        handlerMappings = new HashMap<>();
    }

    public static TaskHandler buildChain(List<TaskStep> steps) {
        TaskHandler first = null, prev = null;

        for (TaskStep step : steps) {
            TaskHandler handler = createHandler(step);
            if (handler == null) continue;

            if (first == null) {
                first = handler;
            }
            if (prev != null) {
                prev.setNext(handler);
            }
            prev = handler;
        }
        return first;
    }

    private static TaskHandler createHandler(TaskStep step) {
        switch (step.getStep()) {
            case "CheckTableExistence":
                return new CheckTableExistenceHandler(step);
            case "DeleteRecords":
                return new DeleteRecordsHandler(step);
            case "ReadCSVAndInsertData":
                return new CSVToDatabaseDataTransfer(step);
            case "InsertData":
                return new DataInsertHandler(step);
            case "ReadCSV":
                return new CSVReadHandler(step);
            default:
                return createDynamicHandler(step);
        }
    }

    private static TaskHandler createDynamicHandler(TaskStep step) {
        String handlerClassName = handlerMappings.get(step.getStep());
        if (handlerClassName == null) {
            return null;
        }

        try {
            Class<?> handlerClass = Class.forName(handlerClassName);
            Constructor<?> constructor = handlerClass.getConstructor(TaskStep.class);
            return (TaskHandler) constructor.newInstance(step);
        } catch (Exception e) {
            throw new RuntimeException("Error creating dynamic handler for step: " + step.getStep(), e);
        }
    }
}

