package com.mkt.xac.taskhandler;

public class OperationChainBuilder {
    public static TaskHandler buildChain(OperationsConfig config) {
        TaskHandler first = null, prev = null;

        for (TaskStep step : config.getSteps()) {
            TaskHandler handler = createHandler(step);
            if (first == null) {
                first = handler;
            }
            if (prev != null) {
                prev.setNext(handler);
            }
            prev = handler;
        }

        return first;
    }

    private static TaskHandler createHandler(TaskStep step) {
        switch (step.getStep()) {
            case "CheckTableExistence":
                return new CheckTableExistenceHandler(step);
            case "DeleteRecords":
                return new DeleteRecordsHandler(step);
            case "ReadCSV":
                return new CSVReaderHandler(step);
            case "InsertData":
                return new DataInsertHandler(step);
            default:
                return null;
        }
    }
}
