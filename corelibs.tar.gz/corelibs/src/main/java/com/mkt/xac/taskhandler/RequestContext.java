package com.mkt.xac.taskhandler;

import com.mkt.xac.config.EnvironmentManager;
import com.mkt.xac.dbclients.dbclients.exceptions.ConnectionException;
import com.mkt.xac.dbclients.dbclients.oracledb.OracleDBConnector;
import com.mkt.xac.dbclients.dbclients.oracledb.OracleDatabaseService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class RequestContext {
    private static final Logger LOGGER = LogManager.getLogger(RequestContext.class);

    private OracleDatabaseService dbService;
    private OracleDBConnector dbConnector;
    private OperationsConfig config;
    private Map<String, Object> data = new HashMap<>();

    public RequestContext() {
        this.dbService = new OracleDatabaseService();
        this.dbConnector = new OracleDBConnector(dbService);
        setupDatabaseConnection();
    }

    private void setupDatabaseConnection() {
        try {
            final String oracledbConfigPath = EnvironmentManager.getInstance().getVariable("oracledb.config.path");
            dbConnector.configure(oracledbConfigPath);
            dbConnector.connect();
        } catch (ConnectionException e) {
            LOGGER.error("Error while connecting to the database: {}", e.getMessage(), e);
        }
    }

    public OracleDatabaseService getDbService() {
        return dbService;
    }

    public Connection getDbConnection() throws SQLException, ConnectionException {
        return dbConnector.getConnection();
    }

    public OperationsConfig getConfig() {
        return config;
    }

    public void setConfig(OperationsConfig config) {
        this.config = config;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void disconnectDatabase() {
        dbConnector.disconnect();
    }
}
