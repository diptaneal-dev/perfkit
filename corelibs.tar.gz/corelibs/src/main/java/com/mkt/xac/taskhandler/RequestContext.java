package com.mkt.xac.taskhandler;

import com.mkt.xac.dbclients.DatabaseConnector;
import com.mkt.xac.dbclients.DatabaseService;
import com.mkt.xac.dbclients.exceptions.ConnectionException;
import com.mkt.xac.taskhandler.operationsConfig.OperationsConfig;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class RequestContext {
    private DatabaseService dbService;
    private DatabaseConnector dbConnector;
    private OperationsConfig config;
    private Map<String, Object> data = new HashMap<>();

    public RequestContext(DatabaseService dbService, DatabaseConnector dbConnector) {
        this.dbService = dbService;
        this.dbConnector = dbConnector;
    }

    public DatabaseService getDbService() {
        return dbService;
    }

    public Connection getDbConnection() throws SQLException, ConnectionException {
        return dbConnector.getConnection();
    }

    public OperationsConfig getConfig() {
        return config;
    }

    public void setConfig(OperationsConfig config) {
        this.config = config;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void disconnectDatabase() {
        dbConnector.disconnect();
    }
}
