package com.mkt.xac.loadbalancers;

public interface LoadMetrics {
    int getRequestsPerSecond();
    // Additional methods to provide load metrics if needed
}
