package com.mkt.xac.timeprovider.timezoneprovider;

import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

class CompositeTimeZoneMapping implements TimeZoneMappingComponent {
    private List<TimeZoneMappingComponent> childMappings = new ArrayList<>();

    public void addComponent(TimeZoneMappingComponent component) {
        childMappings.add(component);
    }

    @Override
    public void addMapping(String key, String timeZone) {
        childMappings.forEach(child -> child.addMapping(key, timeZone));
    }

    @Override
    public ZoneId getMapping(String key) {
        for (TimeZoneMappingComponent child : childMappings) {
            ZoneId zoneId = child.getMapping(key);
            if (zoneId != null) {
                return zoneId;
            }
        }
        return null; // or throw an exception
    }

    @Override
    public void removeMapping(String key) {
        childMappings.forEach(child -> child.removeMapping(key));
    }
}
