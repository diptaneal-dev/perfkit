package com.mkt.xac.taskhandler.handlers;

import com.mkt.xac.taskhandler.RequestContext;
import com.mkt.xac.taskhandler.operationsConfig.TaskStep;

public abstract class AbstractTaskHandler implements TaskHandler {
    protected TaskHandler next;
    protected final TaskStep taskStep;

    public AbstractTaskHandler(TaskStep taskStep) {
        this.taskStep = taskStep;
    }

    @Override
    public void setNext(TaskHandler handler) {
        this.next = handler;
    }

    protected void passToNext(RequestContext context) {
        if (next != null) {
            next.handle(context);
        }
    }

    @Override
    public abstract void handle(RequestContext context);
}
