package com.mkt.xac.taskhandler.handlers;

import java.sql.SQLException;

import com.mkt.xac.dbclients.DatabaseService;
import com.mkt.xac.dbclients.exceptions.ConnectionException;
import com.mkt.xac.taskhandler.RequestContext;
import com.mkt.xac.taskhandler.operationsConfig.TaskStep;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

public class DeleteRecordsHandler extends AbstractTaskHandler {
    private static final Logger LOGGER = LogManager.getLogger(DeleteRecordsHandler.class);

    public DeleteRecordsHandler(TaskStep taskStep) {
        super(taskStep);
    }

    @Override
    public void handle(RequestContext context) {
        DatabaseService dbService = context.getDbService();
        final String deleteSQL = taskStep.getQuery();

        try {
            dbService.executeUpdate(context.getDbConnection(), deleteSQL, new Object[]{});
            LOGGER.info("Records deleted successfully using query: {}", deleteSQL);
        } catch (SQLException | ConnectionException e) {
            LOGGER.error("SQL Exception in DeleteRecordsHandler: {}", e.getMessage(), e);
        }

        if (next != null) {
            LOGGER.info("Class Name {}", next.getClass().getCanonicalName());
            next.handle(context);
        }
    }
}


