package com.mkt.xac.reusableobjects;

public class FIXMessageParsingException extends Exception {

    public FIXMessageParsingException(String message) {
        super(message);
    }

    public FIXMessageParsingException(String message, Throwable cause) {
        super(message, cause);
    }
}
