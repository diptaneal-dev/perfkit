package com.mkt.xac.reusableobjects;

@SuppressWarnings("squid:S116")
public class FIXMessageString implements Reusable<FIXMessageString> {
    private byte[] _bytes;
    private int _len;
    private int _hash;
    private FIXMessageString _next = null;
    private static final byte soh = 0x01; // SOH character in FIX protocol
    private static final byte[] VERSION_TAG_BYTES = "8=".getBytes();
    private static final byte[] MESSAGE_TYPE_TAG_BYTES = "35=".getBytes();


    public FIXMessageString() {
        _bytes = new byte[SizeConstants.DEFAULT_STRING_LENGTH];
    }

    public void setBuffer(byte[] buf, int len) {
        _bytes = buf;
        _len = len;
        _hash = 0; // Reset hash as the content has changed
    }

    /**
     * Efficient method to update the FIX version.
     * @param newVersion New FIX version as a string (e.g., "FIX.4.4").
     */
    public void updateFIXVersion(String newVersion) throws FIXMessageParsingException {
        int startIndex = indexOf(VERSION_TAG_BYTES);
        if (startIndex < 0) {
            throw new FIXMessageParsingException("FIX version tag (8=) not found in the message.");
        }

        int endIndex = indexOf(startIndex, soh);
        if (endIndex < 0) {
            throw new FIXMessageParsingException("End of FIX version value not found in the message.");
        }
        replace(startIndex + VERSION_TAG_BYTES.length, endIndex, newVersion.getBytes());
    }

    /**
     * Finds the index of a byte array within this ReusableString.
     * @param pattern The byte array to find.
     * @return The start index of the pattern, or -1 if not found.
     */
    private int indexOf(byte[] pattern) {
        for (int i = 0; i <= _len - pattern.length; i++) {
            if (startsWith(pattern, i)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Checks if the ReusableString starts with the given pattern at the specified index.
     * @param pattern The pattern to check.
     * @param offset The offset to start checking from.
     * @return True if the pattern is found at the offset.
     */
    private boolean startsWith(byte[] pattern, int offset) {
        if (pattern.length + offset > _len) {
            return false;
        }

        for (int i = 0; i < pattern.length; i++) {
            if (_bytes[offset + i] != pattern[i]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Finds the index of a byte starting from a given index.
     * @param fromIndex The index to start the search from.
     * @param b The byte to find.
     * @return The index of the byte, or -1 if not found.
     */
    private int indexOf(int fromIndex, byte b) {
        for (int i = fromIndex; i < _len; i++) {
            if (_bytes[i] == b) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Replaces part of the byte array with another byte array.
     * @param start The starting index of the replacement.
     * @param end The ending index of the replacement.
     * @param replacement The byte array to replace with.
     */
    private void replace(int start, int end, byte[] replacement) {
        int replacementLength = replacement.length;
        int newLength = _len - (end - start) + replacementLength;
        ensureCapacity(newLength);

        // Move the part of the array that comes after the replaced section
        System.arraycopy(_bytes, end, _bytes, start + replacementLength, _len - end);

        // Insert the replacement bytes
        System.arraycopy(replacement, 0, _bytes, start, replacementLength);
        _len = newLength;
    }

    /**
     * Ensures that the underlying byte array can accommodate the specified capacity.
     * If not, it increases the array size.
     * @param minimumCapacity The desired minimum capacity.
     */
    public void ensureCapacity(int minimumCapacity) {
        if (minimumCapacity > _bytes.length) {
            int newCapacity = Math.max(_bytes.length * 2, minimumCapacity);
            byte[] newArray = new byte[newCapacity];
            System.arraycopy(_bytes, 0, newArray, 0, _len);
            _bytes = newArray;
        }
    }

    /**
     * Efficient method to update the message type.
     * @param newType New message type as a string.
     */
    public void updateMessageType(String newType) {
        int startIndex = indexOf(MESSAGE_TYPE_TAG_BYTES);
        if (startIndex < 0) {
            // Message type tag not found
            return;
        }

        int endIndex = indexOf(startIndex + MESSAGE_TYPE_TAG_BYTES.length, soh);
        if (endIndex < 0) {
            // End of message type value not found
            return;
        }
        replace(startIndex + MESSAGE_TYPE_TAG_BYTES.length, endIndex, newType.getBytes());
    }

    @Override
    public FIXMessageString getNext() {
        return _next;
    }

    @Override
    public void setNext(FIXMessageString next) {
        _next = next;
    }

    @Override
    public void reset() {
        _len = 0;
        _hash = 0;
    }
}
