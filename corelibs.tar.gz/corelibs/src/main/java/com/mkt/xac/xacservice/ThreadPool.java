package com.mkt.xac.xacservice;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class ThreadPool {
    private ExecutorService executorService;
    private final int corePoolSize;
    private final int maxPoolSize;
    private AtomicBoolean isRunning;

    // Constructor
    public ThreadPool(int corePoolSize, int maxPoolSize) {
        this.corePoolSize = corePoolSize;
        this.maxPoolSize = maxPoolSize;
        this.isRunning = new AtomicBoolean(false);
    }

    // Method to start the thread pool
    public void start() {
        if (isRunning.compareAndSet(false, true)) {
            // Using a CachedThreadPool as an example. You might want to use ThreadPoolExecutor for more control.
            this.executorService = Executors.newCachedThreadPool();
        }
    }

    // Method to submit tasks to the thread pool
    public void submit(Runnable task) {
        if (isRunning.get()) {
            executorService.submit(task);
        }
    }

    // Method to stop the thread pool
    public void stop() {
        if (isRunning.compareAndSet(true, false)) {
            try {
                executorService.shutdown();
                if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                    executorService.shutdownNow();
                }
            } catch (InterruptedException e) {
                executorService.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }
}
