package com.mkt.xac.taskhandler;

import java.util.List;

public class OperationsConfig {
    private List<Operation> operations;

    public List<Operation> getOperations() {
        return operations;
    }

    public void setOperations(List<Operation> operations) {
        this.operations = operations;
    }

    public OperationsConfig getSequence() {
        return null;
    }

    public TaskStep[] getSteps() {
        return null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("OperationsConfig{");
        if (operations != null) {
            sb.append("operations=");
            operations.forEach(operation -> sb.append(operation.toString()).append(", "));
        }
        sb.append('}');
        return sb.toString();
    }
}
