package com.mkt.xac.monitoring;

import com.mkt.xac.config.EnvironmentManager;
import com.mkt.xac.dbclients.dbclients.DatabaseClient;
import com.mkt.xac.dbclients.dbclients.exceptions.ConnectionException;
import com.mkt.xac.dbclients.dbclients.infuxdb.InfluxDBClient;
import com.mkt.xac.eventshandling.EventProcessor;
import com.mkt.xac.eventshandling.EventPublisher;
import com.mkt.xac.eventshandling.EventType;
import com.mkt.xac.eventshandling.exceptions.MonitoringException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class AbstractMonitor<E extends EventType, S, T> implements Observer<E, S> {
    protected static final Logger LOGGER = LogManager.getLogger(AbstractMonitor.class);
    protected EventPublisher<T> eventPublisher;
    protected EventProcessor<T> eventProcessor;
    protected DatabaseClient databaseClient;

    protected AbstractMonitor() {
        try {
            initializeInfluxDBConnection();
            this.eventProcessor = createEventProcessor(databaseClient);
            this.eventPublisher = createEventPublisher();
        } catch (Exception e) {
            throw new MonitoringException("Error initializing monitor", e);
        }
    }

    private void initializeInfluxDBConnection() throws MonitoringException {
        final String influxdbConfigPath = EnvironmentManager.getInstance().getVariable("influxdb.config.path");
        try {
            databaseClient = new InfluxDBClient(influxdbConfigPath);
        } catch (Exception e) {
            throw new MonitoringException("Failed to initialize InfluxDB client", e);
        }
    }

    public void connectToDatabase() throws MonitoringException {
        try {
            databaseClient.connect();
        } catch (ConnectionException e) {
            LOGGER.error("InfluxDB Connection not successful: {}", e.getMessage(), e);
            throw new MonitoringException("Failed to establish InfluxDB connection", e);
        }
    }

    protected abstract EventProcessor<T> createEventProcessor(DatabaseClient databaseClient);

    protected abstract EventPublisher<T>  createEventPublisher();

    protected void publishTelemetryData(T data) {
        if (eventPublisher == null) {
            throw new IllegalStateException("EventPublisher is not initialized!");
        }
        eventPublisher.publish(data);
    }

    public void shutdown() {
        if (databaseClient != null) {
            try {
                databaseClient.disconnect();
            } catch (Exception e) {
                LOGGER.error("Error disconnecting InfluxDB", e);
            }
        }
        LOGGER.info("Monitor shutdown completed");
    }
}

