package com.mkt.xac.dbclients.infuxdb;

import com.influxdb.client.write.Point;
import com.mkt.xac.dbclients.DataWriter;

public class InfluxDBDataWriter implements DataWriter<Point> {
    private final InfluxDBConnector influxDBConnector;

    public InfluxDBDataWriter(InfluxDBConnector influxDBConnector) {
        this.influxDBConnector = influxDBConnector;
    }

    public void write(Point point) {
        influxDBConnector.write(point);
    }
}
