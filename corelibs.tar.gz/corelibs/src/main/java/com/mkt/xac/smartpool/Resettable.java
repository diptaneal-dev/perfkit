package com.mkt.xac.smartpool;

public interface Resettable {
    void reset();
}
