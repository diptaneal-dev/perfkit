package com.mkt.xac.config;

public interface ConfigLoader {

}
