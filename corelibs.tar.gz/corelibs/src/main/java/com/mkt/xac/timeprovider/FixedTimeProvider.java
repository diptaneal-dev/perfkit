package com.mkt.xac.timeprovider;

import com.mkt.xac.timeprovider.exception.InvalidTimeZoneException;

import java.time.DateTimeException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class FixedTimeProvider implements TimeProvider {
    private final Instant fixedTime;

    public FixedTimeProvider(Instant fixedTime) {
        this.fixedTime = fixedTime;
    }

    @Override
    public Instant getCurrentTime() {
        return fixedTime;
    }

    @Override
    public Instant getCurrentTime(ZoneId zoneId) {
        try {
            return ZonedDateTime.ofInstant(fixedTime, zoneId).toInstant();
        } catch (DateTimeException e) {
            throw new InvalidTimeZoneException("Invalid or unrecognized time zone: " + zoneId);
        }
    }
}
