package com.mkt.xac.timeprovider;

import com.mkt.xac.timeprovider.exception.InvalidTimeZoneException;

import java.time.DateTimeException;
import java.time.Instant;
import java.time.ZoneId;

import java.time.Clock;

public class FixedTimeProvider implements TimeProvider {
    private Clock fixedClock;
    private final ZoneId defaultZone = ZoneId.of("UTC");

    public FixedTimeProvider(Instant fixedTime) {
        this.fixedClock = Clock.fixed(fixedTime, defaultZone);
    }

    public void setFixedTimeAndZone(Instant fixedTime, ZoneId zoneId) {
        this.fixedClock = Clock.fixed(fixedTime, zoneId);
    }

    @Override
    public Instant getCurrentTime() {
        return fixedClock.instant();
    }

    @Override
    public Instant getCurrentTime(ZoneId zoneId) {
        try {
            return Instant.now(Clock.fixed(fixedClock.instant(), zoneId));
        } catch (DateTimeException e) {
            throw new InvalidTimeZoneException("Invalid or unrecognized time zone: " + zoneId);
        }
    }
}

