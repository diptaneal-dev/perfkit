package com.mkt.xac.taskhandler.handlers;

import com.mkt.xac.taskhandler.RequestContext;
import com.mkt.xac.taskhandler.operationsConfig.TaskStep;

public class DataInsertHandler extends AbstractTaskHandler {
    public DataInsertHandler(TaskStep taskStep) {
        super(taskStep);
    }

    @Override
    public void handle(RequestContext context) {

    }
}
