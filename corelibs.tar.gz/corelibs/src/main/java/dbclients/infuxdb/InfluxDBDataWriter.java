package dbclients.infuxdb;

import com.influxdb.client.write.Point;
import dbclients.DataWriter;

public class InfluxDBDataWriter implements DataWriter<Point> {
    private final InfluxDBConnector influxDBConnector;

    public InfluxDBDataWriter(InfluxDBConnector influxDBConnector) {
        this.influxDBConnector = influxDBConnector;
    }

    public void write(Point point) {
        influxDBConnector.write(point);
    }
}
