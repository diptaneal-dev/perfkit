package dbclients.infuxdb;

import com.influxdb.client.write.Point;
import dbclients.DatabaseClient;
import dbclients.exceptions.ConnectionException;

public class InfluxDBClient implements DatabaseClient {
    private final InfluxDBConnector influxDBConnector;

    public InfluxDBClient(String configPath) {
        this.influxDBConnector = new InfluxDBConnector(configPath);
    }

    @Override
    public void connect() throws ConnectionException {
        influxDBConnector.connect();
    }

    @Override
    public void disconnect() throws ConnectionException {
        influxDBConnector.disconnect();
    }

    @Override
    public boolean isConnected() {
        return influxDBConnector.isConnected();
    }

    @Override
    public void writeData(Point data) {
        influxDBConnector.write(data);
    }
}
