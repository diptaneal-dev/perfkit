package dbclients.infuxdb;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.influxdb.client.InfluxDBClient;
import com.influxdb.client.InfluxDBClientFactory;
import com.influxdb.client.WriteApi;
import com.influxdb.client.write.Point;
import config.EnvironmentManager;
import dbclients.AbstractDatabaseConnector;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import security.CryptoUtils;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.nio.file.Files;
import java.nio.file.Paths;

public class InfluxDBConnector extends AbstractDatabaseConnector {
    private static final Logger LOGGER = LogManager.getLogger(InfluxDBConnector.class);

    private InfluxDBClient client;
    private String token;
    private String bucket;
    private String username;
    private String secretValue;
    private String organization;

    public InfluxDBConnector(String configFilePath) {
        super(null, new HashMap<>());
        readConfig(configFilePath);
    }

    private void readConfig(String configFile) {
        try {
            ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
            Map<String, Object> yamlConfig = mapper.readValue(Files.newInputStream(Paths.get(configFile)), Map.class);
            Map<String, String> influxDBConfig = (Map<String, String>) yamlConfig.get("influxDBConfig");

            this.url = influxDBConfig.get("url");
            this.token = resolveEnvironmentVariable(influxDBConfig.get("token"));
            this.bucket = influxDBConfig.get("bucket");
            this.organization = influxDBConfig.get("organization");
            this.username = resolveEnvironmentVariable(influxDBConfig.get("username"));
            final String encodedKey = resolveEnvironmentVariable(influxDBConfig.get("encryptionKey"));
            final byte[] key = Base64.getDecoder().decode(encodedKey);
            final String secretPass = resolveEnvironmentVariable(influxDBConfig.get("secretValue"));
            this.secretValue = CryptoUtils.decrypt(secretPass, key);
        } catch (Exception e) {
            LOGGER.error("Reading config Failed with exception {}", e.getMessage());
        }
    }

    private String resolveEnvironmentVariable(String value) {
        if (value != null && value.startsWith("${") && value.endsWith("}")) {
            return EnvironmentManager.getInstance().getVariable(value.substring(2, value.length() - 1));
        }
        return value;
    }

    @Override
    public void configure() {
    }

    @Override
    public void connect() {
        try {
            configure();
            client = InfluxDBClientFactory.create(url, token.toCharArray());
        } catch (Exception e) {
            LOGGER.error("Connection Failed with InfluxDB with exception {}", e.getMessage());
        }
    }

    @Override
    public void disconnect() {
        if (client != null) {
            try {
                client.close();
            } catch (Exception e) {
                LOGGER.error("Connection Close Failed with InfluxDB with exception {}", e.getMessage());
            }
        }
    }

    @Override
    public void executeQuery(String query) {

    }

    @Override
    public void write(Point point) {
        if (client == null) {
            throw new IllegalStateException("InfluxDB client not initialized. Call connect() first.");
        }

        try (WriteApi writeApi = client.makeWriteApi()) {
            writeApi.writePoint(bucket, organization, point);
        } catch (Exception e) {
            LOGGER.error("Write Failed with InfluxDB with exception {}", e.getMessage());
        }
    }

    @Override
    public String toString() {
        return "InfluxDBConnector{" +
                "url='" + url + '\'' +
                ", bucket='" + bucket + '\'' +
                ", organization='" + organization + '\'' +
                '}';
    }

    protected InfluxDBClient createClient(String url, char[] token) {
        return InfluxDBClientFactory.create(url, token);
    }

    public InfluxDBClient getClient() {
        return client;
    }
}


