package dbclients;

import com.influxdb.client.write.Point;

public interface DatabaseConnector {
    void connect();
    void disconnect();
    void write(Point point);
}
