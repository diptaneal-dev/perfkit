package dbclients;

import dbclients.exceptions.ConnectionException;

public interface DatabaseConnector {
    void connect() throws ConnectionException;
    void disconnect();
}
