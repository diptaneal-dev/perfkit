package dbclients;

import java.util.Map;

public abstract class AbstractDatabaseConnector implements DatabaseConnector {
    protected String url;
    protected Map<String, String> configParameters;

    public AbstractDatabaseConnector(String url, Map<String, String> configParameters) {
        this.url = url;
        this.configParameters = configParameters;
    }

    public abstract void configure();

    public abstract void connect();
    public abstract void disconnect();
    public abstract void executeQuery(String query);

    @Override
    public String toString() {
        return "AbstractDatabaseConnector{" +
                "url='" + url + '\'' +
                ", configParameters=" + configParameters +
                '}';
    }
}
