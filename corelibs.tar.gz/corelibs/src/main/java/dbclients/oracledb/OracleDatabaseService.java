package dbclients.oracledb;

import dbclients.DatabaseService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.*;

public class OracleDatabaseService implements DatabaseService {
    private static final Logger LOGGER = LogManager.getLogger(OracleDatabaseService.class);

    public <T> T executeQuery(Connection connection, String query, ResultSetProcessor<T> processor) throws SQLException {
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            return processor.process(rs);
        }
    }

    public boolean executeInsert(Connection connection, String insertSQL, Object[] values) {
        try (PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {
            for (int i = 0; i < values.length; i++) {
                preparedStatement.setObject(i + 1, values[i]);
            }

            int rowsAffected = preparedStatement.executeUpdate();
            LOGGER.debug("{} row(s) inserted successfully.", rowsAffected);
            return true;
        } catch (SQLException e) {
            LOGGER.error("Insert failed: {}", e.getMessage(), e);
            return false;
        }
    }
    public boolean executeUpdate(Connection connection, String updateSQL, Object[] values) {
        try (PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {
            for (int i = 0; i < values.length; i++) {
                preparedStatement.setObject(i + 1, values[i]);
            }

            int rowsAffected = preparedStatement.executeUpdate();
            LOGGER.debug("{} row(s) updated successfully.", rowsAffected);
            return true;
        } catch (SQLException e) {
            LOGGER.error("Update failed: {}", e.getMessage(), e);
            return false;
        }
    }

    public boolean executeDelete(Connection connection, String deleteSQL, Object[] values) {
        try (PreparedStatement preparedStatement = connection.prepareStatement(deleteSQL)) {
            for (int i = 0; i < values.length; i++) {
                preparedStatement.setObject(i + 1, values[i]);
            }

            int rowsAffected = preparedStatement.executeUpdate();
            LOGGER.debug("{} row(s) deleted successfully.", rowsAffected);
            return true;
        } catch (SQLException e) {
            LOGGER.error("Delete failed: {}", e.getMessage(), e);
            return false;
        }
    }

    public boolean executeBatch(Connection connection, String[] sqlCommands) {
        try (Statement statement = connection.createStatement()) {
            for (String sql : sqlCommands) {
                statement.addBatch(sql);
            }

            int[] results = statement.executeBatch();
            LOGGER.debug("Batch executed with {} statements.", results.length);
            return true;
        } catch (SQLException e) {
            LOGGER.error("Batch execution failed: {}", e.getMessage(), e);
            return false;
        }
    }
}