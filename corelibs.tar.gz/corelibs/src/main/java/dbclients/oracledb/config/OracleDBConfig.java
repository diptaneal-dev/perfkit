package dbclients.oracledb.config;

import config.PropertyResolver;
import config.ResolveProperty;

public class OracleDBConfig implements PropertyResolver {
    @ResolveProperty
    private String url;
    @ResolveProperty
    private String user;
    @ResolveProperty
    private String password;
    @ResolveProperty
    private String tnsAdminPath;
    @ResolveProperty
    private String tlsProtocolVersion;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTnsAdminPath() {
        return tnsAdminPath;
    }

    public void setTnsAdminPath(String tnsAdminPath) {
        this.tnsAdminPath = tnsAdminPath;
    }

    public String getTlsProtocolVersion() {
        return tlsProtocolVersion;
    }

    public void setTlsProtocolVersion(String tlsProtocolVersion) {
        this.tlsProtocolVersion = tlsProtocolVersion;
    }
}
