package dbclients;

public interface DatabaseService {
}
