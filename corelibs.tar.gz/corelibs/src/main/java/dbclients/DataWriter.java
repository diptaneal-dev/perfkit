package dbclients;

public interface DataWriter<T> {
    void write(T data);
}
