package monitoring;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

public interface Observable<E, S> {
    static final Logger LOGGER = LogManager.getLogger(Observable.class);

    List<Observer<E, S>> getObservers();

    default void addObserver(Observer<E, S> observer) {
        LOGGER.info("Observer registered: " + observer.getClass().getName());
        getObservers().add(observer);
    }

    default void removeObserver(Observer<E, S> observer) {
        LOGGER.info("Observer removed: " + observer.getClass().getName());
        getObservers().remove(observer);
    }

    default void notifyObservers(E event) {
        handleObservableEvent(event, this);
    }

    default void notifyObservers(E event, ObservableEvent eventObject) {
        handleObservableEvent(event, eventObject);
    }

    default void handleObservableEvent(E event, Object eventObject) {
        List<Observer<E, S>> observers = getObservers();
        if (observers.isEmpty()) {
            LOGGER.warn("No observers found to notify for event: " + event);
        } else {
            observers.forEach(observer -> {
                try {
                    observer.update(event, (S) eventObject);
                } catch (Exception e) {
                    LOGGER.error("Error while notifying observer " + observer.getClass().getName(), e);
                }
            });
        }
    }
}
