package monitoring;

import com.influxdb.client.write.Point;
import config.EnvironmentManager;
import dbclients.DataWriter;
import dbclients.exceptions.ConnectionException;
import dbclients.infuxdb.InfluxDBConnector;
import dbclients.infuxdb.InfluxDBDataWriter;
import eventsHandling.EventProcessor;
import eventsHandling.EventPublisher;
import eventsHandling.EventType;
import eventsHandling.exceptions.MonitoringException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class AbstractMonitor<E extends EventType, S, T> implements Observer<E, S> {
    protected static final Logger LOGGER = LogManager.getLogger(AbstractMonitor.class);
    protected InfluxDBConnector influxDBConnector;
    protected DataWriter<Point> dataWriter;
    protected EventPublisher<T> eventPublisher;
    protected EventProcessor<T> eventProcessor;

    protected AbstractMonitor() {
        LOGGER.trace("Monitor is being initialized");
        try {
            initializeInfluxDBConnection();
            initializeDataWriter();
            this.eventProcessor = createEventProcessor();
            this.eventPublisher = createEventPublisher();
        } catch (Exception e) {
            throw new MonitoringException("Error initializing monitor", e);
        }
    }

    private void initializeInfluxDBConnection() throws MonitoringException {
        String influxdbConfigPath = EnvironmentManager.getInstance().getVariable("influxdb.config.path");
        influxDBConnector = new InfluxDBConnector(influxdbConfigPath);
        try {
            influxDBConnector.connect();
        } catch (ConnectionException e) {
            LOGGER.error("InfluxDB Connection not successful: {}", e.getMessage(), e);
            throw new MonitoringException("Failed to establish InfluxDB connection", e);
        }
    }

    private void initializeDataWriter() throws MonitoringException {
        try {
            dataWriter = new InfluxDBDataWriter(influxDBConnector);
        } catch (Exception e) {
            LOGGER.error("Error initializing data writer: {}", e.getMessage(), e);
            throw new MonitoringException("Failed to initialize data writer", e);
        }
    }

    protected abstract EventProcessor<T> createEventProcessor();

    protected abstract EventPublisher<T>  createEventPublisher();

    protected void publishTelemetryData(T data) {
        if (eventPublisher == null) {
            throw new IllegalStateException("EventPublisher is not initialized!");
        }
        eventPublisher.publish(data);
    }

    public void shutdown() {
        if (influxDBConnector != null) {
            try {
                influxDBConnector.disconnect();
            } catch (Exception e) {
                LOGGER.error("Error disconnecting InfluxDB", e);
            }
        }
        LOGGER.info("Monitor shutdown completed");
    }
}

