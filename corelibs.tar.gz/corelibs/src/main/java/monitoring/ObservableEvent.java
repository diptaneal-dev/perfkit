package monitoring;

public interface ObservableEvent {
}
