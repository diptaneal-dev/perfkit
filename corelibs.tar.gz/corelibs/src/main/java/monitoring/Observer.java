package monitoring;

public interface Observer<E, S> {
    void update(E eventType, S subject);
}
