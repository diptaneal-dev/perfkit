package monitoring;

import eventsHandling.DynamicEvent;
import eventsHandling.EventType;

public interface Observer<E extends EventType, S> {
    void update(DynamicEvent<S, E> event);
}

