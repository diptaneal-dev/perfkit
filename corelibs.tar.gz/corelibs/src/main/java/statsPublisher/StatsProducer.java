package statsPublisher;

import stats.Stats;

public interface StatsProducer {
    Stats getMetric();

    void registerWithMediator(StatsPublisherMediator mediator);
}
