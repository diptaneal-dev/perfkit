package xaccache;

public interface CacheNode {
    Object getFromCache(Object key);

    void putToCache(Object key, Object value);

    void removeFromCache(Object key);

    String getCacheName();

    boolean isCacheOpen();

    boolean isCacheClosed();

    int size();

    void close();
}
