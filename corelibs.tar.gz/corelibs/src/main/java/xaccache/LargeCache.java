package xaccache;

import net.openhft.chronicle.map.ChronicleMap;
import net.openhft.chronicle.map.ChronicleMapBuilder;

import java.io.File;

public class LargeCache implements CacheNode {
    private ChronicleMap<Object, Object> chronicleMap;

    LargeCache(String mapName) {
        try {
            this.chronicleMap = ChronicleMapBuilder
                    .of(Object.class, Object.class)
                    .entries(1000)
                    .averageKeySize(2048)
                    .averageValueSize(2048)
                    .name(mapName)
                    .createPersistedTo(new File("maps/" + mapName + ".dat"));
        } catch (Exception e) {
            throw new RuntimeException("Error initializing ChronicleMap", e);
        }
    }

    public String getCacheName() {
        return chronicleMap.name();
    }

    public boolean isCacheOpen() {
        return chronicleMap.isOpen();
    }

    public boolean isCacheClosed() {
        return chronicleMap.isClosed();
    }

    public void putToCache(Object key, Object value) {
        chronicleMap.put(key, value);
    }

    public Object getFromCache(Object key) {
        return chronicleMap.get(key);
    }

    public void removeFromCache(Object key) {
        chronicleMap.remove(key);
    }

    public int size() {
        return chronicleMap.size();
    }

    public void close() {
        chronicleMap.close();
    }
}
