package xaccache;

import loadbalancers.LoadBalancer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class CachePool {
    private static final Logger LOGGER = LogManager.getLogger(CachePool.class);

    private final List<CacheNode> poolOfCaches;
    private final LoadBalancer<CacheNode> loadBalancer;

    public CachePool(int poolSize, String mapNamePrefix, LoadBalancer<CacheNode> loadBalancer) {
        poolOfCaches = new ArrayList<>();
        for (int i = 0; i < poolSize; i++) {
            final String mapName = mapNamePrefix + i;
            poolOfCaches.add(new LargeCache(mapName));
        }

        this.loadBalancer = loadBalancer;
        this.loadBalancer.addNodes(poolOfCaches);
    }

    public List<CacheNode> getPoolOfCaches() {
        return poolOfCaches;
    }

    public void putToCache(Object key, Object value) {
        CacheNode selectedCache = loadBalancer.getNextNode();
        selectedCache.putToCache(key, value);
    }

    public Object getFromCache(Object key) {
        CacheNode selectedCache = loadBalancer.getNextNode();
        return selectedCache.getFromCache(key);
    }

    public void removeFromCache(Object key) {
        CacheNode selectedCache = loadBalancer.getNextNode();
        selectedCache.removeFromCache(key);
    }

    public void close() {
        for (CacheNode cache : poolOfCaches) {
            cache.close();
        }
    }

    public void closeSingleCache(int index) {
        if (index >= 0 && index < poolOfCaches.size()) {
            CacheNode cache = poolOfCaches.get(index);
            cache.close();
        } else {
            LOGGER.error("Invalid cache index");
        }
    }

    public String printCacheState() {
        StringBuilder buffer = new StringBuilder();
        for (CacheNode cache : poolOfCaches) {
            int numberOfRecords = cache.size();
            buffer.append(String.format("Cache %s has numberOfRecords: %s%n", cache.getCacheName(), numberOfRecords));
        }
        return buffer.toString();
    }

}
