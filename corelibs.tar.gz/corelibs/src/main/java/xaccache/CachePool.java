package xaccache;

import loadbalancers.LoadBalancer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class CachePool {
    private static final Logger LOGGER = LogManager.getLogger(CachePool.class);

    private List<LargeCache> cachePool;
    private LoadBalancer<LargeCache> loadBalancer;

    public CachePool(int poolSize, String mapNamePrefix, LoadBalancer<LargeCache> loadBalancer) {
        cachePool = new ArrayList<>();
        for (int i = 0; i < poolSize; i++) {
            final String mapName = mapNamePrefix + i;
            cachePool.add(new LargeCache(mapName));
        }

        this.loadBalancer = loadBalancer;
        this.loadBalancer.addNodes(cachePool);
    }

    public List<LargeCache> getCachePool() {
        return cachePool;
    }

    public void putToCache(Object key, Object value) {
        LargeCache selectedCache = loadBalancer.getNextNode();
        selectedCache.putToCache(key, value);
    }

    public Object getFromCache(Object key) {
        LargeCache selectedCache = loadBalancer.getNextNode();
        return selectedCache.getFromCache(key);
    }

    public void removeFromCache(Object key) {
        LargeCache selectedCache = loadBalancer.getNextNode();
        selectedCache.removeFromCache(key);
    }

    public void close() {
        for (LargeCache cache : cachePool) {
            cache.close();
        }
    }

    public void closeSingleCache(int index) {
        if (index >= 0 && index < cachePool.size()) {
            LargeCache cache = cachePool.get(index);
            cache.close();
            // cachePool.remove(index);
        } else {
            LOGGER.error("Invalid cache index");
        }
    }

    public String printCacheState() {
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < cachePool.size(); i++) {
            LargeCache cache = cachePool.get(i);
            int numberOfRecords = cache.size();
            buffer.append(String.format("Cache %s has numberOfRecords: %s%n", cache.getCacheName(), numberOfRecords));
        }
        LOGGER.info(buffer.toString());
        return buffer.toString();
    }

}
