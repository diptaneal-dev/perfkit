package loadbalancers;

import loadbalancers.algorithms.RoundRobinAlgorithm;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class StickyRoundRobinLoadBalancer<T> extends AbstractLoadBalancer<T> {
    private final RoundRobinAlgorithm<T> roundRobinAlgorithm;
    private final Map<Object, T> stickySessions;

    public StickyRoundRobinLoadBalancer() {
        super(new RoundRobinAlgorithm<>());
        this.roundRobinAlgorithm = (RoundRobinAlgorithm<T>) super.getAlgorithm();
        this.stickySessions = new ConcurrentHashMap<>();
    }

    public StickyRoundRobinLoadBalancer(List<T> nodes) {
        super(nodes, new RoundRobinAlgorithm<>());
        this.roundRobinAlgorithm = (RoundRobinAlgorithm<T>) super.getAlgorithm();
        this.stickySessions = new ConcurrentHashMap<>();
    }

    @Override
    public T getNextNode() {
        Object stickyKey = getStickySessionKey();
        if (stickyKey != null) {
            return stickySessions.computeIfAbsent(stickyKey, k -> roundRobinAlgorithm.getNextNode(getNodes()));
        }

        // Fallback to round-robin for non-sticky requests
        return roundRobinAlgorithm.getNextNode(getNodes());
    }

    @Override
    public T getStickySession(Client client) {
        // Use consistent hashing on client information for stickiness
        Object stickyKey = computeStickyKey(client);
        return stickySessions.get(stickyKey);
    }

    @Override
    public void setStickySession(Client client, T node) {
        // Use consistent hashing on client information for stickiness
        Object stickyKey = computeStickyKey(client);
        stickySessions.put(stickyKey, node);
    }

    private Object computeStickyKey(Client client) {
        // Use consistent hashing on client information (e.g., client ID)
        // You can customize this logic based on your application's requirements
        return client.getClientId();
    }

    private Object getStickySessionKey() {
        // Logic to determine whether a sticky session exists for the current request
        // You can customize this logic based on your application's requirements
        return null;
    }
}
