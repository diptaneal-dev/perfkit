package loadbalancers;

import loadbalancers.algorithms.StickySessionsAlgorithm;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StickySessionsLoadBalancer<T> extends AbstractLoadBalancer<T> {
    private final Map<Client, T> stickySessions;

    public StickySessionsLoadBalancer(List<T> nodes) {
        super(nodes, new StickySessionsAlgorithm<>());
        this.stickySessions = new HashMap<>();
    }

    public T getStickySession(Client client) {
        return stickySessions.get(client);
    }

    public void setStickySession(Client client, T node) {
        stickySessions.put(client, node);
    }
}
