package loadbalancers;

public interface Client {
    String getClientId();
}
