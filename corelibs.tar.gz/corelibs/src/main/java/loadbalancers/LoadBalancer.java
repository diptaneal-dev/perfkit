package loadbalancers;

import loadbalancers.algorithms.Algorithm;

import java.util.List;
import java.util.Map;

public interface LoadBalancer<T> {

    void addNode(T node);

    void removeNode(T node);

    void addNodes(List<T> nodes);

    List<T> getNodes();

    T getNextNode();

    Status getNodeStatus(T node);

    void setNodeStatus(T node, Status status);

    Map<T, Integer> getLoadDistribution();

    LoadMetrics getLoadMetrics(T node);

    Algorithm getAlgorithm();

    void setAlgorithm(Algorithm algorithm);

    T getStickySession(Client client);

    void setStickySession(Client client, T node);
}
