package loadbalancers;

import loadbalancers.algorithms.RoundRobinAlgorithm;

import java.util.List;

public class RoundRobinLoadBalancer<T> extends AbstractLoadBalancer<T> {
    private final RoundRobinAlgorithm<T> roundRobinAlgorithm;

    public RoundRobinLoadBalancer() {
        super(new RoundRobinAlgorithm<>());
        this.roundRobinAlgorithm = (RoundRobinAlgorithm<T>) super.getAlgorithm();
    }

    public RoundRobinLoadBalancer(List<T> nodes) {
        super(nodes, new RoundRobinAlgorithm<>());
        this.roundRobinAlgorithm = (RoundRobinAlgorithm<T>) super.getAlgorithm();
    }

    public int getCurrentIndex() {
        return roundRobinAlgorithm.getCurrentIndex();
    }
}
