package loadbalancers.algorithms;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StickySessionsAlgorithm<T> implements Algorithm<T> {
    private Map<Object, T> stickySessions = new HashMap<>();

    @Override
    public T getNextNode(List<T> nodes) {
        if (nodes.isEmpty()) {
            throw new IllegalStateException("No nodes available in the algorithm");
        }

        // For sticky sessions, try to use the previously assigned node for the client
        // If not found or the node is not in the current node list, fall back to Round Robin
        return stickySessions.computeIfAbsent(Thread.currentThread().getId(), k -> {
            // Round Robin logic
            int currentIndex = stickySessions.size() % nodes.size();
            return nodes.get(currentIndex);
        });
    }
}
