package statsHandling;

public interface StatsPublisher {
    void publishStats(String statsJson);
}
