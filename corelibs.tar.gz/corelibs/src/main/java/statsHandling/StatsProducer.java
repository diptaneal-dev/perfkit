package statsHandling;

import eventsHandling.StatsPublisherMediator;

public interface StatsProducer {
    TelemetryData getMetric();

    void registerWithMediator(StatsPublisherMediator mediator);
}
