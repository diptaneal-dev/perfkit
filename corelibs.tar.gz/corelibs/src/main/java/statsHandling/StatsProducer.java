package statsHandling;

import eventsHandling.StatsPublisherMediator;

public interface StatsProducer {
    Stats getMetric();

    void registerWithMediator(StatsPublisherMediator mediator);
}
