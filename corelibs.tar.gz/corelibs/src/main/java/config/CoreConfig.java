package config;

public interface CoreConfig {

}
