package config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.lang.reflect.Field;

/**
 * Interface for resolving property values, typically used for resolving
 * configuration parameters or environment variables. This interface provides
 * a mechanism to resolve individual properties as well as a method to
 * trigger the resolution of all relevant properties in a given context.
 *
 * @since 1.0
 */
public interface PropertyResolver {
    Logger LOGGER = LogManager.getLogger(PropertyResolver.class);

    /**
     * Resolves the given property value. If the value is enclosed in "${" and "}",
     * it is treated as a key for which the value will be fetched from the
     * {@link EnvironmentManager}.
     *
     * @param value The property value or key to be resolved.
     * @return The resolved value, or the original value if no resolution is needed.
     */
    static String resolve(String value) {
        if (value != null && value.startsWith("${") && value.endsWith("}")) {
            return EnvironmentManager.getInstance().getVariable(value.substring(2, value.length() - 1));
        }
        return value;
    }

    static void resolveAnnotatedProperties(Object config) {
        Field[] fields = config.getClass().getDeclaredFields();
        for (Field field : fields) {
            if (field.isAnnotationPresent(ResolveProperty.class)) {
                field.setAccessible(true);
                try {
                    Object value = field.get(config);
                    if (value instanceof String) {
                        String resolved = resolve((String) value);
                        field.set(config, resolved);
                    }
                } catch (IllegalAccessException e) {
                    LOGGER.error("Property resolution failed {} ", e.getMessage());
                }
            }
        }
    }

    /**
     * Default method to trigger the resolution of all properties that require explicit resolution.
     * It delegates to the static resolveAnnotatedProperties method.
     */
    default void resolveAllProperties() {
        resolveAnnotatedProperties(this);
    }
}
