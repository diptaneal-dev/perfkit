package config;

public interface ConfigLoader {

}
