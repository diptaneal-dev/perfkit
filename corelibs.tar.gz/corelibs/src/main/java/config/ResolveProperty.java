package config;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation to mark a field that requires resolution, typically for
 * post-processing or dependency injection. Fields annotated with {@code @ResolveProperty}
 * are expected to be processed by a component or framework that understands
 * the annotation and performs the necessary resolution logic, such as
 * setting the field with a resolved value from a configuration or another source.
 *
 * @since 1.0
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface ResolveProperty {
}
