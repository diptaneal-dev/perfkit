package config;

public interface ApplicationConfig {
    void loadConfigFromFile(String filePath);

    void loadConfigFromString(String yamlString);
}
