package config;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class EnvironmentManager {
    private static EnvironmentManager instance;
    private final Properties envVariables = new Properties();

    private EnvironmentManager(String configFilePath) throws IOException {
        try (FileInputStream inStream = new FileInputStream(Paths.get(configFilePath).toFile())) {
            envVariables.load(inStream);
        }
    }

    public static synchronized EnvironmentManager getInstance() throws IOException {
        if (instance == null) {
            String configFilePath = System.getProperty("env.config.path", "default/path/to/env_variables.properties");
            instance = new EnvironmentManager(configFilePath);
        }
        return instance;
    }

    public String getVariable(String key, String defaultValue) {
        return envVariables.getProperty(key, defaultValue);
    }
}
