package config;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Properties;

/**
 * Manages environment variables loaded from a configuration file.
 */
public class EnvironmentManager {
    private static EnvironmentManager instance;
    private final Properties envVariables = new Properties();

    /**
     * Constructs an EnvironmentManager and loads environment variables from the specified file.
     *
     * @param configFilePath the file path of the configuration file.
     * @throws IOException if an error occurs during file reading.
     */
    private EnvironmentManager(String configFilePath) throws IOException {
        try (FileInputStream inStream = new FileInputStream(Paths.get(configFilePath).toFile())) {
            envVariables.load(inStream);
        }
    }

    /**
     * Provides the singleton instance of EnvironmentManager.
     *
     * @return the singleton instance of EnvironmentManager.
     * @throws RuntimeException if an IOException occurs during instance creation.
     */
    public static synchronized EnvironmentManager getInstance() {
        try {
            if (instance == null) {
                String configFilePath = System.getProperty("env.config.path", "src/main/resources/environment.properties");
                instance = new EnvironmentManager(configFilePath);
            }
            return instance;
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Retrieves the value of an environment variable.
     *
     * @param key the key of the variable to retrieve.
     * @return the value of the variable, or null if not found.
     */
    public String getVariable(String key) {
        return envVariables.getProperty(key);
    }

    /**
     * Retrieves the value of an environment variable, or a default value if the variable is not found.
     *
     * @param key the key of the variable to retrieve.
     * @param defaultValue the default value to return if the variable is not found.
     * @return the value of the variable, or the default value if the variable is not found.
     */
    public String getVariable(String key, String defaultValue) {
        return envVariables.getProperty(key, defaultValue);
    }
}
