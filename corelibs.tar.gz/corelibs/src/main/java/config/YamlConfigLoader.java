package config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import smartpool.config.ApplicationConfig;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Collectors;

/**
 * A utility class for loading YAML configurations.
 */
public class YamlConfigLoader {

    private static final ObjectMapper mapper = new ObjectMapper(new YAMLFactory());

    /**
     * Loads configuration from a YAML file.
     *
     * @param yamlFilePath the file path of the YAML file.
     * @param configInstance the instance to populate with loaded data.
     * @throws IOException if reading from the file fails.
     * @param <T> the type of configuration instance.
     */
    public static <T extends ApplicationConfig> void loadConfigFromFile(String yamlFilePath, T configInstance) throws IOException {
        String yamlContent = Files.lines(Paths.get(yamlFilePath))
                .collect(Collectors.joining("\n"));
        configInstance.loadConfigFromString(yamlContent);
    }

    /**
     * Loads configuration from a YAML string.
     *
     * @param yamlString the YAML content as a string.
     * @param configInstance the instance to populate with loaded data.
     * @param <T> the type of configuration instance.
     */
    public static <T extends ApplicationConfig> void loadConfigFromString(String yamlString, T configInstance) {
        configInstance.loadConfigFromString(yamlString);
    }

    /**
     * Loads configuration from a YAML file and returns an instance of the specified type.
     *
     * @param yamlFilePath the file path of the YAML file.
     * @param targetType the class of the type to return.
     * @return an instance of the specified type with loaded data, or null in case of errors.
     * @param <T> the type of configuration instance.
     */
    public static <T> T loadConfig(String yamlFilePath, Class<T> targetType) {
        try (InputStream input = new FileInputStream(yamlFilePath)) {
            ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
            return mapper.readValue(input, targetType);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}


