package stats;

import java.time.Instant;

public interface Stats<T> {
    Instant getCreationTime();
    Instant getUpdateTime();
    String convertStatsToJson();
}

