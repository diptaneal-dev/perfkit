package com.mkt.xac.loadbalancers;

import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.Test;
import com.mkt.xac.smartpool.ObjectPool;
import com.mkt.xac.smartpool.SmartObjectPoolManager;
import com.mkt.xac.smartpool.poolexceptions.PoolException;
import com.mkt.xac.xaccache.CacheNode;
import com.mkt.xac.xaccache.CachePool;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class LoadBalancerTest {
    private static final Logger LOGGER = LogManager.getLogger(LoadBalancerTest.class);

    final int poolSize = 3;
    final String mapNamePrefix1 = "CacheMap_";
    private ObjectPool<OrderState> orderStatePool;

    public LoadBalancerTest() {
        System.setProperty("env.config.path", "src/test/resources/test.environment.properties");
        SmartObjectPoolManager smartObjectPoolManager = SmartObjectPoolManager.getInstance();
        orderStatePool = new ObjectPool<>(OrderState::new, OrderState.class, 20, 100);
    }

    @Test
    void testRoundRobinLoadBalancer() {
        LoadBalancer<CacheNode> roundRobinLoadBalancer = new RoundRobinLoadBalancer<>();
        CachePool rrCachePool = new CachePool(poolSize, mapNamePrefix1, roundRobinLoadBalancer);

        LoadBalancerTest loadBalancerTest = new LoadBalancerTest();
        loadBalancerTest.setRandomOrderStateValues(10, rrCachePool);
        assertEquals(3, rrCachePool.getNumberOfCache());

        int sumOfCacheSizes = rrCachePool.cacheSizes().stream().mapToInt(Integer::intValue).sum();
        assertEquals(10, sumOfCacheSizes);
        rrCachePool.clearAll();
    }

    @Test
    void testStickySessionLoadBalancer() {
        final String mapNamePrefix2 = "CacheMap2_";
        LoadBalancer<CacheNode> stickySessionLoadBalancer = new StickySessionLoadBalancer<>();
        CachePool ssCachePool = new CachePool(poolSize, mapNamePrefix2, stickySessionLoadBalancer);

        LoadBalancerTest loadBalancerTest = new LoadBalancerTest();
        loadBalancerTest.updateOrderStateWithRandomOrderStateValues(10, ssCachePool);

        assertEquals(3, ssCachePool.getNumberOfCache());
        int sumOfCacheSizes = ssCachePool.cacheSizes().stream().mapToInt(Integer::intValue).sum();
        assertEquals(10, sumOfCacheSizes);
        ssCachePool.clearAll();
    }


    private OrderState createOrderState(String orderID, char orderStatus, char prevOrdStatus,
                                        long leavesQty, long cumQty, double avgPx,
                                        long dayOrdQty, long dayCumQty, double dayAvgPx,
                                        String orderLinkID, String text, int counter,
                                        boolean oneRiskEligible, boolean gtcGtdOmsTerminated) {
        OrderState orderState = null;
        try {
            orderState = orderStatePool.get();

            // Set values for the fields
            orderState.setOrderID(orderID);
            orderState.setOrderStatus(orderStatus);
            orderState.setPrevOrdStatus(prevOrdStatus);
            orderState.setLeavesQty(leavesQty);
            orderState.setCumQty(cumQty);
            orderState.setAvgPx(avgPx);
            orderState.setDayOrdQty(dayOrdQty);
            orderState.setDayCumQty(dayCumQty);
            orderState.setDayAvgPx(dayAvgPx);
            orderState.setOrderLinkID(orderLinkID);
            orderState.setText(text);
            orderState.setCounter(counter);
            orderState.setOneRiskEligible(oneRiskEligible);
            orderState.setGtcGtdOmsTerminated(gtcGtdOmsTerminated);
            return orderState;
        } catch (PoolException e) {
            LOGGER.error("Failed to create OrderState: " + e.getMessage(), e);
            return null;
        } finally {
            if (orderState != null) {
                try {
                    orderStatePool.release(orderState);
                } catch (PoolException e) {
                    LOGGER.error("Failed to release OrderState: " + e.getMessage(), e);
                }
            }
        }
    }

    private void setRandomOrderStateValues(int numberOfOrderStates, CachePool cachePool) {
        Random random = new Random();

        for (int i = 0; i < numberOfOrderStates; i++) {
            String orderID = "Order" + i;
            char orderStatus = (char) (random.nextInt(26) + 'A');
            char prevOrdStatus = (char) (random.nextInt(26) + 'A');
            long leavesQty = random.nextLong() % 9991 + 10;
            long cumQty = random.nextLong() % 9991 + 10;
            double avgPx = random.nextDouble();
            long dayOrdQty = random.nextLong() % 9991 + 10;
            long dayCumQty = random.nextLong() % 9991 + 10;
            double dayAvgPx = random.nextDouble();
            String orderLinkID = "Link" + i;
            String text = "Text" + i;
            int counter = random.nextInt(1000);
            boolean oneRiskEligible = random.nextBoolean();
            boolean gtcGtdOmsTerminated = random.nextBoolean();

            OrderState orderState = createOrderState(orderID, orderStatus, prevOrdStatus, leavesQty,
                    cumQty, avgPx, dayOrdQty, dayCumQty, dayAvgPx, orderLinkID, text, counter,
                    oneRiskEligible, gtcGtdOmsTerminated);

            cachePool.putToCache(orderState.getOrderID(), orderState);
            if (orderState != null) {
                try {
                    orderStatePool.release(orderState);
                } catch (PoolException e) {
                    LOGGER.error("Failed to release OrderState: " + e.getMessage(), e);
                }
            }
        }
    }

    private void updateOrderStateWithRandomOrderStateValues(int numberOfOrderStates, CachePool cachePool) {
        Random random = new Random();

        for (int i = 0; i < numberOfOrderStates; i++) {
            String orderID = "Order" + i;
            char orderStatus = (char) (random.nextInt(26) + 'A');
            char prevOrdStatus = (char) (random.nextInt(26) + 'A');
            long leavesQty = random.nextLong() % 9991 + 10;
            long cumQty = random.nextLong() % 9991 + 10;
            double avgPx = random.nextDouble();
            long dayOrdQty = random.nextLong() % 9991 + 10;
            long dayCumQty = random.nextLong() % 9991 + 10;
            double dayAvgPx = random.nextDouble();
            String orderLinkID = "Link" + i;
            String text = "Text" + i;
            int counter = random.nextInt(1000);
            boolean oneRiskEligible = random.nextBoolean();
            boolean gtcGtdOmsTerminated = random.nextBoolean();

            OrderState orderState = createOrderState(orderID, orderStatus, prevOrdStatus, leavesQty,
                    cumQty, avgPx, dayOrdQty, dayCumQty, dayAvgPx, orderLinkID, text, counter,
                    oneRiskEligible, gtcGtdOmsTerminated);

            cachePool.putToCache(orderState.getOrderID(), orderState);

            updateOrderStateWithRandomValues(orderState);
            cachePool.putToCache(orderState.getOrderID(), orderState);

            if (orderState != null) {
                try {
                    orderStatePool.release(orderState);
                } catch (PoolException e) {
                    LOGGER.error("Failed to release OrderState: " + e.getMessage(), e);
                }
            }
        }
    }

    private void updateOrderState(OrderState orderState, char orderStatus, char prevOrdStatus,
                                  long leavesQty, long cumQty, double avgPx,
                                  long dayOrdQty, long dayCumQty, double dayAvgPx,
                                  String orderLinkID, String text, int counter,
                                  boolean oneRiskEligible, boolean gtcGtdOmsTerminated) {
        if (orderState != null) {
            orderState.setOrderStatus(orderStatus);
            orderState.setPrevOrdStatus(prevOrdStatus);
            orderState.setLeavesQty(leavesQty);
            orderState.setCumQty(cumQty);
            orderState.setAvgPx(avgPx);
            orderState.setDayOrdQty(dayOrdQty);
            orderState.setDayCumQty(dayCumQty);
            orderState.setDayAvgPx(dayAvgPx);
            orderState.setOrderLinkID(orderLinkID);
            orderState.setText(text);
            orderState.setCounter(counter);
            orderState.setOneRiskEligible(oneRiskEligible);
            orderState.setGtcGtdOmsTerminated(gtcGtdOmsTerminated);
        }
    }

    private void updateOrderStateWithRandomValues(OrderState orderState) {
        if (orderState != null) {
            Random random = new Random();

            // Generate random values for fields
            char orderStatus = (char) (random.nextInt(26) + 'A');
            char prevOrdStatus = (char) (random.nextInt(26) + 'A');
            long leavesQty = random.nextLong() % 9991 + 10;
            long cumQty = random.nextLong() % 9991 + 10;
            double avgPx = random.nextDouble();
            long dayOrdQty = random.nextLong() % 9991 + 10;
            long dayCumQty = random.nextLong() % 9991 + 10;
            double dayAvgPx = random.nextDouble();
            String orderLinkID = "Link" + random.nextInt(100);
            String text = "Text" + random.nextInt(100);
            int counter = random.nextInt(1000);
            boolean oneRiskEligible = random.nextBoolean();
            boolean gtcGtdOmsTerminated = random.nextBoolean();

            // Update the OrderState with random values
            updateOrderState(orderState, orderStatus, prevOrdStatus, leavesQty, cumQty, avgPx, dayOrdQty,
                    dayCumQty, dayAvgPx, orderLinkID, text, counter, oneRiskEligible,
                    gtcGtdOmsTerminated);
        }
    }
}


