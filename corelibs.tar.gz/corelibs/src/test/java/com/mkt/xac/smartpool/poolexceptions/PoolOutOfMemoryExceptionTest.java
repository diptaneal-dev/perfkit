package com.mkt.xac.smartpool.poolexceptions;

import static org.junit.jupiter.api.Assertions.*;

import com.mkt.xac.smartpool.poolexceptions.PoolOutOfMemoryException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PoolOutOfMemoryExceptionTest {

    @Test
    public void testExceptionWithMessage() {
        String message = "OutOfMemory Test Message";
        PoolOutOfMemoryException exception = new PoolOutOfMemoryException(message);

        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }
}
