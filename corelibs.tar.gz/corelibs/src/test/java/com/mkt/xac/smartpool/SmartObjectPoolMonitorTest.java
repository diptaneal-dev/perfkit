package com.mkt.xac.smartpool;

import com.mkt.xac.config.EnvironmentManager;
import com.mkt.xac.eventshandling.DynamicEvent;
import com.mkt.xac.eventshandling.EventPublisher;
import com.mkt.xac.smartpool.*;
import org.junit.jupiter.api.AfterEach;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.mkt.xac.smartpool.config.SmartPoolManagerConfig;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.Mockito.*;

public class SmartObjectPoolMonitorTest {

    private SmartObjectPoolMonitor monitor;
    private ObjectPool<String> mockPool;
    private Map<Class<?>, PoolTelemetryData> poolStatsMapMock;

    private EnvironmentManager mockEnvManager;
    private SmartPoolManagerConfig mockConfig;

    @BeforeEach
    public void setup() {
        System.setProperty("env.config.path", "src/test/resources/test.environment.properties");
        monitor = SmartObjectPoolMonitor.getInstance();
        monitor.reset();

        mockEnvManager = mock(EnvironmentManager.class);
        mockConfig = mock(SmartPoolManagerConfig.class);

        when(mockEnvManager.getVariable("smartobjectpool.config.path", null)).thenReturn("path/to/config.yaml");
        when(mockConfig.getEodFilePath()).thenReturn("/path/to/eodfile");

        SmartObjectPoolManager manager = SmartObjectPoolManager.getInstance();
        manager.setEnvironmentManager(mockEnvManager);
        manager.setConfig(mockConfig);

        mockPool = mock(ObjectPool.class);
        when(mockPool.getObjectClass()).thenReturn(String.class);

        EventPublisher<PoolTelemetryData> mockPublisher = mock(EventPublisher.class);
        monitor.setEventPublisher(mockPublisher);
    }

    @AfterEach
    public void tearDown() {
        monitor.reset();
    }

    @Test
    public void testPoolCreation() {
        when(mockPool.getCurrentSize()).thenReturn(5);
        when(mockPool.getInitialSize()).thenReturn(5L);

        DynamicEvent<ObjectPool<String>, PoolEventType> event =
                new DynamicEvent<>(PoolEventType.POOL_CREATION, mockPool, String.class);
        monitor.update(event);

        PoolTelemetryData stats = monitor.getStatsForClass(String.class);

        assertEquals(5, stats.getCurrentSize());
        assertEquals(5, stats.getInitialPoolSize());
    }

    @Test
    public void testObjectBorrowed() {
        DynamicEvent<ObjectPool<String>, PoolEventType> event =
                new DynamicEvent<>(PoolEventType.OBJECT_BORROWED, mockPool, String.class);
        monitor.update(event);

        PoolTelemetryData stats = monitor.getStatsForClass(String.class);

        assertEquals(1, stats.getCurrentPoolUtilization());
    }

    @Test
    public void testReset() {
        DynamicEvent<ObjectPool<String>, PoolEventType> event =
                new DynamicEvent<>(PoolEventType.RESET, mockPool, String.class);
        monitor.update(event);

        PoolTelemetryData stats = monitor.getStatsForClass(String.class);

        assertEquals(0, stats.getInitialPoolSize());
        assertEquals(0, stats.getCurrentSize());
        assertEquals("", stats.getPoolType());
        assertEquals(0, stats.getCurrentPoolUtilization());
    }

    @Test
    public void testEndOfDaySummary() {
        DynamicEvent<ObjectPool<String>, PoolEventType> event =
                new DynamicEvent<>(PoolEventType.POOL_CREATION, mockPool, String.class);
        monitor.update(event);

        String summary = monitor.endOfDaySummary();

        assertTrue(summary.contains("Stats for pool of type String"));
    }

    @Test
    public void testGetPoolStatsAsJson_Found() {
        PoolTelemetryData mockStats = mock(PoolTelemetryData.class);
        when(mockStats.convertTelemetryDataToJSON()).thenReturn("{\"mockKey\":\"mockValue\"}");

        Map<Class<?>, PoolTelemetryData> mockMap = new HashMap<>();
        mockMap.put(String.class, mockStats);

        SmartObjectPoolMonitor spyMonitor = spy(SmartObjectPoolMonitor.getInstance());

        doReturn("{\"mockKey\":\"mockValue\"}").when(spyMonitor).getPoolStatsAsJson(String.class);

        String result = spyMonitor.getPoolStatsAsJson(String.class);
        assertEquals("{\"mockKey\":\"mockValue\"}", result);
    }

    @Test
    public void testGetPoolStatsAsJson_NotFound() {
        Class<?> clazz = Integer.class;
        poolStatsMapMock = mock(Map.class);
        when(poolStatsMapMock.get(clazz)).thenReturn(null);

        String result = monitor.getPoolStatsAsJson(clazz);
        assertEquals("{}", result);
    }
}
