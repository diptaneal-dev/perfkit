package com.mkt.xac.xaccache;

import static org.junit.jupiter.api.Assertions.*;

import net.openhft.chronicle.hash.impl.util.Objects;
import org.junit.jupiter.api.Test;

import java.io.Serializable;

public class SerializationUtilsTest {

    @Test
    void testSerializeAndDeserialize() {
        SerializableObject sampleObject = new SerializableObject("TestObject", 42);
        byte[] serializedBytes = SerializationUtils.serialize(sampleObject);

        SerializableObject deserializedObject = (SerializableObject)SerializationUtils.deserialize(serializedBytes);
        assertEquals(sampleObject, deserializedObject);
    }

    @Test
    void testSerializeNullObject() {
        byte[] serializedBytes = SerializationUtils.serialize(null);

        assertNotNull(serializedBytes);
        SerializableObject deserializedObject = (SerializableObject)SerializationUtils.deserialize(serializedBytes);

        assertNull(deserializedObject);
    }
}

class SerializableObject implements Serializable {
    private String name;
    private int value;

    public SerializableObject(String name, int value) {
        this.name = name;
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SerializableObject that = (SerializableObject) o;
        return value == that.value &&
                name.equals(that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, value);
    }
}

class NonSerializableObject {
    private String name;
    private int value;

    public NonSerializableObject(String name, int value) {
        this.name = name;
        this.value = value;
    }
}
