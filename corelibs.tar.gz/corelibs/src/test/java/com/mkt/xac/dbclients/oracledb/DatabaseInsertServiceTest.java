package com.mkt.xac.dbclients.oracledb;

import com.mkt.xac.config.EnvironmentManager;
import com.mkt.xac.dbclients.exceptions.ConnectionException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import java.sql.SQLException;

public class DatabaseInsertServiceTest {
    private static final Logger LOGGER = LogManager.getLogger(DatabaseInsertServiceTest.class);

    public static void main(String[] args) {
        System.setProperty("env.config.path", "src/test/resources/test.environment.properties");

        OracleDatabaseService dbService = new OracleDatabaseService();
        OracleDBConnector dbConnector = new OracleDBConnector(dbService);

        try {
            // Configure and connect to the database
            final String oracledbConfigPath = EnvironmentManager.getInstance().getVariable("oracledb.config.path");
            dbConnector.configure(oracledbConfigPath);
            dbConnector.connect();

            // Check if the CountryMaster table already exists
            final String checkTableExistsSQL = "SELECT table_name FROM user_tables WHERE table_name = 'COUNTRYMASTER'";
            boolean tableExists = dbService.executeQuery(dbConnector.getConnection(), checkTableExistsSQL,
                    rs -> rs.next());

            if (!tableExists) {
                final String createTableSQL = "CREATE TABLE CountryMaster (" +
                        "CountryCode VARCHAR2(3) PRIMARY KEY, " +
                        "CountryName VARCHAR2(50) NOT NULL)";
                dbService.executeQuery(dbConnector.getConnection(), createTableSQL, rs -> null);
                LOGGER.info("CountryMaster table created successfully.");
            } else {
                LOGGER.info("CountryMaster table already exists.");

                // Delete existing records from the table
                final String deleteSQL = "DELETE FROM CountryMaster";
                dbService.executeUpdate(dbConnector.getConnection(), deleteSQL, new Object[]{});
                LOGGER.info("Existing records in CountryMaster table deleted.");
            }

            // Read CSV file and insert data
            int insertCount = 0;
            final String csvFilePath = "data/country.csv";
            try (BufferedReader br = new BufferedReader(new FileReader(csvFilePath))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] countryData = line.split(",");
                    if (countryData.length == 2) {
                        String insertSQL = "INSERT INTO CountryMaster (CountryCode, CountryName) VALUES (?, ?)";
                        boolean success = dbService.executeInsert(dbConnector.getConnection(), insertSQL, countryData);
                        if (success) {
                            insertCount++;
                        }
                        else {
                            LOGGER.error("Failed to insert data for country code: " + countryData[0]);
                        }
                    }
                }
            } catch (IOException e) {
                LOGGER.error("Error reading CSV file: {}", e.getMessage(), e);
            }

            LOGGER.info("Data insertion into CountryMaster completed. Total records inserted: " + insertCount);

        } catch (ConnectionException e) {
            LOGGER.error("Error while connecting to the database: {}", e.getMessage(), e);
        } catch (SQLException e) {
            LOGGER.error("SQL Exception: {}", e.getMessage(), e);
        } finally {
            dbConnector.disconnect();
        }
    }
}
