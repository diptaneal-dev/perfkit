package com.mkt.xac.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

class DefaultFileProviderTest {
    private static final Logger LOGGER = LogManager.getLogger(DefaultFileProviderTest.class);

    private DefaultFileProvider fileProvider;

    @BeforeEach
    public void setUp() {
        fileProvider = new DefaultFileProvider();
    }

    @Test
    void testNewInputStreamWithExistingFile(@TempDir Path tempDir) throws IOException {
        Path testFile = tempDir.resolve("testFile.txt");
        Files.write(testFile, "Test content".getBytes());

        try (InputStream inputStream = fileProvider.newInputStream(testFile)) {
            assertNotNull(inputStream);
        }
    }

    @Test
    void testNewInputStreamWithNonExistingFile() {
        Path nonExistingFile = Paths.get("/path/that/does/not/exist");
        try (InputStream inputStream = fileProvider.newInputStream(nonExistingFile)) {
            LOGGER.info("This line will be printed when the test fails {}",
                    inputStream.toString());
        } catch (IOException e) {
            assertThrows(NoSuchFileException.class, () -> {
                throw e;
            });
        }
    }
}
