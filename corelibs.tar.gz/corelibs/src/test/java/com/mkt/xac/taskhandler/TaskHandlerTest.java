package com.mkt.xac.taskhandler;

import com.mkt.xac.config.EnvironmentManager;
import com.mkt.xac.dbclients.DatabaseConnector;
import com.mkt.xac.dbclients.DatabaseService;
import com.mkt.xac.dbclients.exceptions.ConnectionException;
import com.mkt.xac.dbclients.oracledb.OracleDBConnector;
import com.mkt.xac.dbclients.oracledb.OracleDatabaseService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class TaskHandlerTest {
    private DatabaseService dbService;
    DatabaseConnector dbConnector;

    @BeforeEach
    void setup(){
        System.setProperty("env.config.path", "src/test/resources/test.environment.properties");
        dbService = new OracleDatabaseService();
        dbConnector = new OracleDBConnector(dbService);
        try {
            final String oracledbConfigPath = EnvironmentManager.getInstance().getVariable("oracledb.config.path");
            dbConnector.configure(oracledbConfigPath);
            dbConnector.connect();
        } catch (ConnectionException e) {
            throw new RuntimeException(e);
        }
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void testTaskHandlers() {
        TaskSchedulerService scheduler = new TaskSchedulerService();
        RequestContext context = new RequestContext(dbService, dbConnector);
       // scheduler.scheduleTasks("src/test/resources/dailyoperations.yaml", context);

        Runtime.getRuntime().addShutdownHook(new Thread(scheduler::shutdown));
    }


}