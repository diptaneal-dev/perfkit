package com.mkt.xac.dbclients.infuxdb;

import com.mkt.xac.dbclients.DatabaseClient;
import com.mkt.xac.dbclients.exceptions.ConnectionException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

class TestInfluxDBConnection {

    private static final Logger LOGGER = LogManager.getLogger(TestInfluxDBConnection.class);

    @Mock
    private DatabaseClient databaseClient;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        System.setProperty("env.config.path", "src/test/resources/test.environment.properties");
        when(databaseClient.isConnected()).thenReturn(true);
    }

    @AfterEach
    public void tearDown() {
        try {
            databaseClient.disconnect();
        } catch (Exception e) {
            LOGGER.error("Error occurred during disconnection: {}", e.getMessage());
        }
    }

    @Test
    void testConnectionToInfluxDB() {
        try {
            databaseClient.connect();
            boolean connected = databaseClient.isConnected();
            assertTrue(connected, "Mocked connection to InfluxDB should be successful");

            // Verify if the connect method was called on the mock
            verify(databaseClient).connect();
        } catch (ConnectionException e) {
            LOGGER.error("InfluxDB Connection not successful: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to establish InfluxDB connection", e);
        }
    }
}
