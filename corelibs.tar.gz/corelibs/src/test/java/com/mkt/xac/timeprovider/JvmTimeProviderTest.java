package com.mkt.xac.timeprovider;

import static org.junit.jupiter.api.Assertions.*;

import com.mkt.xac.timeprovider.exception.InvalidTimeZoneException;
import org.junit.jupiter.api.Test;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.zone.ZoneRulesException;

class JvmTimeProviderTest {

    @Test
    void testGetCurrentTime() {
        JvmTimeProvider provider = new JvmTimeProvider("UTC");
        Instant expected = Instant.now();
        Instant actual = provider.getCurrentTime();
        long timeDifference = Math.abs(actual.toEpochMilli() - expected.toEpochMilli());
        assertTrue(timeDifference < 1000);
    }

    @Test
    void testGetCurrentTimeInZone() {
        JvmTimeProvider provider = new JvmTimeProvider("Europe/London");
        Instant expected = ZonedDateTime.now(ZoneId.of("Europe/London")).toInstant();
        Instant actual = provider.getCurrentTimeInZone();
        assertEquals(expected.getEpochSecond(), actual.getEpochSecond(), 1);
    }

    @Test
    void testGetCurrentLocalTime() {
        JvmTimeProvider provider = new JvmTimeProvider("Asia/Tokyo");
        LocalTime expected = ZonedDateTime.now(ZoneId.of("Asia/Tokyo")).toLocalTime();
        LocalTime actual = provider.getCurrentLocalTime();
        assertEquals(expected.getHour(), actual.getHour());
        assertEquals(expected.getMinute(), actual.getMinute());
    }

    @Test
    void testGetFormattedCurrentTime() {
        JvmTimeProvider provider = new JvmTimeProvider("UTC");
        String pattern = "yyyy-MM-dd HH:mm";
        String expected = DateTimeFormatter.ofPattern(pattern).withZone(ZoneId.of("UTC")).format(Instant.now());
        String actual = provider.getFormattedCurrentTime(pattern);
        assertEquals(expected.substring(0, 16), actual.substring(0, 16));
    }

    @Test
    void testGetCurrentTimeOrUTC() {
        JvmTimeProvider provider = new JvmTimeProvider("UTC");
        Instant actual = provider.getCurrentTimeOrUTC(ZoneId.of("Europe/Paris"));
        assertNotNull(actual);
    }

    @Test
    void testInvalidTimeZoneException() {
        JvmTimeProvider provider = new JvmTimeProvider("UTC");
        assertThrows(ZoneRulesException.class, () -> provider.getCurrentTime(ZoneId.of("Invalid/Zone")));
    }
}
