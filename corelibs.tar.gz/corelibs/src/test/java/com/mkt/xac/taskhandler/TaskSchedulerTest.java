package com.mkt.xac.taskhandler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.mkt.xac.taskhandler.operationsConfig.Operation;
import com.mkt.xac.taskhandler.operationsConfig.OperationsConfig;
import com.mkt.xac.timeprovider.FixedTimeProvider;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class TaskSchedulerTest {

    @Test
    public void testReadCsvAndSchedule() throws InterruptedException {
        // Step 1: Load and parse the YAML configuration
        String yamlString =
                "operations:\n" +
                        "  - name: CountryDataUpload\n" +
                        "    databaseType: oracle\n" +
                        "    schedule:\n" +
                        "      startTime: \"17:49\"  # Time in HH:mm format\n" +
                        "      frequency: \"daily\"  # Options: daily, weekly, monthly, etc.\n" +
                        "    sequence:\n" +
                        "      - step: ReadCSV\n" +
                        "        filePath: \"data/country.csv\"\n" +
                        "        delimiter: \",\"\n" +
                        "        expectedColumnCount: 2\n";

        OperationsConfig config = parseYamlConfig(yamlString);

        // Step 2: Adjust the start time to be 2 seconds from now
        Instant nowPlusTwoSeconds = Instant.now().plusSeconds(2);
        adjustOperationStartTime(config, nowPlusTwoSeconds);

        // Step 3: Create a FixedTimeProvider set to now + 2 seconds
        FixedTimeProvider timeProvider = new FixedTimeProvider(nowPlusTwoSeconds);

        // Step 4: Initialize the TaskSchedulerService with the FixedTimeProvider
        TaskSchedulerService scheduler = new TaskSchedulerService(timeProvider);

        // Step 5: Schedule the task
        RequestContext context = new RequestContext(null, null);
        for (Operation operation : config.getOperations()) {
            scheduler.scheduleOperation(operation, context);
        }

        // Wait for 3 seconds to allow the task to execute
        Thread.sleep(3000);
        scheduler.shutdown();
    }

    private OperationsConfig parseYamlConfig(String yamlConfig) {
        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
        try {
            return mapper.readValue(yamlConfig, OperationsConfig.class);
        } catch (IOException e) {
            throw new RuntimeException("Failed to parse YAML configuration", e);
        }
    }

    private void adjustOperationStartTime(OperationsConfig config, Instant newStartTime) {
        // Convert Instant to LocalTime
        LocalTime newTime = LocalDateTime.ofInstant(newStartTime, ZoneId.systemDefault()).toLocalTime();

        // Format LocalTime to a string in HH:mm format
        String formattedTime = newTime.format(DateTimeFormatter.ofPattern("HH:mm"));

        // Iterate through all operations and adjust their start time
        for (Operation operation : config.getOperations()) {
            if (operation.getSchedule() != null) {
                operation.getSchedule().setStartTime(formattedTime);
            }
        }
    }
}
