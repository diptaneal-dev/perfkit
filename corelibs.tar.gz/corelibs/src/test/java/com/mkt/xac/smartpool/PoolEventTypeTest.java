package com.mkt.xac.smartpool;

import com.mkt.xac.smartpool.PoolEventType;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class PoolEventTypeTest {

    @Test
    public void testDescriptions() {
        assertEquals("Pool created event", PoolEventType.POOL_CREATION.getDescription());
        assertEquals("Object borrowed event", PoolEventType.OBJECT_BORROWED.getDescription());
        assertEquals("Object returned to the pool", PoolEventType.OBJECT_RETURNED.getDescription());
        assertEquals("Out of available objects in the pool", PoolEventType.OUT_OF_POOL.getDescription());
        assertEquals("Unable to allocate memory for new objects", PoolEventType.OUT_OF_MEMORY.getDescription());
        assertEquals("MaxSize Breach event triggered", PoolEventType.MAXSIZE_BREACH.getDescription());
        assertEquals("Pool has been resized", PoolEventType.RESIZE.getDescription());
        assertEquals("Pool is reset", PoolEventType.RESET.getDescription());
        assertEquals("Error occurred while releasing object back to the pool", PoolEventType.ERROR_ON_RELEASE.getDescription());
        assertEquals("Error during pool resize", PoolEventType.ERROR_ON_RESIZE.getDescription());
        assertEquals("Smart Pool Creation Error", PoolEventType.ERROR_ON_CREATION.getDescription());
    }

    @Test
    public void testEnumCount() {
        assertEquals(12, PoolEventType.values().length);
    }
}
