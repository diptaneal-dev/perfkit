package com.mkt.xac.stats;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.reflect.Whitebox;
import com.mkt.xac.smartpool.PoolTelemetryData;

import java.lang.reflect.Field;
import java.time.Instant;
import java.util.List;
import static org.mockito.Mockito.when;


public class PoolTelemetryDataTest {
    private PoolTelemetryData poolStats;

    @BeforeEach
    public void setup() {
        poolStats = new PoolTelemetryData();
    }

    @AfterEach
    public void tearDown() {
        poolStats.reset();
    }

    @Test
    public void testDefaultInitialization() {
        assertEquals(0, poolStats.getInitialPoolSize());
        assertEquals("", poolStats.getPoolType());
        assertEquals(0, poolStats.getPeakSize());
        assertEquals(null, poolStats.getCreationTime());
        assertEquals(false, poolStats.isMaxSizeBreached());
    }

    @Test
    public void testSettersAndGetters() {
        poolStats.setInitialPoolSize(10);
        poolStats.setPoolType("testType");
        poolStats.setPeakSize(1000);
        poolStats.setResizes(3);
        poolStats.setMaxSizeBreached(true);
        poolStats.setCurrentSize(10);

        assertEquals(10, poolStats.getInitialPoolSize());
        assertEquals("testType", poolStats.getPoolType());
        assertEquals(1000, poolStats.getPeakSize());
        assertEquals(3, poolStats.getResizes());
        assertEquals(true, poolStats.isMaxSizeBreached());
        assertEquals(10, poolStats.getCurrentSize());
    }

    @Test
    public void testIncrementDecrementatOperations() {
        poolStats.incrementOutOfMemoryCount();
        poolStats.incrementOutOfPoolCount();
        poolStats.incrementCurrentPoolUtilization();
        poolStats.incrementResizes();

        assertEquals(1, poolStats.getCurrentPoolUtilization());

        poolStats.decrementCurrentPoolUtilization();
        assertEquals(0, poolStats.getCurrentPoolUtilization());

        assertEquals(1, poolStats.getOutOfMemoryCount());
        assertEquals(1, poolStats.getOutOfPoolCount());
        assertEquals(1, poolStats.getResizes());
    }

    @Test
    public void testTimestampLogging() {
        assertNull(poolStats.getCreationTime());

        poolStats.updateTimeOfPoolCreation();
        assertNotNull(poolStats.getCreationTime());
    }

    @Test
    public void testConversionToJson() {
        String jsonOutput = poolStats.convertTelemetryDataToJSON();
        assertTrue(jsonOutput.contains("\"initialPoolSize\":0"));
    }

    @Test
    public void testReset() {
        poolStats.setInitialPoolSize(10);
        poolStats.reset();

        assertEquals(0, poolStats.getInitialPoolSize());
        assertEquals("", poolStats.getPoolType());
        assertEquals(0, poolStats.getPeakSize());
        assertEquals(null, poolStats.getCreationTime());
        assertEquals(false, poolStats.isMaxSizeBreached());
    }
    @Test
    public void testAddResizeTimestamp() throws NoSuchFieldException, IllegalAccessException {
        Instant timestamp = Instant.now();

        poolStats.addResizeTimestamp(timestamp);

        Field field = PoolTelemetryData.class.getDeclaredField("resizeTimestamps");
        field.setAccessible(true);
        List<Instant> resizeTimestamps = (List<Instant>) field.get(poolStats);

        assertEquals(1, resizeTimestamps.size(), "Size of resizeTimestamps should be 1 after adding a timestamp.");
        assertTrue(resizeTimestamps.contains(timestamp), "resizeTimestamps should contain the added timestamp.");
    }

    @Mock
    private ObjectMapper objectMapperMock;

    private ObjectMapper originalObjectMapper;

    @Test
    public void testConvertStatsToJson_RuntimeException() throws Exception {
        MockitoAnnotations.openMocks(this);
        originalObjectMapper = Whitebox.getInternalState(PoolTelemetryData.class, "OBJECT_MAPPER");

        when(objectMapperMock.writeValueAsString(Mockito.any(PoolTelemetryData.class))).thenThrow(new RuntimeException("Mocked exception"));
        Whitebox.setInternalState(PoolTelemetryData.class, "OBJECT_MAPPER", objectMapperMock);
        PoolTelemetryData poolStats = new PoolTelemetryData();
        assertThrows(RuntimeException.class, () -> poolStats.convertTelemetryDataToJSON(), "Expected RuntimeException to be thrown");

        Whitebox.setInternalState(PoolTelemetryData.class, "OBJECT_MAPPER", originalObjectMapper);
    }

}
