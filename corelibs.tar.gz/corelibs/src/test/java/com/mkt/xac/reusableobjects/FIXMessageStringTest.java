package com.mkt.xac.reusableobjects;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class FIXMessageStringTest {
    private String rawFIXMessage;

    @BeforeEach
    void setup(){
        rawFIXMessage = "8=FIX.4.2|9=176|35=8|34=1|49=SENDER|56=RECEIVER|52=20210907-08:30:00|60=20210907-08:30:00|54=1|55=TCS.NS|100=NS|38=100|44=1200|40=2|59=0|";
    }

    @Test
    void testUpdateMessageType() throws FIXMessageParsingException {
        byte[] messageBytes = rawFIXMessage.replace('|', '\u0001').getBytes();

        FIXMessageString fixMessageString = TLC.instance().getFIXMessageString();
        fixMessageString.setBuffer(messageBytes, messageBytes.length);

        fixMessageString.updateMessageType( "D");

        String expectedFIXMessage = "8=FIX.4.2|9=176|35=D|34=1|49=SENDER|56=RECEIVER|" +
                "52=20210907-08:30:00|60=20210907-08:30:00|54=1|55=TCS.NS|100=NS|" +
                "38=100|44=1200|40=2|59=0|";
        expectedFIXMessage = expectedFIXMessage.replace('|', '\u0001');

        // Assert equality of expected and actual FIX messages
        assertEquals(expectedFIXMessage, fixMessageString.toString());
    }

    @Test
    void testUpdateFIXVersion() throws FIXMessageParsingException {
        byte[] messageBytes = rawFIXMessage.replace('|', '\u0001').getBytes();

        FIXMessageString fixMessageString = TLC.instance().getFIXMessageString();
        fixMessageString.setBuffer(messageBytes, messageBytes.length);

        fixMessageString.updateFIXVersion( "FIX.4.4");

        String expectedFIXMessage = "8=FIX.4.4|9=176|35=8|34=1|49=SENDER|56=RECEIVER|" +
                "52=20210907-08:30:00|60=20210907-08:30:00|54=1|55=TCS.NS|100=NS|" +
                "38=100|44=1200|40=2|59=0|";
        expectedFIXMessage = expectedFIXMessage.replace('|', '\u0001');

        // Assert equality of expected and actual FIX messages
        assertEquals(expectedFIXMessage, fixMessageString.toString());
    }

    @Test
    void updateFIXTag() throws FIXMessageParsingException {
        byte[] messageBytes = rawFIXMessage.replace('|', '\u0001').getBytes();

        FIXMessageString fixMessageString = TLC.instance().getFIXMessageString();
        fixMessageString.setBuffer(messageBytes, messageBytes.length);

        fixMessageString.updateFIXTag("35=".getBytes(), "D");

        String expectedFIXMessage = "8=FIX.4.2|9=176|35=D|34=1|49=SENDER|56=RECEIVER|" +
                "52=20210907-08:30:00|60=20210907-08:30:00|54=1|55=TCS.NS|100=NS|" +
                "38=100|44=1200|40=2|59=0|";
        expectedFIXMessage = expectedFIXMessage.replace('|', '\u0001');

        // Assert equality of expected and actual FIX messages
        assertEquals(expectedFIXMessage, fixMessageString.toString());
    }
}