package com.mkt.xac.xaccache;

import static org.junit.jupiter.api.Assertions.*;

import com.mkt.xac.xaccache.LargeCache;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.util.regex.Pattern;

public class LargeCacheTest {
    private static final String MAPS_DIRECTORY = "maps/";
    private static final Pattern MAP_NAME_PATTERN = Pattern.compile("^LargeCacheChMap.*\\.dat$");

    private LargeCache largeCache;
    private File mapFile;

    @BeforeEach
    void setUp() {
        mapFile = new File("maps/LargeCacheChMap_test.dat");
        largeCache = new LargeCache("LargeCacheChMap");
    }

    @AfterEach
    public void tearDown() {
        largeCache.close();

        System.out.println("Teardown function called");
        File mapsDirectory = new File(MAPS_DIRECTORY);
        File[] mapFiles = mapsDirectory.listFiles();

        if (mapFiles != null) {
            for (File mapFile : mapFiles) {
                if (mapFile.isFile() && MAP_NAME_PATTERN.matcher(mapFile.getName()).matches()) {
                    mapFile.delete();
                }
            }
        }
    }

    @Test
    void testGetCacheName() {
        String mapFileName = "LargeCacheChMap";
        LargeCache largeCache = new LargeCache(mapFileName);
        Object key = "testKey";
        Object value = "testValue";

        largeCache.putToCache(key, value);

        String cacheName = largeCache.getCacheName();
        assertEquals(mapFileName, cacheName);
    }

    @Test
    void testPutAndGetFromCache() {
        Object key = "testKey";
        Object value = "testValue";

        largeCache.putToCache(key, value);
        Object retrievedValue = largeCache.getFromCache(key);
        assertEquals(value, retrievedValue);
    }

    @Test
    void testRemoveFromCache() {
        Object key = "testKey";
        Object value = "testValue";

        largeCache.putToCache(key, value);
        largeCache.removeFromCache(key);

        assertNull(largeCache.getFromCache(key));
    }

    @Test
    void testPersistence() {
        largeCache.putToCache("key1", "value1");
        largeCache.putToCache("key2", "value2");

        largeCache.close();

        largeCache = new LargeCache("LargeCacheChMap");

        assert((String) largeCache.getFromCache("key1")).equals("value1");
        assert((String) largeCache.getFromCache("key2")).equals("value2");
    }

    @Test
    public void testCacheIsClosed() {
        assertTrue(largeCache.isCacheOpen());
        largeCache.close();
        assertFalse(largeCache.isCacheOpen());
    }

}
