package com.mkt.xac.utils;

import com.mkt.xac.utils.StackTraceUtility;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class StackTraceUtilityTest {

    @Test
    public void testPrintCallStackLevels_ThrowsIllegalArgumentException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            StackTraceUtility.printCallStackLevels(0);
        });

        String expectedMessage = "Number of levels must be at least 1";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

}
