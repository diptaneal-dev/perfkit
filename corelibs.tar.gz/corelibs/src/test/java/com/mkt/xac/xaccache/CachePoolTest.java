package com.mkt.xac.xaccache;

import com.mkt.xac.loadbalancers.LoadBalancer;
import com.mkt.xac.loadbalancers.RoundRobinLoadBalancer;
import com.mkt.xac.xaccache.CacheNode;
import com.mkt.xac.xaccache.CachePool;
import com.mkt.xac.xaccache.LargeCache;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.util.Arrays;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CachePoolTest {
    private static final String MAPS_DIRECTORY = "maps/";
    private static final Pattern MAP_NAME_PATTERN = Pattern.compile("^TestChMap.*\\.dat$");

    @AfterEach
    public void tearDown() {
        System.out.println("Teardown function called");
        File mapsDirectory = new File(MAPS_DIRECTORY);
        File[] mapFiles = mapsDirectory.listFiles();

        if (mapFiles != null) {
            for (File mapFile : mapFiles) {
                if (mapFile.isFile() && MAP_NAME_PATTERN.matcher(mapFile.getName()).matches()) {
                    mapFile.delete();
                }
            }
        }
    }

    @Test
    public void testPutToCache() {
        LargeCache largeCacheMock = mock(LargeCache.class);

        LoadBalancer<CacheNode> loadBalancerMock = mock(LoadBalancer.class);
        when(loadBalancerMock.getNextNode()).thenReturn(largeCacheMock);

        CachePool cachePool = new CachePool(1, "TestChMap", loadBalancerMock);
        cachePool.putToCache("some-key", "some value");

        verify(largeCacheMock).putToCache("some-key", "some value");
    }

    @Test
    void getFromCache() {
        LargeCache largeCache = new LargeCache("TestChMap");
        LoadBalancer<CacheNode> loadBalancer = new RoundRobinLoadBalancer<>(Arrays.asList(largeCache));
        CachePool cachePool = new CachePool(1, "TestChMap", loadBalancer);

        cachePool.putToCache("some-key", "some value");
        Object result = cachePool.getFromCache("some-key");

        assertNotNull(result);
        assertEquals("some value", result);
    }

    @Test
    void removeFromCache() {
        LargeCache largeCache = new LargeCache("TestChMap");
        LoadBalancer<CacheNode> loadBalancer = new RoundRobinLoadBalancer<>(Arrays.asList(largeCache));
        CachePool cachePool = new CachePool(1, "TestChMap", loadBalancer);

        cachePool.putToCache("some-key", "some value");
        Object result = cachePool.getFromCache("some-key");

        assertNotNull(result);
        cachePool.removeFromCache("some-key");
        result = cachePool.getFromCache("some-key");
        assertNull(result);
    }

    @Test
    void close() {
        CachePool cachePool = new CachePool(3, "TestChMap", new RoundRobinLoadBalancer<>());
        cachePool.close();

        for (CacheNode cache : cachePool.getPoolOfCaches()) {
            assertTrue(cache.isCacheClosed());
        }
    }

    @Test
    public void testCloseSingleCache() {
        CachePool cachePool = new CachePool(3, "TestChMap", new RoundRobinLoadBalancer<>());
        cachePool.closeSingleCache(0);

        // Verify that the first cache is closed
        assertTrue(cachePool.getPoolOfCaches().get(0).isCacheClosed());
        assertFalse(cachePool.getPoolOfCaches().get(1).isCacheClosed());
        assertFalse(cachePool.getPoolOfCaches().get(2).isCacheClosed());
    }

    @Test
    void printCacheState() {
        LargeCache largeCache = new LargeCache("TestChMap");
        LoadBalancer<CacheNode> loadBalancer = new RoundRobinLoadBalancer<>(Arrays.asList(largeCache));
        CachePool cachePool = new CachePool(1, "TestChMap", loadBalancer);

        cachePool.putToCache("some-key", "some value");
        Object result = cachePool.getFromCache("some-key");

        assertNotNull(result);
        assertEquals("Cache TestChMap0 has numberOfRecords: 1\n", cachePool.printCacheState());
    }
}