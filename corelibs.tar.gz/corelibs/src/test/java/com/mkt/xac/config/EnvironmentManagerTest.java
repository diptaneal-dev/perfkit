package com.mkt.xac.config;

import com.mkt.xac.config.EnvironmentManager;
import com.mkt.xac.config.exceptions.EnvironmentManagerInitializationException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Properties;

import static org.junit.jupiter.api.Assertions.*;

class EnvironmentManagerTest {
    @TempDir
    File tempDir;

    private EnvironmentManager environmentManager;

    @BeforeEach
    void setUp() {
        File configFile = new File(tempDir, "test.properties");
        Properties properties = new Properties();
        properties.setProperty("key1", "value1");
        properties.setProperty("key2", "value2");
        try (FileOutputStream fos = new FileOutputStream(configFile)) {
            properties.store(fos, null);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        // Set the system property for the configuration file path
        System.setProperty("env.config.path", configFile.getAbsolutePath());
    }

    @AfterEach
    void tearDown() throws Exception {
        if (environmentManager != null) {
            callResetInstance();
        }
    }

    private void callResetInstance() throws Exception {
        Class<?> environmentManagerClass = environmentManager.getClass();
        Method resetInstanceMethod = environmentManagerClass.getDeclaredMethod("resetInstance");
        resetInstanceMethod.setAccessible(true);
        resetInstanceMethod.invoke(environmentManager);
    }

    @Test
    void testGetInstance() {
        environmentManager = EnvironmentManager.getInstance();
        assertNotNull(environmentManager);
    }

    @Test
    void testGetVariable() {
        environmentManager = EnvironmentManager.getInstance();
        assertEquals("value1", environmentManager.getVariable("key1"));
        assertEquals("value2", environmentManager.getVariable("key2"));
        assertNull(environmentManager.getVariable("nonexistentKey"));
    }

    @Test
    void testGetVariableWithDefaultValue() {
        environmentManager = EnvironmentManager.getInstance();
        assertEquals("value1", environmentManager.getVariable("key1", "default1"));
        assertEquals("value2", environmentManager.getVariable("key2", "default2"));
        assertEquals("default3", environmentManager.getVariable("nonexistentKey", "default3"));
    }

    @Test
    void testReload() throws IOException {
        environmentManager = EnvironmentManager.getInstance();
        File newConfigFile = new File(tempDir, "test_new.properties");
        Properties newProperties = new Properties();
        newProperties.setProperty("key1", "new_value1");
        try (FileOutputStream fos = new FileOutputStream(newConfigFile)) {
            newProperties.store(fos, null);
        }

        environmentManager.reload(newConfigFile.getAbsolutePath());
        assertEquals("new_value1", environmentManager.getVariable("key1"));
    }

    @Test
    void getInstance_ShouldThrowException_WhenInvalidPath() {
        String originalProperty = System.getProperty("env.config.path");
        try {
            System.setProperty("env.config.path", "/invalid/path");
            assertThrows(EnvironmentManagerInitializationException.class,
                    EnvironmentManager::getInstance);
        } finally {
            if (originalProperty != null) {
                System.setProperty("env.config.path", originalProperty);
            } else {
                System.clearProperty("env.config.path");
            }
        }
    }
}