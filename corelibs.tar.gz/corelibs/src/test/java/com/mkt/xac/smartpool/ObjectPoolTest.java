package com.mkt.xac.smartpool;

import com.mkt.xac.eventshandling.DynamicEvent;
import com.mkt.xac.monitoring.Observer;
import com.mkt.xac.smartpool.ObjectPool;
import com.mkt.xac.smartpool.PoolEventType;
import com.mkt.xac.smartpool.SmartObjectPoolMonitor;
import org.junit.jupiter.api.*;
import org.mockito.*;
import com.mkt.xac.smartpool.poolexceptions.PoolException;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class ObjectPoolTest {
    @Mock
    private ObjectPool.Factory<String> mockFactory;

    private ObjectPool<String> objectPool;
    private AutoCloseable closeable;

    @BeforeEach
    public void setUp() {
        System.setProperty("env.config.path", "src/test/resources/test.environment.properties");
        closeable = MockitoAnnotations.openMocks(this);
        when(mockFactory.create()).thenReturn("TestString");
        objectPool = new ObjectPool<>(mockFactory, String.class, 2, 10);
    }

    @AfterEach
    public void tearDown() throws Exception {
        closeable.close();
    }

    @Test
    @SuppressWarnings("unchecked")
    void testInitializeObjects() {
        SmartObjectPoolMonitor poolObserver = SmartObjectPoolMonitor.getInstance();
        poolObserver.reset();
        ObjectPool<String> objectPool = new ObjectPool<>(String::new, String.class, 2, 10);
        assertEquals(2, objectPool.getAvailableObjects());
        assertEquals(1, poolObserver.getCurrentPoolSizes().size());
    }

    @Test
    void testGet() throws PoolException {
        String obj = objectPool.get();
        assertEquals("TestString", obj);
        assertEquals(1, objectPool.getAvailableObjects());
    }

    @Test
    void testRelease() throws PoolException {
        String obj = objectPool.get();
        objectPool.release(obj);
        assertEquals(2, objectPool.getAvailableObjects());
    }

    @Test
    void testReleaseNullObject() {
        assertThrows(PoolException.class, () -> objectPool.release(null));
    }

    @Test
    void testResize() throws PoolException {
        for (int i = 0; i < 2; i++) objectPool.get();
        String obj = objectPool.get();
        assertNotNull(obj);
        assertEquals(1, objectPool.getAvailableObjects());
        assertEquals(4, objectPool.getCurrentSize());
    }

    @Test
    @SuppressWarnings("unchecked")
    void testMaxSizeBreach() throws PoolException {
        when(mockFactory.create()).thenAnswer(inv -> "");
        ObjectPool<String> limitedPool = new ObjectPool<>(mockFactory, String.class, 5, 10);
        for (int i = 0; i < 15; i++) {
            limitedPool.get();
        }
        assertTrue(SmartObjectPoolMonitor.getInstance().getStatsForClass(String.class).isMaxSizeBreached());
    }

    @Test
    void testReset() {
        objectPool.reset();
        assertEquals(0, objectPool.getAvailableObjects());
    }

    @Test
    @SuppressWarnings("unchecked")
    void testAddObserver() throws PoolException {
        Observer<PoolEventType, ObjectPool<String>> anotherObserver = mock(Observer.class);
        objectPool.addObserver(anotherObserver);
        objectPool.get();

        verify(anotherObserver, times(1)).update(argThat(event ->
                event.getEventType() == PoolEventType.OBJECT_BORROWED &&
                        event.getSubject().equals(objectPool)
        ));
    }


    @Test
    @SuppressWarnings("unchecked")
    void testRemoveObserver() throws PoolException {
        Observer<PoolEventType, ObjectPool<String>> anotherObserver = mock(Observer.class);
        objectPool.addObserver(anotherObserver);

        objectPool.get();

        verify(anotherObserver, times(1)).update(argThat(event ->
                event.getEventType() == PoolEventType.OBJECT_BORROWED &&
                        event.getSubject().equals(objectPool)
        ));

        Mockito.reset(anotherObserver);
        objectPool.removeObserver(anotherObserver);

        objectPool.get();
        verify(anotherObserver, never()).update(any(DynamicEvent.class));
        verifyNoMoreInteractions(anotherObserver);
    }

    @Test
    @SuppressWarnings("unchecked")
    void testResizeOutOfMemory() {
        ObjectPool.Factory<String> mockFactory = mock(ObjectPool.Factory.class);
        when(mockFactory.create()).thenThrow(new OutOfMemoryError());

        objectPool.setFactory(mockFactory);

        Observer<PoolEventType, ObjectPool<String>> observerMock = mock(Observer.class);
        objectPool.addObserver(observerMock);

        PoolException exception = assertThrows(PoolException.class, () -> objectPool.resize());
        assertEquals("Failed to resize the pool due to memory constraints", exception.getMessage());

        verify(observerMock, times(1)).update(argThat(event ->
                event.getEventType() == PoolEventType.OUT_OF_MEMORY &&
                        event.getSubject().equals(objectPool)
        ));
    }


    @Test
    @SuppressWarnings("unchecked")
    void testResizeException() {
        ObjectPool.Factory<String> mockFactory = mock(ObjectPool.Factory.class);
        when(mockFactory.create()).thenThrow(new RuntimeException("Simulated pool creation error"));

        objectPool.setFactory(mockFactory);

        Observer<PoolEventType, ObjectPool<String>> observerMock = mock(Observer.class);
        objectPool.addObserver(observerMock);

        PoolException exception = assertThrows(PoolException.class, () -> objectPool.resize());
        assertEquals("Error occurred during pool resizing", exception.getMessage());

        verify(observerMock, times(1)).update(argThat(event ->
                event.getEventType() == PoolEventType.ERROR_ON_RESIZE &&
                        event.getSubject().equals(objectPool)
        ));
    }
}
