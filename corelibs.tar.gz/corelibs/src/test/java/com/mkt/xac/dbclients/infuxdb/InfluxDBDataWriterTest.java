package com.mkt.xac.dbclients.infuxdb;

import static org.mockito.Mockito.*;

import com.influxdb.client.domain.WritePrecision;
import com.influxdb.client.write.Point;
import com.mkt.xac.dbclients.infuxdb.InfluxDBConnector;
import com.mkt.xac.dbclients.infuxdb.InfluxDBDataWriter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class InfluxDBDataWriterTest {

    private InfluxDBDataWriter dataWriter;
    private InfluxDBConnector influxDBConnector;

    @BeforeEach
    public void setUp() {
        influxDBConnector = mock(InfluxDBConnector.class);
        dataWriter = new InfluxDBDataWriter(influxDBConnector);
    }

    @Test
    public void testWrite() {
        Point point = new Point("measurementName")
                .addTag("tag1", "value1")
                .addField("field1", 123)
                .time(System.currentTimeMillis(), WritePrecision.MS);
        dataWriter.write(point);

        verify(influxDBConnector, times(1)).write(point);
    }
}

