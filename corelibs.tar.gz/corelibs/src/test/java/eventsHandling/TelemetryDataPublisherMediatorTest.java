package eventsHandling;

import com.mkt.xac.eventshandling.StatsPublisherMediator;
import com.mkt.xac.statsHandling.StatsPublisher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;


public class TelemetryDataPublisherMediatorTest {

    private StatsPublisherMediator mediator;
    private StatsPublisher mockPublisher1;
    private StatsPublisher mockPublisher2;

    @BeforeEach
    public void setUp() {
        mediator = new StatsPublisherMediator();
        mockPublisher1 = mock(StatsPublisher.class);
        mockPublisher2 = mock(StatsPublisher.class);
    }

    @Test
    public void testPublishAll() {
        mediator.addPublisher(mockPublisher1);
        mediator.addPublisher(mockPublisher2);

        String sampleStats = "{ \"stat\": \"value\" }";
        mediator.publishAll(sampleStats);

        verify(mockPublisher1, times(1)).publishStats(sampleStats);
        verify(mockPublisher2, times(1)).publishStats(sampleStats);
    }
}
