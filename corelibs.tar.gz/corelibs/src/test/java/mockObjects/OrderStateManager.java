package mockObjects;

import java.util.Random;

import loadbalancers.LoadBalancer;
import loadbalancers.RoundRobinLoadBalancer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import smartpool.ObjectPool;
import smartpool.SmartObjectPoolManager;
import smartpool.poolexceptions.PoolException;
import xaccache.CacheNode;
import xaccache.CachePool;

public class OrderStateManager {
    private static final Logger LOGGER = LogManager.getLogger(OrderStateManager.class);

    private CachePool cachePool;
    private ObjectPool<OrderState> orderStatePool = new ObjectPool<>(OrderState::new, OrderState.class, 100, 1000);

    public OrderStateManager(CachePool cachePool) {
        this.cachePool = cachePool;
    }

    public OrderState createOrderState(String orderID, char orderStatus, char prevOrdStatus,
                                       long leavesQty, long cumQty, double avgPx,
                                       long dayOrdQty, long dayCumQty, double dayAvgPx,
                                       String orderLinkID, String text, int counter,
                                       boolean oneRiskEligible, boolean gtcGtdOmsTerminated) {
        OrderState orderState = null;
        try {
            orderState = orderStatePool.get();

            // Set values for the fields
            orderState.setOrderID(orderID);
            orderState.setOrderStatus(orderStatus);
            orderState.setPrevOrdStatus(prevOrdStatus);
            orderState.setLeavesQty(leavesQty);
            orderState.setCumQty(cumQty);
            orderState.setAvgPx(avgPx);
            orderState.setDayOrdQty(dayOrdQty);
            orderState.setDayCumQty(dayCumQty);
            orderState.setDayAvgPx(dayAvgPx);
            orderState.setOrderLinkID(orderLinkID);
            orderState.setText(text);
            orderState.setCounter(counter);
            orderState.setOneRiskEligible(oneRiskEligible);
            orderState.setGtcGtdOmsTerminated(gtcGtdOmsTerminated);
            return orderState;
        } catch (PoolException e) {
            LOGGER.error("Failed to create OrderState: " + e.getMessage(), e);
            return null;
        } finally {
            if (orderState != null) {
                try {
                    orderStatePool.release(orderState);
                } catch (PoolException e) {
                    LOGGER.error("Failed to release OrderState: " + e.getMessage(), e);
                }
            }
        }
    }

    public void setRandomOrderStateValues(int numberOfOrderStates) {
        Random random = new Random();

        for (int i = 0; i < numberOfOrderStates; i++) {
            String orderID = "Order" + i;
            char orderStatus = (char) (random.nextInt(26) + 'A');
            char prevOrdStatus = (char) (random.nextInt(26) + 'A'); // Random uppercase letter
            long leavesQty = random.nextLong() % 9991 + 10;
            long cumQty = random.nextLong() % 9991 + 10;
            double avgPx = random.nextDouble();
            long dayOrdQty = random.nextLong() % 9991 + 10;
            long dayCumQty = random.nextLong() % 9991 + 10;
            double dayAvgPx = random.nextDouble();
            String orderLinkID = "Link" + i;
            String text = "Text" + i;
            int counter = random.nextInt(1000);
            boolean oneRiskEligible = random.nextBoolean();
            boolean gtcGtdOmsTerminated = random.nextBoolean();

            // Create an OrderState object with random values
            OrderState orderState = createOrderState(orderID, orderStatus, prevOrdStatus, leavesQty,
                    cumQty, avgPx, dayOrdQty, dayCumQty, dayAvgPx, orderLinkID, text, counter,
                    oneRiskEligible, gtcGtdOmsTerminated);

            cachePool.putToCache(orderState.getOrderID(), orderState);

            // Make sure to release the object back to the pool when done
            if (orderState != null) {
                try {
                    orderStatePool.release(orderState);
                } catch (PoolException e) {
                    LOGGER.error("Failed to release OrderState: " + e.getMessage(), e);
                }
            }
        }
    }

    public static void main(String[] args) {
        SmartObjectPoolManager smartObjectPoolManager = SmartObjectPoolManager.getInstance();

        int poolSize = 3;
        String mapNamePrefix = "CacheMap_";

        LoadBalancer<CacheNode> loadBalancer = new RoundRobinLoadBalancer<>();
        CachePool cachePool = new CachePool(poolSize, mapNamePrefix, loadBalancer);

        OrderStateManager orderStateManager = new OrderStateManager(cachePool);
        orderStateManager.setRandomOrderStateValues(100);
    }
}


