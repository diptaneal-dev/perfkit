package featureToggle.telemetry;

import static org.junit.jupiter.api.Assertions.*;

import com.mkt.xac.eventshandling.DynamicEvent;
import com.mkt.xac.featureToggle.FeatureManager;
import com.mkt.xac.featureToggle.telemetry.KVMEventMonitor;
import com.mkt.xac.featureToggle.telemetry.KVMEventType;
import com.mkt.xac.featureToggle.telemetry.KVMTelemetryData;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class KVMEventMonitorTest {
    KVMEventMonitor<FeatureManager> kvmEventMonitor;
    @BeforeEach
    public void setup() {
        System.setProperty("env.config.path", "src/test/resources/test.environment.properties");
    }

    @AfterEach
    public void tearDown() {
        if (kvmEventMonitor != null ) {
            kvmEventMonitor.reset();
        }
    }

    @Test
    void testUpdateKVMUsageCounterEvent() {
        FeatureManager featureManager = Mockito.mock(FeatureManager.class);
        kvmEventMonitor = KVMEventMonitor.getInstance();

        DynamicEvent<FeatureManager, KVMEventType> event = new DynamicEvent<>(
                KVMEventType.KVM_USAGE_COUNTER, featureManager);
        kvmEventMonitor.update(event);

        KVMTelemetryData telemetryData = kvmEventMonitor.getTelemetryData(FeatureManager.class);

        assertNotNull(telemetryData);
        assertEquals(1, telemetryData.getCountKVMUsage());
    }

    @Test
    void testUpdateNonFeatureManagerEvent() {
        // Create a mock object that is not a FeatureManager
        Object nonFeatureManagerObject = new Object();
        KVMEventMonitor<Object> kvmEventMonitor = KVMEventMonitor.getInstance();

        DynamicEvent<Object, KVMEventType> event = new DynamicEvent<>(
                KVMEventType.KVM_USAGE_COUNTER, nonFeatureManagerObject);

        // Update the KVMEventMonitor with the event
        kvmEventMonitor.update(event);

        KVMTelemetryData telemetryData = kvmEventMonitor.getTelemetryData(Object.class);
        assertNull(telemetryData);
    }

}
