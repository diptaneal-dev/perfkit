package featureToggle;

import static org.junit.jupiter.api.Assertions.*;

import com.mkt.xac.featureToggle.FeatureManager;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;


public class FeatureManagerTest {
    private FeatureManager<Boolean> featureManager;

    @BeforeEach
    void setup(){
        System.setProperty("env.config.path", "src/test/resources/test.environment.properties");
        featureManager = FeatureManager.getInstance();;
    }

    @AfterEach
    void tearDown() {
        featureManager.reset();
    }

    @Test
    void testAddGroup() {
        featureManager.addFeatureGroup("group1");
        featureManager.addFeature("group1", "feature1", true);

        assertTrue(featureManager.getFeatureValue("group1", "feature1"));
    }

    @Test
    void testAddFeature() {
        featureManager.addFeatureGroup("group1");
        featureManager.addFeature("group1", "feature1", true);
        assertTrue(featureManager.getFeatureValue("group1", "feature1"));
    }

    @Test
    void testAddKVMWithNonExistentGroup() {
        FeatureManager<String> featureManager1 = FeatureManager.getInstance();
        assertThrows(IllegalArgumentException.class, () -> {
            featureManager1.addFeature("nonexistent_group", "feature1", "value1");
        });
    }

    @Test
    void testIsFeatureEnabled() {
        featureManager.addFeatureGroup("group1");
        featureManager.addFeature("group1", "feature1", true);
        assertTrue(featureManager.getFeatureValue("group1", "feature1"));
        assertThrows(IllegalArgumentException.class, () -> {
            featureManager.getFeatureValue("group1", "feature2");
        });
    }

    @Test
    void testIsFeatureEnabledInNonExistentGroup() {
        assertThrows(IllegalArgumentException.class, () -> {
            featureManager.getFeatureValue("nonexistent_group", "feature1");
        });
    }

    @Test
    void testCreateKVMWithValue() {
        FeatureManager<String> featureManager1 = FeatureManager.getInstance();
        featureManager1.addFeatureGroup("group1");
        featureManager1.createKVM("group1", "feature1", "value1");

        assertEquals("value1", featureManager1.getFeatureValue("group1", "feature1"));
    }

    @Test
    void testCreateKVMWithNullValue() {
        FeatureManager<String> featureManager1 = FeatureManager.getInstance();
        featureManager1.addFeatureGroup("group1");
        assertThrows(IllegalArgumentException.class, () -> {
            featureManager1.createKVM("group1", "feature1", null);
        });

        // Test that the group is not created if value is null
        assertFalse(featureManager1.getKVM("group1").containsKey("feature1"));
    }

    @Test
    void testCreateKVMWithDefaultValue() {
        FeatureManager<String> featureManager1 = FeatureManager.getInstance();
        featureManager1.addFeatureGroup("group1");
        featureManager1.createKVM("group1", "feature1", null, "defaultValue");

        // Test getting the default value from the KVM
        assertEquals("defaultValue", featureManager1.getFeatureValue("group1", "feature1"));
    }

    @Test
    void testGetFeatureValueWithDefault() {
        FeatureManager<String> featureManager1 = FeatureManager.getInstance();

        featureManager1.addFeatureGroup("group1");
        featureManager1.addFeature("group1", "feature1", "value1");

        // value is not null
        assertEquals("value1", featureManager1.getFeatureValueWithDefault("group1", "feature1", "defaultValue"));

        // group does  not exist
        assertThrows(IllegalArgumentException.class, () -> {
            featureManager1.getFeatureValueWithDefault("nonexistent_group", "feature1", "defaultValue");
        });

        // non-existent feature, it should return the default value
        assertEquals("defaultValue", featureManager1.getFeatureValueWithDefault("group1", "nonexistent_feature", "defaultValue"));
    }

    @Test
    void testGetKVM_PositiveCase() {
        featureManager.addFeatureGroup("group1");
        featureManager.addFeature("group1", "feature1", true);

        Map<String, Boolean> kvm = featureManager.getKVM("group1");

        assertTrue(kvm.containsKey("feature1"));
        assertTrue(kvm.get("feature1"));
    }

    @Test
    void testGetKVM_NegativeCase() {
        Map<String, Boolean> kvm = featureManager.getKVM("noSuchGroup");
        assertTrue(kvm.isEmpty());
    }

    @Test
    void testUpdateFeature_CreateNewGroup() {
        FeatureManager<Boolean> featureManager = FeatureManager.getInstance();
        featureManager.updateFeature("group1", "feature1", true);

        assertTrue(featureManager.getFeatureValue("group1", "feature1"));
    }

    @Test
    void testUpdateFeature_UpdateExistingFeature() {
        FeatureManager<Boolean> featureManager = FeatureManager.getInstance();
        featureManager.createKVM("group1", "feature1", true);

        featureManager.updateFeature("group1", "feature1", false);
        assertFalse(featureManager.getFeatureValue("group1", "feature1"));
    }

    @Test
    void testGetFeatureValue() {
        FeatureManager<String> featureManager1 = FeatureManager.getInstance();
        featureManager1.createKVM("group1", "feature1", "value1");

        assertEquals("value1", featureManager1.getFeatureValue("group1", "feature1"));

        assertThrows(IllegalArgumentException.class, () -> {
            featureManager1.getFeatureValue("group1", "nonexistent_feature");
        });

        // Test getting a feature from a non-existent group
        assertThrows(IllegalArgumentException.class, () -> {
            featureManager1.getFeatureValue("nonexistent_group", "feature1");
        });
    }

    @Test
    void testGetKVM() {
        FeatureManager<String> featureManager1 = FeatureManager.getInstance();

        featureManager1.addFeatureGroup("group1");
        featureManager1.addFeature("group1", "feature1", "value1");
        featureManager1.addFeature("group1", "feature2", "value2");

        // Test getting the KVM for an existing group
        Map<String, String> kvm = featureManager1.getKVM("group1");
        assertNotNull(kvm);
        assertEquals(2, kvm.size());
        assertEquals("value1", kvm.get("feature1"));
        assertEquals("value2", kvm.get("feature2"));

        // Test getting the KVM for a non-existent group
        Map<String, String> nonExistentKVM = featureManager1.getKVM("nonexistent_group");
        assertNotNull(nonExistentKVM);
        assertTrue(nonExistentKVM.isEmpty());
    }

    // Test creating a KVM when the group does not exist
    @Test
    void testCreateKVMForNonExistentGroup() {
        FeatureManager<String> featureManager1 = FeatureManager.getInstance();
        featureManager1.createKVM("nonexistent_group", "feature1", "value1");

        Map<String, String> kvm = featureManager1.getKVM("nonexistent_group");

        assertNotNull(kvm);
        assertEquals(1, kvm.size());
        assertEquals("value1", kvm.get("feature1"));

        // Test creating a KVM with a null value
        assertThrows(IllegalArgumentException.class, () -> {
            featureManager1.createKVM("group1", "feature2", null);
        });
    }

    @Test
    void testRemoveFeature() {
        FeatureManager<String> featureManager1 = FeatureManager.getInstance();

        featureManager1.addFeatureGroup("group1");
        featureManager1.addFeature("group1", "feature1", "value1");

        String featureValue = featureManager1.getFeatureValue("group1", "feature1");
        assertNotNull(featureValue);
        assertEquals("value1", featureValue);

        featureManager1.removeFeature("group1", "feature1");
        assertThrows(IllegalArgumentException.class, () -> {
            featureManager1.getFeatureValue("group1", "feature1");
        });

        // Check if the group is removed when it's empty
        Map<String, String> group1KVM = featureManager1.getKVM("group1");
        assertTrue(group1KVM.isEmpty());

        // Try removing a non-existing feature
        assertDoesNotThrow(() -> featureManager1.removeFeature("group1", "nonexistent_feature"));

        // Try removing a feature from a non-existing group
        assertDoesNotThrow(() -> featureManager1.removeFeature("nonexistent_group", "feature1"));
    }

}
