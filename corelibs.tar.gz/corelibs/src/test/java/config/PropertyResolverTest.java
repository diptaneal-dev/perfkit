package config;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;

import static org.junit.jupiter.api.Assertions.*;


import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.anyString;

@RunWith(MockitoJUnitRunner.class)
public class PropertyResolverTest {
    private TestConfig config;
    private EnvironmentManager mockEnvironmentManager;

    @BeforeEach
    public void setUp() {
        config = new TestConfig();
        System.setProperty("env.config.path", "src/test/resources/test.environment.properties");

        mockEnvironmentManager = Mockito.mock(EnvironmentManager.class);
        try (MockedStatic<EnvironmentManager> mocked = Mockito.mockStatic(EnvironmentManager.class)) {
            mocked.when(EnvironmentManager::getInstance).thenReturn(mockEnvironmentManager);
        }
    }

    @Test
    public void mockEnvironmentManagerTest() {
        assertNotNull(mockEnvironmentManager);
    }

    @Test
    public void testEnvironmentManagerMock() {
        try (MockedStatic<EnvironmentManager> mocked = Mockito.mockStatic(EnvironmentManager.class)) {
            EnvironmentManager mockEnvironmentManager = Mockito.mock(EnvironmentManager.class);
            mocked.when(EnvironmentManager::getInstance).thenReturn(mockEnvironmentManager);
            EnvironmentManager environmentManager1 = EnvironmentManager.getInstance();
            assertNotNull(environmentManager1);
        }
    }

    @Test
    public void testResolve() {
        try (MockedStatic<EnvironmentManager> mocked = Mockito.mockStatic(EnvironmentManager.class)) {
            mocked.when(EnvironmentManager::getInstance).thenReturn(mockEnvironmentManager);
            Mockito.when(mockEnvironmentManager.getVariable("test")).thenReturn("ExpectedValue");

            String resolved = PropertyResolver.resolve("${test}");
            assertEquals("ExpectedValue", resolved);

            String unresolved = PropertyResolver.resolve("regularValue");
            assertEquals("regularValue", unresolved);
        }
    }

    @Test
    public void testResolveAnnotatedProperties() {
        try (MockedStatic<EnvironmentManager> mocked = Mockito.mockStatic(EnvironmentManager.class)) {
            mocked.when(EnvironmentManager::getInstance).thenReturn(mockEnvironmentManager);
            Mockito.when(mockEnvironmentManager.getVariable(anyString())).thenAnswer(invocation -> {
                String arg = invocation.getArgument(0);
                switch (arg) {
                    case "url": return "ExpectedUrl";
                    case "token": return "ExpectedToken";
                    default: return null;
                }
            });

            PropertyResolver.resolveAnnotatedProperties(config);
            assertEquals("ExpectedUrl", config.getUrl());
            assertEquals("ExpectedToken", config.getToken());
            assertEquals("${ignored}", config.getNonAnnotatedField());
        }
    }

    private class TestConfig {
        @ResolveProperty
        private String url = "${url}";
        @ResolveProperty
        private String token = "${token}";
        private String nonAnnotatedField = "${ignored}";

        public String getUrl() {
            return url;
        }

        public String getToken() {
            return token;
        }

        public String getNonAnnotatedField() {
            return nonAnnotatedField;
        }
    }

    private class TestConfigWithFinalField {
        @ResolveProperty
        private final String nonModifiableField = "initialValue";

        public String getNonModifiableField() {
            return nonModifiableField;
        }
    }
}
