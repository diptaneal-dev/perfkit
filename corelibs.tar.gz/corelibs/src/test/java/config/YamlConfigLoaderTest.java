package config;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;

class YAMLConfigLoaderTest {

    @TempDir
    Path tempDir;

    @Test
    void testLoadConfig_Success() throws IOException {
        String content = "classname: Test\ninitialPoolSize: 25";
        File tempFile = createTempFileWithContent(content);

        TestConfig result = YamlConfigLoader.loadConfig(tempFile.getAbsolutePath(), TestConfig.class);

        assertNotNull(result);
        assertEquals("Test", result.getClassname());
        assertEquals(25, result.getInitialPoolSize());
    }

    @Test
    void testLoadConfig_FileNotFound() {
        String nonExistentFilePath = "/path/to/non/existent/file.yaml";
        TestConfig result = YamlConfigLoader.loadConfig(nonExistentFilePath, TestConfig.class);
        assertNull(result);
    }

    @Test
    void testLoadConfig_InvalidContent() throws IOException {
        String invalidContent = "invalid: yaml: content";
        File tempFile = createTempFileWithContent(invalidContent);

        TestConfig result = YamlConfigLoader.loadConfig(tempFile.getAbsolutePath(), TestConfig.class);
        assertNull(result);
    }

    private File createTempFileWithContent(String content) throws IOException {
        File tempFile = tempDir.resolve("tempFile.yaml").toFile();
        try (FileWriter writer = new FileWriter(tempFile)) {
            writer.write(content);
        }
        return tempFile;
    }

    public static class TestConfig {
        private String classname;
        private int initialPoolSize;

        public String getClassname() {
            return classname;
        }

        public void setClassname(String classname) {
            this.classname = classname;
        }

        public void setInitialPoolSize(int initialPoolSize) {
            this.initialPoolSize = initialPoolSize;
        }

        public int getInitialPoolSize() {
            return initialPoolSize;
        }
    }
}
