package config;

import static org.junit.jupiter.api.Assertions.*;

import com.mkt.xac.config.ApplicationConfig;
import com.mkt.xac.config.YamlConfigLoader;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Path;

import static org.mockito.Mockito.*;

import com.mkt.xac.smartpool.config.SmartPoolManagerConfig;

import java.nio.file.Files;

class YamlConfigLoaderTest {
    private static final String TEST_YAML_STRING = "testKey: testValue";

    @TempDir
    Path tempDir;

    @Test
    void testLoadConfigFromFile_Success() throws IOException {
        Path testFile = tempDir.resolve("test.yaml");
        String yamlContent = "eodFilePath: /path/to/eodfile";
        Files.write(testFile, yamlContent.getBytes());

        SmartPoolManagerConfig mockConfig = mock(SmartPoolManagerConfig.class);
        YamlConfigLoader.loadConfigFromFile(testFile.toString(), mockConfig);

        verify(mockConfig).loadConfigFromString(yamlContent);
    }

    @Test
    void testLoadConfig_Success() throws IOException {
        Path testFile = tempDir.resolve("test.yaml");
        String yamlContent = "eodFilePath: /path/to/eodfile";
        Files.write(testFile, yamlContent.getBytes());

        SmartPoolManagerConfig loadedConfig = YamlConfigLoader.loadConfig(testFile.toString(), SmartPoolManagerConfig.class);

        assertNotNull(loadedConfig);
        assertEquals("/path/to/eodfile", loadedConfig.getEodFilePath());
    }

    @Test
    void testLoadConfigFromString_Success() {
        ApplicationConfig mockConfig = mock(ApplicationConfig.class);
        YamlConfigLoader.loadConfigFromString(TEST_YAML_STRING, mockConfig);

        verify(mockConfig).loadConfigFromString(TEST_YAML_STRING);
    }

    @Test
    void testLoadConfig_FileNotFound() {
        String nonExistentFilePath = "nonexistent.yaml";
        assertNull(YamlConfigLoader.loadConfig(nonExistentFilePath, ApplicationConfig.class));
    }
}
