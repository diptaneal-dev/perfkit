package config;

import config.exceptions.EnvironmentManagerInitializationException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EnvironmentManagerTest {

    @Test
    void getInstance_ShouldThrowException_WhenInvalidPath() {
        String originalProperty = System.getProperty("env.config.path");
        try {
            System.setProperty("env.config.path", "/invalid/path");
            assertThrows(EnvironmentManagerInitializationException.class,
                    EnvironmentManager::getInstance);
        } finally {
            // Clean up: Reset the system property to its original state
            if (originalProperty != null) {
                System.setProperty("env.config.path", originalProperty);
            } else {
                System.clearProperty("env.config.path");
            }
        }
    }
}