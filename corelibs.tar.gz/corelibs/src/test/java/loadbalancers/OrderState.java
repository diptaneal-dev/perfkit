package loadbalancers;

import java.io.Serializable;

public class OrderState implements Serializable {
    private String orderID;
    private char orderStatus;
    private char prevOrdStatus;
    private long leavesQty;
    private long cumQty;
    private double avgPx;
    private long dayOrdQty;
    private long dayCumQty;
    private double dayAvgPx;
    private String orderLinkID;
    private String text;
    private int counter;
    private boolean oneRiskEligible = false;
    private boolean gtcGtdOmsTerminated = false;

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public char getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(char orderStatus) {
        this.orderStatus = orderStatus;
    }

    public char getPrevOrdStatus() {
        return prevOrdStatus;
    }

    public void setPrevOrdStatus(char prevOrdStatus) {
        this.prevOrdStatus = prevOrdStatus;
    }

    public long getLeavesQty() {
        return leavesQty;
    }

    public void setLeavesQty(long leavesQty) {
        this.leavesQty = leavesQty;
    }

    public long getCumQty() {
        return cumQty;
    }

    public void setCumQty(long cumQty) {
        this.cumQty = cumQty;
    }

    public double getAvgPx() {
        return avgPx;
    }

    public void setAvgPx(double avgPx) {
        this.avgPx = avgPx;
    }

    public long getDayOrdQty() {
        return dayOrdQty;
    }

    public void setDayOrdQty(long dayOrdQty) {
        this.dayOrdQty = dayOrdQty;
    }

    public long getDayCumQty() {
        return dayCumQty;
    }

    public void setDayCumQty(long dayCumQty) {
        this.dayCumQty = dayCumQty;
    }

    public double getDayAvgPx() {
        return dayAvgPx;
    }

    public void setDayAvgPx(double dayAvgPx) {
        this.dayAvgPx = dayAvgPx;
    }

    public String getOrderLinkID() {
        return orderLinkID;
    }

    public void setOrderLinkID(String orderLinkID) {
        this.orderLinkID = orderLinkID;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    public boolean isOneRiskEligible() {
        return oneRiskEligible;
    }

    public void setOneRiskEligible(boolean oneRiskEligible) {
        this.oneRiskEligible = oneRiskEligible;
    }

    public boolean isGtcGtdOmsTerminated() {
        return gtcGtdOmsTerminated;
    }

    public void setGtcGtdOmsTerminated(boolean gtcGtdOmsTerminated) {
        this.gtcGtdOmsTerminated = gtcGtdOmsTerminated;
    }
}
