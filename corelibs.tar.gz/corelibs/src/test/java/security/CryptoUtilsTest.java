package security;

import org.junit.jupiter.api.Test;
import static org.junit.Assert.assertEquals;

public class CryptoUtilsTest {

    @Test
    public void testEncryptDecrypt() throws Exception {
        byte[] key = CryptoUtils.generateKey();
        System.out.println(key);
        String originalValue = "strongValue123";
        String encryptedValue = CryptoUtils.encrypt(originalValue, key);
        String decryptedValue = CryptoUtils.decrypt(encryptedValue, key);

        assertEquals("Decrypted value should match the original value", originalValue, decryptedValue);
    }

}
