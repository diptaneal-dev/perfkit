package security;

import javax.crypto.Cipher;
import java.security.Provider;
import java.security.Security;

public class CryptoStrengthTest {
    public static void listCryptoProviders() {
        for (Provider provider : Security.getProviders()) {
            System.out.println(provider.getName());
            for (String key : provider.stringPropertyNames()) {
                System.out.println("\t" + key + "\t" + provider.getProperty(key));
            }
        }
    }

    public static void main(String[] args) {
        try {
            listCryptoProviders();

            int maxKeyLen = Cipher.getMaxAllowedKeyLength("AES");
            System.out.println("Max AES Key Length: " + maxKeyLen);
            if (maxKeyLen > 128) {
                System.out.println("Unlimited Strength Jurisdiction Policy files are installed.");
            } else {
                System.out.println("Unlimited Strength Jurisdiction Policy files are NOT installed.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
