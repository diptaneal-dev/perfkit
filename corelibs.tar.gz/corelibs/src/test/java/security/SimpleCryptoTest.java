package security;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

public class SimpleCryptoTest {

    private static final String ALGORITHM = "AES";
    private static final String CHARSET = "UTF-8";

    public static void main(String[] args) {
        try {
            byte[] keyBytes = new byte[16];
            SecretKeySpec secretKey = new SecretKeySpec(keyBytes, ALGORITHM);

            Cipher cipher = Cipher.getInstance(ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);

            String originalValue = "scttcs123";
            byte[] encryptedValue = cipher.doFinal(originalValue.getBytes(CHARSET));
            String encryptedString = Base64.getEncoder().encodeToString(encryptedValue);

            System.out.println("Encrypted: " + encryptedString);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
