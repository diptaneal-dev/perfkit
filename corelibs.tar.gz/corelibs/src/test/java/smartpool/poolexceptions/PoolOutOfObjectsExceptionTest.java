package smartpool.poolexceptions;

import com.mkt.xac.smartpool.poolexceptions.PoolOutOfObjectsException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PoolOutOfObjectsExceptionTest {

    @Test
    public void testExceptionWithMessage() {
        String message = "OutOfObjects Test Message";
        PoolOutOfObjectsException exception = new PoolOutOfObjectsException(message);

        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

}