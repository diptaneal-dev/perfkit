package smartpool.poolexceptions;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class PoolExceptionTest {

    @Test
    public void testExceptionWithMessage() {
        String message = "Test Message";
        PoolException exception = new PoolException(message);

        assertEquals(message, exception.getMessage());
        assertNull(exception.getCause());
    }

    @Test
    public void testExceptionWithMessageAndCause() {
        String message = "Test Message with Cause";
        Exception cause = new RuntimeException("Cause exception");
        PoolException exception = new PoolException(message, cause);

        assertEquals(message, exception.getMessage());
        assertTrue(exception.getCause() instanceof RuntimeException);
        assertEquals("Cause exception", exception.getCause().getMessage());
    }
}
