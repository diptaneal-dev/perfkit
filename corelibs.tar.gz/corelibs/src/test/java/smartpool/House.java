package smartpool;

public class House implements Resettable {
    private String address;
    private int rooms;

    @Override
    public void reset() {
        address = null;
        rooms = 0;
    }

    public House() {
        this.address = "Default Address";
        this.rooms = 3;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getRooms() {
        return rooms;
    }

    public void setRooms(int rooms) {
        this.rooms = rooms;
    }

}
