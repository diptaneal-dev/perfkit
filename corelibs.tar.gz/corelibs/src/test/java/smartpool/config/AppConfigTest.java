package smartpool.config;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class AppConfigTest {

    @Test
    public void testSmartPoolManagerConfigSettersAndGetters() {
        AppConfig appConfig = new AppConfig();
        AppConfig.SmartPoolManagerConfig smartPoolManagerConfig = new AppConfig.SmartPoolManagerConfig();
        String eodFilePath = "/path/to/eod/file";

        smartPoolManagerConfig.setEodFilePath(eodFilePath);
        appConfig.setSmartPoolManagerConfig(smartPoolManagerConfig);

        assertNotNull(appConfig.getSmartPoolManagerConfig());
        assertEquals(eodFilePath, appConfig.getSmartPoolManagerConfig().getEodFilePath());
    }

    @Test
    public void testToStringMethods() {
        AppConfig appConfig = new AppConfig();
        AppConfig.SmartPoolManagerConfig smartPoolManagerConfig = new AppConfig.SmartPoolManagerConfig();
        String eodFilePath = "/path/to/eod/file";
        smartPoolManagerConfig.setEodFilePath(eodFilePath);
        appConfig.setSmartPoolManagerConfig(smartPoolManagerConfig);

        assertEquals("SmartPoolManager{eodFilePath='" + eodFilePath + "'}", smartPoolManagerConfig.toString());
        assertEquals("AppConfig{smartPoolManager=" + smartPoolManagerConfig.toString() + "}", appConfig.toString());
    }
}
