package smartpool.config;

import static org.junit.jupiter.api.Assertions.*;

import config.YamlConfigLoader;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

class ApplicationConfigTest {
    private SmartPoolManagerConfig config;

    @BeforeEach
    void setUp() {
        config = new SmartPoolManagerConfig();
    }

    @Test
    void testLoadConfigFromFile_Success() throws IOException {
        YamlConfigLoader.loadConfigFromFile("src/test/resources/testSmartObjectPool.yaml", config);
        assertNotNull(config.getEodFilePath());
        assertEquals("/Users/diptanealroy/dev/threading/corelibs/data/eodfile", config.getEodFilePath());
    }

    @Test
    void testLoadConfigFromString_Success() {
        String yamlContent = "smartPoolManagerConfig:\n  eodFilePath: \"/Users/diptanealroy/dev/threading/corelibs/data/eodfile\"";
        config.loadConfigFromString(yamlContent);
        assertNotNull(config.getEodFilePath());
        assertEquals("/Users/diptanealroy/dev/threading/corelibs/data/eodfile", config.getEodFilePath());
    }

    @Test
    void testLoadConfigFromFile_FileNotFound() {
        assertThrows(IOException.class, () -> {
            YamlConfigLoader.loadConfigFromFile("nonexistent.yaml", config);
        });
    }

}
