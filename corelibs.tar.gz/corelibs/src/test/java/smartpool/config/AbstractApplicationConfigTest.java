package smartpool.config;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.Mockito;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AbstractApplicationConfigTest {

    private AbstractApplicationConfig config;
    private final String testYamlContent = "key: value";

    @TempDir
    Path tempDir;

    @BeforeEach
    void setUp() {
        config = Mockito.spy(new AbstractApplicationConfig() {
            @Override
            public void loadConfigFromString(String yamlString) {
            }
        });
    }

    @Test
    void testLoadConfigFromFile_Success() throws IOException {
        Path testFile = tempDir.resolve("test.yaml");
        Files.write(testFile, testYamlContent.getBytes(StandardCharsets.UTF_8));

        config.loadConfigFromFile(testFile.toString());

        verify(config).loadConfigFromString(testYamlContent);
    }

    @Test
    void testLoadConfigFromFile_FileNotFound() {
        config.loadConfigFromFile("nosuchfile.yaml");
        verify(config, never()).loadConfigFromString(anyString());
    }

    @Test
    void testParseYamlToMap() {
        Map<String, Object> result = config.parseYamlToMap("key: value");

        assertNotNull(result);
        assertEquals("value", result.get("key"));
    }

    @Test
    void testParseYamlToMap_InvalidYaml() {
        Map<String, Object> result = config.parseYamlToMap("** invalid yaml ::");
        assertNull(result);
    }
}
