package smartpool;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import smartpool.poolexceptions.PoolException;

public class SmartPoolManagerApp {
    private static final Logger LOGGER = LogManager.getLogger(SmartPoolManagerApp.class);

    public static void main(String[] args) throws PoolException {
        SmartObjectPoolManager manager = SmartObjectPoolManager.getInstance();
        manager.registerPool(Car.class, Car::new, 20, 100);
        manager.registerPool(House.class, House::new, 20, 100);

        ObjectPool<Car> carPool = manager.getPool(Car.class);
        Car car = carPool.get();
        carPool.release(car);

        ObjectPool<House> housePool = manager.getPool(House.class);
        House house = housePool.get();
        house.setAddress("Hadapsar, Pune");
        housePool.release(house);

        for (int i =0; i < 120; i++) {
            ObjectPool<Car> carPool1 = manager.getPool(Car.class);
            carPool1.get();
        }

        for (int i=0; i < 25; i++){
            ObjectPool<House> housePool1 = manager.getPool(House.class);
            House house1 = housePool1.get();
            if (i%5 == 0) {
                housePool1.release(house1);
            }
        }

        LOGGER.info(SmartObjectPoolMonitor.getInstance().getPoolStatsAsJson(Car.class));
        LOGGER.info(SmartObjectPoolMonitor.getInstance().getPoolStatsAsJson(House.class));

        LOGGER.info(SmartObjectPoolMonitor.getInstance().endOfDaySummary());
        SmartObjectPoolManager.getInstance().savePoolSizes("data/eodfile");
    }
}
