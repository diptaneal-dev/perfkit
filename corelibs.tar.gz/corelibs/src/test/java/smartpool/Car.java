package smartpool;

public class Car implements Resettable {
    private String model;
    private int year;

    @Override
    public void reset() {
        model = "Default Model";
        year = 2020;
    }

    public Car() {
        this.model = "Default Model";
        this.year = 2020;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}
