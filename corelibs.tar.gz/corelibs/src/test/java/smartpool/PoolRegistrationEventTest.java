package smartpool;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.Test;

class PoolRegistrationEventTest {

    @Test
    void testPoolTypeIsCorrectlyAssigned() {
        Class<?> expectedPoolType = String.class;
        SmartObjectPoolManager mockPoolManager = mock(SmartObjectPoolManager.class);

        PoolRegistrationEvent event = new PoolRegistrationEvent(expectedPoolType, mockPoolManager);
        assertEquals(expectedPoolType, event.getPoolType(), "The pool type should be correctly set in the event.");
    }

    @Test
    void testPoolManagerIsCorrectlyAssigned() {
        Class<?> poolType = String.class;
        SmartObjectPoolManager expectedPoolManager = mock(SmartObjectPoolManager.class);

        PoolRegistrationEvent event = new PoolRegistrationEvent(poolType, expectedPoolManager);
        assertSame(expectedPoolManager, event.getPoolManager(), "The pool manager should be correctly set in the event.");
    }
}
