package smartpool;

public class Book implements Resettable {
    private String title;
    private String author;

    @Override
    public void reset() {
        title = null;
        author = null;
    }

    public Book() {
        this.title = "Default Title";
        this.author = "Default Author";
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

}
