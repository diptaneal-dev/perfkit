package smartpool;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import org.powermock.reflect.Whitebox;
import org.yaml.snakeyaml.Yaml;
import smartpool.config.AppConfig;
import stats.PoolStats;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

class SmartObjectPoolManagerTest {
    private SmartObjectPoolMonitor monitor;
    private SmartObjectPoolManager manager;
    private Map<Class<?>, ObjectPool<?>> mockPools;

    @BeforeEach
    public void setUp() {
        AppConfig mockConfig = mock(AppConfig.class);
        AppConfig.SmartPoolManagerConfig mockPoolConfig = mock(AppConfig.SmartPoolManagerConfig.class);
        when(mockConfig.getSmartPoolManagerConfig()).thenReturn(mockPoolConfig);

        manager = SmartObjectPoolManager.getInstance();
        monitor = SmartObjectPoolMonitor.getInstance();
        mockPools = new ConcurrentHashMap<>();

        ObjectPool<String> mockPool = mock(ObjectPool.class);
        mockPools.put(String.class, mockPool);
        Whitebox.setInternalState(manager, "pools", mockPools);

        try {
            Field configField = SmartObjectPoolManager.class.getDeclaredField("config");
            configField.setAccessible(true);
            configField.set(manager, mockConfig);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new RuntimeException("Failed to set mock config", e);
        }
    }

    @AfterEach
    public void tearDown() {
        monitor.reset();
        manager.reset();
    }

    @Test
    public void testLoadAndInitializePools() {
        when(manager.getEodFilePath()).thenReturn("path/to/yaml");
        try (InputStream mockInputStream = mock(InputStream.class)) {
            when(Files.newInputStream(Paths.get("path/to/yaml"))).thenReturn(mockInputStream);

            manager.loadAndInitializePools();

        } catch (Exception e) {
        }
    }

    @Test
    public void testSavePoolSizes() {
        when(manager.getEodFilePath()).thenReturn("path/to/save");

        try (OutputStream mockOutputStream = mock(OutputStream.class)) {
            when(Files.newOutputStream(Paths.get("path/to/save"))).thenReturn(mockOutputStream);

            manager.savePoolSizes("path/to/save");

        } catch (Exception e) {
        }
    }

    @Test
    public void testGetPool_Success() {
        ObjectPool<String> returnedPool = manager.getPool(String.class);

        assertNotNull(returnedPool);
        assertEquals(mock(ObjectPool.class).getClass(), returnedPool.getClass());
    }

    @Test
    public void testGetPool_NotRegistered() {
        ObjectPool<Integer> returnedPool = manager.getPool(Integer.class);
        assertNull(returnedPool);
    }

    public static void injectIntoPrivateField(Object object, String fieldName, Object valueToInject) throws Exception {
        Field field = object.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        ((Map) field.get(object)).putAll((Map) valueToInject);
    }

    private static final String YAML_CONTENT = "!!smartpool.SavedPoolConfig\n" +
            "pools:\n" +
            "- {initialSize: 176, poolType: smartpool.Car}\n" +
            "- {initialSize: 22, poolType: java.lang.String}\n" +
            "- {initialSize: 20, poolType: smartpool.House}";

    @Test
    public void testSavePoolSizes_success() throws Exception {
        SmartObjectPoolManager manager = SmartObjectPoolManager.getInstance();

        PoolStats mockPoolStats = mock(PoolStats.class);
        when(mockPoolStats.getInitialPoolSize()).thenReturn(10L);
        when(mockPoolStats.getPeakSize()).thenReturn(20L);

        SmartObjectPoolMonitor monitorInstance = SmartObjectPoolMonitor.getInstance();
        Map<Class<?>, PoolStats> dummyPoolStatsMap = new HashMap<>();
        dummyPoolStatsMap.put(String.class, mockPoolStats);

        injectIntoPrivateField(monitorInstance, "poolStatsMap", dummyPoolStatsMap);

        String testPath = "testPath.yaml";
        manager.savePoolSizes(testPath);

        Yaml yaml = new Yaml();
        Path path = Paths.get(testPath);
        try (InputStream in = Files.newInputStream(path)) {
            SavedPoolConfig loadedConfig = (SavedPoolConfig) yaml.load(in);

            List<PoolRecord> loadedPools = loadedConfig.getPools();

            assertEquals(1, loadedPools.size());
            PoolRecord loadedRecord = loadedPools.get(0);
            assertEquals("java.lang.String", loadedRecord.getPoolType());
            assertEquals(22, loadedRecord.getInitialSize());
        } catch ( IOException e) {
            throw new RuntimeException("Failed to read the saved EOD pool sizes", e);
        }
        finally {
            // Clean up the test file
            try {
                Files.deleteIfExists(path);
            } catch (IOException e) {
                throw new RuntimeException("Failed to delete the test file: " + testPath, e);
            }
        }
    }
}
