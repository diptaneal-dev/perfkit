package smartpool;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.mkt.xac.config.FileProvider;
import com.mkt.xac.dbclients.dbclients.DatabaseClient;
import com.mkt.xac.smartpool.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import com.mkt.xac.smartpool.config.SavedPoolConfig;
import com.mkt.xac.smartpool.config.SmartPoolManagerConfig;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

class SmartObjectPoolManagerTest {
    private SmartObjectPoolMonitor monitor;
    private SmartObjectPoolManager manager;
    private Map<Class<?>, ObjectPool<?>> mockPools;
    @Mock
    private DatabaseClient mockDatabaseClient;

    @BeforeEach
    public void setUp() {
        System.setProperty("env.config.path", "src/test/resources/test.environment.properties");
        MockitoAnnotations.openMocks(this);

        monitor = SmartObjectPoolMonitor.getInstance();
        when(mockDatabaseClient.isConnected()).thenReturn(true);

        injectDatabaseClientIntoMonitor(mockDatabaseClient);

        SmartPoolManagerConfig mockPoolConfig = mock(SmartPoolManagerConfig.class);
        when(mockPoolConfig.getEodFilePath()).thenReturn("/path/to/eodfile");
        manager = SmartObjectPoolManager.getInstance();
        setupManager(mockPoolConfig);
    }

    private void injectDatabaseClientIntoMonitor(DatabaseClient databaseClient) {
        if (monitor == null || databaseClient == null) {
            throw new IllegalStateException("Monitor or DatabaseClient is not initialized");
        }
        try {
            Field dbClientField = SmartObjectPoolMonitor.class.getDeclaredField("databaseClient");
            dbClientField.setAccessible(true);
            dbClientField.set(monitor, databaseClient);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new RuntimeException("Failed to inject mock DatabaseClient", e);
        }
    }

    private void setupManager(SmartPoolManagerConfig mockPoolConfig) {
        try {
            Field configField = SmartObjectPoolManager.class.getDeclaredField("config");
            configField.setAccessible(true);
            configField.set(manager, mockPoolConfig);

            mockPools = new ConcurrentHashMap<>();
            ObjectPool<String> mockPool = mock(ObjectPool.class);
            mockPools.put(String.class, mockPool);

            Field poolsField = SmartObjectPoolManager.class.getDeclaredField("pools");
            poolsField.setAccessible(true);
            poolsField.set(manager, mockPools);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new RuntimeException("Failed to set mock config or pools", e);
        }
    }

    @AfterEach
    public void tearDown() {
        monitor.reset();
        manager.reset();
    }

    @Test
    public void testLoadAndInitializePools() throws IOException {
        FileProvider mockFileProvider = mock(FileProvider.class);
        when(mockFileProvider.newInputStream(any(Path.class)))
                .thenReturn(new ByteArrayInputStream("...".getBytes()));

        String eodFilePath = "path/to/yaml";
        String yamlContent = "java.lang.String: 10\njava.lang.Integer: 20";

        when(mockFileProvider.newInputStream(any(Path.class)))
                .thenReturn(new ByteArrayInputStream(yamlContent.getBytes(StandardCharsets.UTF_8)));
        when(manager.getEodFilePath()).thenReturn(eodFilePath);

        manager.loadAndInitializePools();

        ObjectPool<String> returnedPool = manager.getPool(String.class);
        assertNotNull(returnedPool);
    }

    @Test
    public void testSavePoolSizes() {
        when(manager.getEodFilePath()).thenReturn("path/to/save");

        try (OutputStream mockOutputStream = mock(OutputStream.class)) {
            when(Files.newOutputStream(Paths.get("path/to/save"))).thenReturn(mockOutputStream);

            manager.savePoolSizes("path/to/save");

        } catch (Exception e) {
        }
    }

    @Test
    public void testGetPool_Success() {
        ObjectPool<String> returnedPool = manager.getPool(String.class);

        assertNotNull(returnedPool);
        assertEquals(mock(ObjectPool.class).getClass(), returnedPool.getClass());
    }

    @Test
    public void testGetPool_NotRegistered() {
        ObjectPool<Integer> returnedPool = manager.getPool(Integer.class);
        assertNull(returnedPool);
    }

    public static void injectIntoPrivateField(Object object, String fieldName, Object valueToInject) throws Exception {
        Field field = object.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        ((Map) field.get(object)).putAll((Map) valueToInject);
    }

    private static final String YAML_CONTENT = "!!smartpool.config.SavedPoolConfig\n" +
            "pools:\n" +
            "- {initialSize: 176, poolType: smartpool.Car}\n" +
            "- {initialSize: 22, poolType: java.lang.String}\n" +
            "- {initialSize: 20, poolType: smartpool.House}";

    @Test
    public void testSavePoolSizes_success() throws Exception {
        SmartObjectPoolManager manager = SmartObjectPoolManager.getInstance();

        PoolTelemetryData mockPoolStats = mock(PoolTelemetryData.class);
        when(mockPoolStats.getInitialPoolSize()).thenReturn(10L);
        when(mockPoolStats.getPeakSize()).thenReturn(20L);

        SmartObjectPoolMonitor monitorInstance = SmartObjectPoolMonitor.getInstance();
        Map<Class<?>, PoolTelemetryData> dummyPoolStatsMap = new HashMap<>();
        dummyPoolStatsMap.put(String.class, mockPoolStats);

        injectIntoPrivateField(monitorInstance, "poolStatsMap", dummyPoolStatsMap);

        String testPath = "testPath.yaml";
        manager.savePoolSizes(testPath);

        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
        Path path = Paths.get(testPath);
        try (InputStream in = Files.newInputStream(path)) {
            SavedPoolConfig loadedConfig = mapper.readValue(in, SavedPoolConfig.class);
            List<PoolRecord> loadedPools = loadedConfig.getPools();

            assertEquals(1, loadedPools.size());
            PoolRecord loadedRecord = loadedPools.get(0);
            assertEquals("java.lang.String", loadedRecord.getPoolType());
            assertEquals(22, loadedRecord.getInitialSize());
        } catch (IOException e) {
            throw new RuntimeException("Failed to read the saved EOD pool sizes", e);
        } finally {
            try {
                Files.deleteIfExists(path);
            } catch (IOException e) {
                throw new RuntimeException("Failed to delete the test file: " + testPath, e);
            }
        }
    }
}
