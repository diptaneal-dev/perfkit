package smartpool;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import smartpool.poolexceptions.PoolException;

public class ObjectPoolApp {
    private static final Logger LOGGER = LogManager.getLogger(SmartObjectPoolMonitor.class);

    public static void main(String[] args) throws PoolException {
        ObjectPool<Car> carPool = new ObjectPool<>(Car::new, Car.class, 2, 10);
        ObjectPool<Book> bookPool = new ObjectPool<>(Book::new, Book.class, 2, 10);
        ObjectPool<House> housePool = new ObjectPool<>(House::new, House.class, 2, 10);

        // Borrow objects from the pool
        Car car1 = carPool.get();
        Book book1 = bookPool.get();
        House house1 = housePool.get();

        car1.setModel("Ford Mustang");
        car1.setYear(1999);
        book1.setAuthor("Arthur Conan Doyle");
        book1.setTitle("The Blue Curbancle");
        house1.setAddress("Pune Hadapsar");
        house1.setRooms(50);

        LOGGER.info("First set of object created from Pool");
        if (SmartObjectPoolMonitor.getInstance().getStatsForClass(Car.class) != null) {
            LOGGER.info("Poolstats: {} ", SmartObjectPoolMonitor.getInstance().getStatsForClass(Car.class).convertTelemetryDataToJSON());
        }

/*        carPool.release(car1);
        bookPool.release(book1);
        housePool.release(house1);*/

        Car car2 = carPool.get();
        Book book2 = bookPool.get();
        House house2 = housePool.get();
        LOGGER.info("Second set of object created from Pool");
        if (SmartObjectPoolMonitor.getInstance().getStatsForClass(Car.class) != null) {
            LOGGER.info("Poolstats: {} ", SmartObjectPoolMonitor.getInstance().getStatsForClass(Car.class).convertTelemetryDataToJSON());
        }

        Car car3 = carPool.get();
        Book book3 = bookPool.get();
        House house3 = housePool.get();

        LOGGER.info("Car Model is: {}", car3.getModel());
        LOGGER.info("Car Model is: {}", car2.getModel());
        if (SmartObjectPoolMonitor.getInstance().getStatsForClass(Car.class) != null) {
            LOGGER.info("Poolstats: {} ", SmartObjectPoolMonitor.getInstance().getStatsForClass(Car.class).convertTelemetryDataToJSON());
        }

        // Get pool metrics
        LOGGER.info("Cars in Pool: {}", carPool.getAvailableObjects());
        LOGGER.info("Books in Pool: {}", bookPool.getAvailableObjects());
        LOGGER.info("Houses in Pool: {}", housePool.getAvailableObjects());

        Car car4 = carPool.get();
        Book book4 = bookPool.get();
        House house4 = housePool.get();

        car4 = carPool.get();
        book4 = bookPool.get();
        house4 = housePool.get();
        car4 = carPool.get();
        book4 = bookPool.get();
        house4 = housePool.get();

        final String carPoolStatsJson = SmartObjectPoolMonitor.getInstance().getPoolStatsAsJson(Car.class);
        final String bookPoolStatsJson = SmartObjectPoolMonitor.getInstance().getPoolStatsAsJson(Book.class);
        final String housePoolStatsJson = SmartObjectPoolMonitor.getInstance().getPoolStatsAsJson(House.class);

        LOGGER.info("Car Object JSON {} ", carPoolStatsJson);
        LOGGER.info("Book Object JSON {} ", bookPoolStatsJson);
        LOGGER.info("House Object JSON {} ", housePoolStatsJson);

        // Get pool metrics
        LOGGER.info("Cars in Pool: {}", carPool.getAvailableObjects());
        LOGGER.info("Books in Pool: {}", bookPool.getAvailableObjects());
        LOGGER.info("Houses in Pool: {}", housePool.getAvailableObjects());

    }
}
