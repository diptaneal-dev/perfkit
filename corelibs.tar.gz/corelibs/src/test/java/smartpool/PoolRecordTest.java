package smartpool;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PoolRecordTest {

    @Test
    public void testDefaultConstructor() {
        PoolRecord record = new PoolRecord();

        assertEquals(null, record.getPoolType());
        assertEquals(0, record.getInitialSize());
    }

    @Test
    public void testParameterizedConstructor() {
        String poolType = "TestType";
        int initialSize = 10;

        PoolRecord record = new PoolRecord(poolType, initialSize);

        assertEquals(poolType, record.getPoolType());
        assertEquals(initialSize, record.getInitialSize());
    }

    @Test
    public void testSettersAndGetters() {
        PoolRecord record = new PoolRecord();

        String newPoolType = "NewType";
        record.setPoolType(newPoolType);
        assertEquals(newPoolType, record.getPoolType());

        long newInitialSize = 20;
        record.setInitialSize(newInitialSize);
        assertEquals(newInitialSize, record.getInitialSize());
    }
}
