package smartpool;

import eventsHandling.EventPublisher;
import monitoring.Observer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.*;
import org.mockito.*;
import smartpool.poolexceptions.PoolException;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class ObjectPoolTest {
    private static final Logger LOGGER = LogManager.getLogger(SmartObjectPoolManager.class);

    @Mock
    private ObjectPool.Factory<String> mockFactory;

    private ObjectPool<String> objectPool;
    private SmartObjectPoolMonitor poolObserver = SmartObjectPoolMonitor.getInstance();

    @BeforeEach
    public void setUp() {
        System.setProperty("env.config.path", "src/test/resources/test.environment.properties");

        EventPublisher<PoolStats> mockPublisher = mock(EventPublisher.class);

        MockitoAnnotations.openMocks(this);
        when(mockFactory.create()).thenReturn("TestString");
        objectPool = new ObjectPool<>(mockFactory, String.class, 2, 10);
    }

    @AfterEach
    public void tearDown() {

    }

    @Test
    public void testInitializeObjects() {
        SmartObjectPoolMonitor poolObserver = SmartObjectPoolMonitor.getInstance();

        objectPool = new ObjectPool<>(String::new, String.class, 2, 10);
        assertEquals(2, objectPool.getAvailableObjects());
        String eod = poolObserver.endOfDaySummary();
        assertEquals(1, poolObserver.getCurrentPoolSizes().size());
    }

    @Test
    public void testGet() throws PoolException {
        String obj = objectPool.get();
        assertEquals("TestString", obj);
        assertEquals(1, objectPool.getAvailableObjects());
    }

    @Test
    public void testRelease() throws PoolException {
        String obj = objectPool.get();
        objectPool.release(obj);
        assertEquals(2, objectPool.getAvailableObjects());
    }

    @Test
    public void testReleaseNullObject() {
        assertThrows(PoolException.class, () -> objectPool.release(null));
    }

    @Test
    public void testResize() throws PoolException {
        for (int i = 0; i < 2; i++) objectPool.get();
        String obj = objectPool.get();
        assertNotNull(obj);
        assertEquals(1, objectPool.getAvailableObjects());
        assertEquals(4, objectPool.getCurrentSize());
    }

    @Test
    public void testMaxSizeBreach() throws PoolException {
        when(mockFactory.create()).thenAnswer(inv -> new String());
        ObjectPool<String> limitedPool = new ObjectPool<>(mockFactory, String.class, 5, 10);
        for (int i = 0; i < 15; i++) {
            limitedPool.get();
        }
        assertTrue(SmartObjectPoolMonitor.getInstance().getStatsForClass(String.class).isMaxSizeBreached());
    }

    @Test
    public void testReset() {
        objectPool.reset();
        assertEquals(0, objectPool.getAvailableObjects());
    }

    @Test
    public void testAddObserver() throws PoolException {
        Observer<PoolEventType, ObjectPool<String>> anotherObserver = mock(Observer.class);
        objectPool.addObserver(anotherObserver);
        objectPool.get();
        verify(anotherObserver, times(1)).update(PoolEventType.OBJECT_BORROWED, objectPool);
    }

    @Test
    public void testRemoveObserver() throws PoolException {
        Observer<PoolEventType, ObjectPool<String>> anotherObserver = mock(Observer.class);
        objectPool.addObserver(anotherObserver);
        objectPool.get();
        verify(anotherObserver, times(1)).update(PoolEventType.OBJECT_BORROWED, objectPool);

        Mockito.reset(anotherObserver);
        objectPool.removeObserver(anotherObserver);

        objectPool.get();
        verify(anotherObserver, never()).update(PoolEventType.OBJECT_BORROWED, objectPool);
        verifyNoMoreInteractions(anotherObserver);
    }

    @Test
    public void testResizeOutOfMemory() {
        ObjectPool.Factory mockFactory = mock(ObjectPool.Factory.class);
        when(mockFactory.create()).thenThrow(new OutOfMemoryError());

        objectPool.setFactory(mockFactory);

        Observer<PoolEventType, ObjectPool<String>> observerMock = mock(Observer.class);
        objectPool.addObserver(observerMock);

        PoolException exception = assertThrows(PoolException.class, () -> objectPool.resize());
        assertEquals("Failed to resize the pool due to memory constraints", exception.getMessage());

        verify(observerMock).update(PoolEventType.OUT_OF_MEMORY, objectPool);
    }

    @Test
    public void testResizeException() {
        ObjectPool.Factory mockFactory = mock(ObjectPool.Factory.class);
        when(mockFactory.create()).thenThrow(new RuntimeException("Simulated pool creation error"));

        objectPool.setFactory(mockFactory);

        Observer<PoolEventType, ObjectPool<String>> observerMock = mock(Observer.class);
        objectPool.addObserver(observerMock);

        PoolException exception = assertThrows(PoolException.class, () -> objectPool.resize());
        assertEquals("Error occurred during pool resizing", exception.getMessage());

        verify(observerMock).update(PoolEventType.ERROR_ON_RESIZE, objectPool);
    }
}
