package dbclients;

import com.influxdb.client.write.Point;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertTrue;


class AbstractDatabaseConnectorTest {
    private static class MockDatabaseConnector extends AbstractDatabaseConnector {
        public MockDatabaseConnector(String url, Map<String, String> configParameters) {
            super(url, configParameters);
        }

        @Override
        public void configure() {
        }

        @Override
        public void connect() {
        }

        @Override
        public void disconnect() {
        }

        @Override
        public void write(Point point) {

        }

        @Override
        public void executeQuery(String query) {
        }
    }

    @Test
    public void testToString() {
        Map<String, String> configParams = new HashMap<>();
        configParams.put("user", "root");
        configParams.put("password", "password");
        MockDatabaseConnector connector = new MockDatabaseConnector("jdbc:mysql://localhost:3306/mydb", configParams);

        String result = connector.toString();

        assertTrue(result.startsWith("AbstractDatabaseConnector{url='jdbc:mysql://localhost:3306/mydb'"));
        assertTrue(result.contains("configParameters={"));
        assertTrue(result.contains("user=root"));
        assertTrue(result.contains("password=password"));
        assertTrue(result.endsWith("}"));
    }
}