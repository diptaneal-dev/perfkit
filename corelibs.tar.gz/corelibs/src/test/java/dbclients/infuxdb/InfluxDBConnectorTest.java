package dbclients.infuxdb;

import com.influxdb.client.InfluxDBClient;
import com.influxdb.client.domain.WritePrecision;
import com.influxdb.client.write.Point;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class InfluxDBConnectorTest {

    private InfluxDBConnector influxDBConnector;
    private InfluxDBClient mockClient;

    @TempDir
    Path tempDir;

    @BeforeEach
    void setUp() throws IOException {
        String configYaml = "influxDBConfig:\n"
                + "  url: 'http://localhost:8086'\n"
                + "  token: 'tokenValue'\n"
                + "  bucket: 'bucketName'\n"
                + "  organization: 'orgName'\n"
                + "  username: 'username'\n"
                + " encryptionKey: 'mf3xrSJdEiUlzduFXNHoaw=='\n";
        Path configFile = tempDir.resolve("config.yaml");
        Files.write(configFile, configYaml.getBytes());

        mockClient = mock(InfluxDBClient.class);
        influxDBConnector = spy(new InfluxDBConnector(configFile.toString()));
        doReturn(mockClient).when(influxDBConnector).createClient(anyString(), any());
        doAnswer(invocation -> mockClient).when(influxDBConnector).createClient(anyString(), any());
    }

    @Test
    void testWriteWithoutConnect() {
        Point mockPoint = Point.measurement("test")
                .addField("field", "value")
                .time(Instant.now(), WritePrecision.MS);

        Exception exception = assertThrows(IllegalStateException.class, () -> {
            influxDBConnector.write(mockPoint);
        });

        assertEquals("InfluxDB client not initialized. Call connect() first.", exception.getMessage());
    }
}
