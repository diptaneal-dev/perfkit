package cataloghandler;

import catalog.electronics.Cellphone;
import catalog.electronics.Speaker;
import catalog.electronics.Television;
import smartpool.SmartObjectPoolManager;

public class ElectronicsBuilder {
    private static ElectronicsBuilder instance;
    private final SmartObjectPoolManager poolManager;

    private ElectronicsBuilder(SmartObjectPoolManager poolManager) {
        this.poolManager = poolManager;
    }

    public static synchronized ElectronicsBuilder getInstance(SmartObjectPoolManager poolManager) {
        if (instance == null) {
            instance = new ElectronicsBuilder(poolManager);
        }
        return instance;
    }

    public ElectronicsBuilder registerPool(long initialSize, int maxSize) {
        poolManager.register(Cellphone.class, initialSize, maxSize);
        poolManager.register(Speaker.class, initialSize, maxSize);
        poolManager.register(Television.class, initialSize, maxSize);
        return this;
    }
}

