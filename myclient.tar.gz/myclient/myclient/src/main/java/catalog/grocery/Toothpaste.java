package catalog.grocery;

public class Toothpaste implements Grocery {
    private String name;
    private String brand;
    private double price;
    private int weight;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    @Override
    public void displayInfo() {
        System.out.println("Toothpaste: " + brand + " " + name + ", Weight: " + weight + "g, Price: $" + price);
    }
}
