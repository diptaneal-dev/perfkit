package catalog.grocery;

public interface Grocery {
    void displayInfo();
}
