package catalog.grocery;

public class Oil implements Grocery {
    private String name;
    private String brand;
    private double price;
    private int volumeInMilliliters;

    public Oil(String name, String brand, double price, int volumeInMilliliters) {
        this.name = name;
        this.brand = brand;
        this.price = price;
        this.volumeInMilliliters = volumeInMilliliters;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getVolumeInMilliliters() {
        return volumeInMilliliters;
    }

    public void setVolumeInMilliliters(int volumeInMilliliters) {
        this.volumeInMilliliters = volumeInMilliliters;
    }

    @Override
    public void displayInfo() {
        System.out.println("Oil: " + brand + " " + name + ", Volume: " + volumeInMilliliters + "ml, Price: $" + price);
    }
}
