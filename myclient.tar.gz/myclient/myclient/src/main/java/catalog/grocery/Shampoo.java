package catalog.grocery;

public class Shampoo implements Grocery {
    private String name;
    private String brand;
    private double price;
    private int weightInMilliliters;

    public Shampoo(String name, String brand, double price, int weightInMilliliters) {
        this.name = name;
        this.brand = brand;
        this.price = price;
        this.weightInMilliliters = weightInMilliliters;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getWeightInMilliliters() {
        return weightInMilliliters;
    }

    public void setWeightInMilliliters(int weightInMilliliters) {
        this.weightInMilliliters = weightInMilliliters;
    }

    @Override
    public void displayInfo() {
        System.out.println("Shampoo: " + brand + " " + name + ", Weight: " + weightInMilliliters + "ml, Price: $" + price);
    }
}
