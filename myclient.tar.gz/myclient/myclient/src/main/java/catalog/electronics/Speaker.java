package catalog.electronics;

public class Speaker implements ElectronicsGoods {
    private String brand;
    private String model;
    private double price;
    private int powerOutput;

    public Speaker() {

    }

    public Speaker(String brand, String model, double price, int powerOutput) {
        this.brand = brand;
        this.model = model;
        this.price = price;
        this.powerOutput = powerOutput;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getPowerOutput() {
        return powerOutput;
    }

    public void setPowerOutput(int powerOutput) {
        this.powerOutput = powerOutput;
    }

    @Override
    public void displayInfo() {
        //System.out.println("Speaker: " + brand + " " + model + ", Power Output: " + powerOutput + "W, Price: $" + price);
    }
}
