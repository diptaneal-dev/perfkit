package catalog.electronics;

public class Cellphone implements ElectronicsGoods {
    private String brand;
    private String model;
    private double price;
    private String operatingSystem;

    public Cellphone() {

    }

    public Cellphone(String brand, String model, double price, String operatingSystem) {
        this.brand = brand;
        this.model = model;
        this.price = price;
        this.operatingSystem = operatingSystem;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getOperatingSystem() {
        return operatingSystem;
    }

    public void setOperatingSystem(String operatingSystem) {
        this.operatingSystem = operatingSystem;
    }

    @Override
    public void displayInfo() {
        //System.out.println("Cellphone: " + brand + " " + model + ", Operating System: " + operatingSystem + ", Price: $" + price);
    }
}
