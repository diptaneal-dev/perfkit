package catalog.electronics;

public interface ElectronicsGoods {
    void displayInfo();
}
