package catalog.electronics;

public class Television implements ElectronicsGoods {
    private String brand;
    private String model;
    private double price;
    private double screenSize;

    public Television (){

    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getScreenSize() {
        return screenSize;
    }

    public void setScreenSize(double screenSize) {
        this.screenSize = screenSize;
    }

    @Override
    public void displayInfo() {
        //System.out.println("Television: " + brand + " " + model + ", Screen Size: " + screenSize + " inches, Price: $" + price);
    }
}
