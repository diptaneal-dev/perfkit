package app;

import catalog.electronics.Cellphone;
import catalog.electronics.Speaker;
import catalog.electronics.Television;
import cataloghandler.ElectronicsBuilder;
import smartpool.ObjectPool;
import smartpool.SmartObjectPoolManager;
import smartpool.poolexceptions.PoolException;

public class Main {
    public static void main(String[] args) {
        SmartObjectPoolManager poolManager = SmartObjectPoolManager.getInstance();

        ElectronicsBuilder electronicsBuilder = ElectronicsBuilder.getInstance(poolManager);
        electronicsBuilder.registerPool(5, 5);

        ObjectPool<Cellphone> cellphonePool = poolManager.getPool(Cellphone.class);
        ObjectPool<Speaker> speakerPool = poolManager.getPool(Speaker.class);
        ObjectPool<Television> televisionPool = poolManager.getPool(Television.class);

        try {
            for (int i=0; i <= 10; i++) {
                Cellphone cellphone = cellphonePool.get();
                cellphone.displayInfo();
            }
        } catch (PoolException e) {
            throw new RuntimeException(e);
        }
    }
}
