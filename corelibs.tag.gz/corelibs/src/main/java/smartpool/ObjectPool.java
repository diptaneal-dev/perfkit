package smartpool;

import smartpool.poolexceptions.PoolException;

import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Predicate;

public class ObjectPool<T> {
    private final ConcurrentLinkedQueue<T> pool = new ConcurrentLinkedQueue<>();
    private final Factory<T> factory;
    private Class<T> type;
    private final long initialSize;
    private final int maxSize;
    private int currentSize;
    private final List<PoolObserver> observers = new ArrayList<>();

    public ObjectPool(Factory<T> factory, Class<T> type, long initialSize, int maxSize) {
        this.factory = factory;
        this.type = type;
        this.initialSize = initialSize;
        this.maxSize = maxSize;
        this.currentSize = 0;
        initializeObjects();
    }

    private void initializeObjects() {
        for (int i = 0; i < initialSize; i++) {
            pool.offer(factory.create());
            currentSize++;
        }
        notifyObservers(PoolEventType.POOL_CREATION);
    }

    public long getInitialSize() {
        return initialSize;
    }

    public T get() throws PoolException {
        T object = pool.poll();
        if (object == null && currentSize < maxSize) {
            synchronized (this) {
                if (!resize()) {
                    notifyObservers(PoolEventType.OUT_OF_POOL);
                    throw new PoolException("No objects available in the pool and resizing is disabled or reached max limit.");
                }
            }

            object = pool.poll();
            if (object == null) {
                notifyObservers(PoolEventType.OUT_OF_POOL);
                throw new PoolException("Failed to retrieve an object even after resizing.");
            }
        }
        notifyObservers(PoolEventType.OBJECT_BORROWED);
        return object;
    }

    public void release(T object) throws PoolException {
        if (object == null) {
            throw new PoolException("Cannot release a null object back to the pool");
        }

        try {
            if (object instanceof Resettable) {
                ((Resettable) object).reset();
            }

            if (!pool.offer(object)) {
                throw new PoolException("Failed to release the object back to the pool");
            }
            notifyObservers(PoolEventType.OBJECT_RETURNED);
        } catch (Exception e) {
            notifyObservers(PoolEventType.ERROR_ON_RELEASE);
            throw new PoolException("Error occurred while releasing object back to the pool", e);
        }
    }

    private boolean resize() throws PoolException {
        try {
            int newSize = currentSize * 2;
            for (int i = 0; i < currentSize; i++) {
                pool.offer(factory.create());
            }
            currentSize = newSize;
            notifyObservers(PoolEventType.RESIZE);

            if (currentSize >= maxSize) {
                notifyObservers(PoolEventType.MAXSIZE_BREACH);
            }
        } catch (OutOfMemoryError e) {
            notifyObservers(PoolEventType.OUT_OF_MEMORY);
            throw new PoolException("Failed to resize the pool due to memory constraints", e);
        } catch (Exception e) {
            notifyObservers(PoolEventType.ERROR_ON_RESIZE);
            throw new PoolException("Error occurred during pool resizing", e);
        }
        return true;
    }

    public void reset() {
        pool.clear();
        notifyObservers(PoolEventType.RESET);
    }

    public void addObserver(PoolObserver observer) {
        observers.add(observer);
    }

    public Class<T> getObjectClass() {
        return type;
    }

    public void removeObserver(PoolObserver observer) {
        observers.removeIf(Predicate.isEqual(observer));
    }

    private void notifyObservers(PoolEventType eventType) {
        for (PoolObserver observer : observers) {
            observer.update(eventType, this);
        }
    }

    public int getCurrentSize() {
        return currentSize;
    }

    public int getAvailableObjects() {
        return pool.size();
    }

    @FunctionalInterface
    public interface Factory<T> {
        T create();
    }
}
