package smartpool;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import stats.PoolStats;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class SmartObjectPoolMonitor implements PoolObserver {
    private static final Logger LOGGER = LogManager.getLogger(SmartObjectPoolMonitor.class);

    private static final SmartObjectPoolMonitor INSTANCE = new SmartObjectPoolMonitor();

    private SmartObjectPoolMonitor() { }

    public static SmartObjectPoolMonitor getInstance() {
        return INSTANCE;
    }

    private final Map<Class<?>, PoolStats> poolStatsMap = new ConcurrentHashMap<>();

    @Override
    public void update(PoolEventType notification, ObjectPool<?> pool) {
        PoolStats stats = poolStatsMap.computeIfAbsent(pool.getObjectClass(), k -> new PoolStats());

        switch (notification) {
            case POOL_CREATION:
                stats.updateTimeOfPoolCreation();
                stats.setCurrentSize(pool.getCurrentSize());
                stats.setInitialPoolSize(pool.getInitialSize());
                stats.setPoolType(pool.getObjectClass().getName());
                LOGGER.info("Pool for class {} created.", pool.getObjectClass());
                break;
            case OBJECT_BORROWED:
                stats.incrementCurrentPoolUtilization();
                break;
            case OBJECT_RETURNED:
                stats.decrementCurrentPoolUtilization();
                break;
            case OUT_OF_POOL:
                stats.incrementOutOfPoolCount();
                break;
            case OUT_OF_MEMORY:
                stats.incrementOutOfMemoryCount();
                LOGGER.error("Failed to resize pool for class {} due to memory constraints.", pool.getObjectClass());
                break;
            case RESIZE:
                stats.incrementResizes();
                stats.setCurrentSize(pool.getCurrentSize());
                stats.addResizeTimestamp(Instant.now());
                LOGGER.warn("Resize event triggered for class {}.", pool.getObjectClass());
                break;
            case RESET:
                stats.reset();
                LOGGER.warn("Reset event triggered for class {}.", pool.getObjectClass());
                break;
            case ERROR_ON_RELEASE:
                LOGGER.error("Error occurred during releasing an object back to the pool for class {}.", pool.getObjectClass());
                break;
            case ERROR_ON_RESIZE:
                LOGGER.error("Error occurred during pool resizing for class {}.", pool.getObjectClass());
                break;
            case MAXSIZE_BREACH:
                LOGGER.warn("Max Pool Size breached for class {}", pool.getObjectClass());
                stats.setPeakSize(pool.getCurrentSize());
                stats.setMaxSizeBreached(true);
                break;
            default:
                break;
        }
    }

    public Map<Class<?>, Long> getCurrentPoolSizes() {
        return poolStatsMap.entrySet().stream()
                .collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue().getCurrentSize()));
    }

    public Map<Class<?>, Long> getInitialPoolSizes() {
        return poolStatsMap.entrySet().stream()
                .collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue().getInitialPoolSize()));
    }

    public Map<Class<?>, Long> getPeakPoolSizes() {
        return poolStatsMap.entrySet().stream()
                .collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue().getPeakSize()));
    }


    public PoolStats getStatsForClass(Class<?> cls) {
        return poolStatsMap.get(cls);
    }

    public String getPoolStatsAsJson(Class<?> clazz) {
        PoolStats stats = poolStatsMap.get(clazz);
        if (stats != null) {
            return stats.convertStatsToJson();
        }
        return "{}";
    }

    public String endOfDaySummary() {
        StringBuilder summaryBuilder = new StringBuilder();
        summaryBuilder.append("End of Day Pool Summary:\n");

        for (Class<?> poolType : poolStatsMap.keySet()) {
            PoolStats stats = getStatsForClass(poolType);
            if (stats != null) {
                String jsonSummary = stats.convertStatsToJson();
                summaryBuilder.append("Stats for pool of type ")
                        .append(poolType.getSimpleName())
                        .append(": ")
                        .append(jsonSummary)
                        .append("\n");
            } else {
                summaryBuilder.append("No stats found for pool of type ")
                        .append(poolType.getSimpleName())
                        .append("\n");
            }
        }

        String completeSummary = summaryBuilder.toString();
        return completeSummary;
    }
}
