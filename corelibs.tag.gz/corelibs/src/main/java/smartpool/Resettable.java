package smartpool;

public interface Resettable {
    void reset();
}
