package smartpool;

public interface PoolObserver {
    void update(PoolEventType notification, ObjectPool<?> pool);
}
