package config;

import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class YamlConfigLoader {

    public static <T> T loadConfig(String yamlFilePath, Class<T> targetType) {
        try (InputStream input = new FileInputStream(yamlFilePath)) {
            Yaml yaml = new Yaml(new Constructor(targetType));
            return (T) yaml.load(input);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}